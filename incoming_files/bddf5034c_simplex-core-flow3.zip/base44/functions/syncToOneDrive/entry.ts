import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get OneDrive access token
    const { accessToken } = await base44.asServiceRole.connectors.getConnection('one_drive');

    // Fetch all portal data to sync
    const [expenses, documents, renewals, compliance, hrRecords] = await Promise.all([
      base44.entities.Expense.list(),
      base44.entities.Document.list(),
      base44.entities.RenewalItem.list(),
      base44.entities.ComplianceItem.list(),
      base44.entities.HRRecord.list()
    ]);

    // Create a JSON backup file with all data
    const backupData = {
      synced_at: new Date().toISOString(),
      user: user.email,
      data: {
        expenses,
        documents,
        renewals,
        compliance,
        hrRecords
      }
    };

    // Upload to OneDrive
    const fileName = `5S_Portal_Backup_${new Date().toISOString().split('T')[0]}.json`;
    const uploadUrl = `/me/drive/root/children/${fileName}/content`;

    const uploadResponse = await fetch(`https://graph.microsoft.com/v1.0${uploadUrl}`, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(backupData)
    });

    if (!uploadResponse.ok) {
      throw new Error(`OneDrive upload failed: ${uploadResponse.status}`);
    }

    return Response.json({
      success: true,
      message: `Synced ${expenses.length + documents.length + renewals.length + compliance.length + hrRecords.length} records to OneDrive`,
      file_name: fileName
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});