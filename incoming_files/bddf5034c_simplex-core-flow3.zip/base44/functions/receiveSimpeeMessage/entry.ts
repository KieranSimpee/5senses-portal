import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { message, sender, timestamp } = await req.json();

    await base44.asServiceRole.entities.NoticeBoard.create({
      title: sender || "Simpee AI",
      body: message,
      category: "General",
      pinned: false
    });

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});