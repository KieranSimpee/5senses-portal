import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    
    const {
      request_type,
      target_app_id,
      target_app_name,
      entity_name,
      instruction,
      data,
      whatsapp_message_id
    } = body;

    // Create approval request
    const request = await base44.asServiceRole.entities.SimpeeApprovalRequest.create({
      request_type,
      target_app_id,
      target_app_name,
      entity_name,
      instruction,
      data,
      status: 'pending',
      whatsapp_message_id
    });

    // Post to NoticeBoard as urgent notice
    await base44.asServiceRole.entities.NoticeBoard.create({
      title: `⚠️ Simpee Approval Required: ${instruction.substring(0, 60)}...`,
      body: `App: ${target_app_name}\nType: ${request_type}\nEntity: ${entity_name}\n\nReview in Workspace Hub > Approvals`,
      category: 'Admin',
      priority: 'urgent',
      pinned: true
    });

    // TODO: Send WhatsApp message via SIMPEE_ENDPOINT with approval request
    // This would integrate with your WhatsApp API

    return Response.json({
      success: true,
      request_id: request.id,
      message: 'Approval request created and posted to NoticeBoard'
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});