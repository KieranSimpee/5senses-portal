import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { accessToken } = await base44.asServiceRole.connectors.getConnection('outlook');

    const response = await fetch('https://graph.microsoft.com/v1.0/me/sendMail', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message: {
          subject: '✅ Test Email from 5S Portal',
          body: {
            contentType: 'HTML',
            content: '<p>This is a test email confirming your Outlook connection is working.</p><p>Sent at: ' + new Date().toISOString() + '</p>',
          },
          toRecipients: [
            {
              emailAddress: {
                address: user.email,
              },
            },
          ],
        },
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      return Response.json({ error: error }, { status: response.status });
    }

    return Response.json({ success: true, message: 'Test email sent to ' + user.email });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});