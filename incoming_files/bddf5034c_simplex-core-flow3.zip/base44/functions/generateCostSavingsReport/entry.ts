import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    const expenses = await base44.asServiceRole.entities.Expense.list().catch(() => []);
    const renewals = await base44.asServiceRole.entities.RenewalItem.list().catch(() => []);

    // Group expenses by category to find high-spend areas
    const byCat = {};
    expenses.forEach(e => {
      const cat = e.category || 'Other';
      if (!byCat[cat]) byCat[cat] = { total: 0, count: 0, items: [] };
      byCat[cat].total += e.amount || 0;
      byCat[cat].count += 1;
      byCat[cat].items.push(e);
    });

    // Identify duplicate vendors (consolidation opportunity)
    const byVendor = {};
    expenses.forEach(e => {
      const vendor = e.vendor || 'Unknown';
      if (!byVendor[vendor]) byVendor[vendor] = { total: 0, count: 0 };
      byVendor[vendor].total += e.amount || 0;
      byVendor[vendor].count += 1;
    });

    const vendors = Object.entries(byVendor)
      .map(([name, data]) => ({ name, ...data }))
      .sort((a, b) => b.total - a.total);

    // Check for duplicate subscriptions
    const softwareExpenses = expenses.filter(e => 
      e.category === 'Software' || e.category === 'Microsoft Licenses'
    );
    const softwareByTitle = {};
    softwareExpenses.forEach(e => {
      const title = (e.title || '').toLowerCase();
      if (!softwareByTitle[title]) softwareByTitle[title] = [];
      softwareByTitle[title].push(e);
    });

    const duplicateSubcriptions = Object.entries(softwareByTitle)
      .filter(([_, items]) => items.length > 1)
      .map(([title, items]) => ({
        title,
        count: items.length,
        monthly_duplicate_cost: items.reduce((s, e) => s + (e.amount || 0), 0),
        annual_waste: items.reduce((s, e) => s + (e.amount || 0), 0) * 12
      }));

    // Hosting consolidation opportunity
    const hostingExpenses = expenses.filter(e => 
      e.category === 'Hosting' || e.category === 'Domain & Hosting'
    );
    const hostingByPlatform = {};
    hostingExpenses.forEach(e => {
      const platform = e.vendor || 'Unknown';
      if (!hostingByPlatform[platform]) hostingByPlatform[platform] = { total: 0, count: 0 };
      hostingByPlatform[platform].total += e.amount || 0;
      hostingByPlatform[platform].count += 1;
    });

    const hostingPlatforms = Object.keys(hostingByPlatform).length;
    const hostingTotal = Object.values(hostingByPlatform).reduce((s, p) => s + p.total, 0);

    // Estimate savings
    let potentialSavings = 0;
    let recommendations = [];

    if (duplicateSubcriptions.length > 0) {
      const dupSavings = duplicateSubcriptions.reduce((s, d) => s + d.annual_waste, 0);
      potentialSavings += dupSavings;
      recommendations.push({
        type: 'duplicate_subscriptions',
        title: `Eliminate ${duplicateSubcriptions.length} duplicate subscriptions`,
        annual_savings: dupSavings,
        details: duplicateSubcriptions
      });
    }

    if (hostingPlatforms > 2) {
      const consolidationSavings = hostingTotal * 0.15; // Estimate 15% savings from consolidation
      potentialSavings += consolidationSavings;
      recommendations.push({
        type: 'hosting_consolidation',
        title: `Consolidate ${hostingPlatforms} hosting providers to 1–2`,
        annual_savings: consolidationSavings,
        details: {
          current_platforms: hostingPlatforms,
          current_spend: hostingTotal,
          estimated_consolidated_spend: hostingTotal * 0.85
        }
      });
    }

    // High-spend categories
    const highSpend = Object.entries(byCat)
      .filter(([_, data]) => data.total > 10000)
      .map(([cat, data]) => ({
        category: cat,
        total: data.total,
        items: data.count,
        avg_per_item: Math.round(data.total / data.count)
      }))
      .sort((a, b) => b.total - a.total);

    return Response.json({
      summary: {
        total_annual_spend: expenses.reduce((s, e) => s + (e.amount || 0), 0),
        potential_annual_savings: Math.round(potentialSavings),
        vendors_consolidated: vendors.length,
        top_vendors: vendors.slice(0, 5)
      },
      recommendations,
      analysis: {
        duplicate_subscriptions: duplicateSubcriptions,
        hosting_consolidation: {
          platforms: hostingPlatforms,
          total_spend: hostingTotal
        },
        high_spend_categories: highSpend
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});