import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Get renewals due in next 30 days
    const renewals = await base44.entities.RenewalItem.list();
    const today = new Date();
    const in30Days = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000);

    const upcomingRenewals = renewals.filter(r => {
      if (r.reminder_sent) return false;
      const renewalDate = new Date(r.renewal_date);
      return renewalDate >= today && renewalDate <= in30Days && r.status === 'Active';
    });

    // Send emails for each renewal
    for (const renewal of upcomingRenewals) {
      const daysLeft = Math.ceil((new Date(renewal.renewal_date) - today) / (24 * 60 * 60 * 1000));
      
      await base44.integrations.Core.SendEmail({
        to: user.email,
        subject: `⏰ Renewal Due Soon: ${renewal.title} (${daysLeft} days)`,
        body: `
Hi ${user.full_name},

Your ${renewal.category} renewal is coming up:

📋 Item: ${renewal.title}
📅 Renewal Date: ${renewal.renewal_date}
💰 Cost: ${renewal.currency} ${renewal.cost?.toLocaleString() || 'N/A'}
🏢 Vendor: ${renewal.vendor || 'N/A'}
⏳ Days Left: ${daysLeft}

Please ensure payment is processed to avoid service interruption.

5S Portal
        `
      });

      // Mark reminder as sent
      await base44.entities.RenewalItem.update(renewal.id, { reminder_sent: true });
    }

    return Response.json({ 
      sent: upcomingRenewals.length,
      renewals: upcomingRenewals.map(r => ({ title: r.title, days_left: Math.ceil((new Date(r.renewal_date) - today) / (24 * 60 * 60 * 1000)) }))
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});