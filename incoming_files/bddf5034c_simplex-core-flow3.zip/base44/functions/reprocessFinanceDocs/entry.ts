import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get all finance documents
    const docs = await base44.entities.Document.filter({ category: 'finance' });
    const results = [];

    for (const doc of docs) {
      if (!doc.file_url) continue;

      try {
        const extraction = await base44.integrations.Core.InvokeLLM({
          prompt: `Extract detailed invoice/receipt data from this document and return as JSON:
- title: document title
- amount: numeric amount only
- currency: currency code (HKD, USD, GBP, etc.)
- vendor: vendor/supplier name
- date: date in YYYY-MM-DD format
- category: Software, Hosting, Marketing, Office, Professional Fees, Government Fees, Legal, Design, Company Registration, Other
- payment_method: Credit Card, Bank Transfer, FPS, Cash, Cheque, Other
- receipt_number: invoice/receipt number if present
- transaction_type: Purchase, Refund, etc.
- product_name: full product/service name
- length: term length if applicable (e.g. '1 Year', '01 Month')
- subtotal: subtotal before tax
- tax_amount: tax amount
- icann_fee: ICANN fee if applicable
- notes: any additional details`,
          file_urls: [doc.file_url],
          response_json_schema: {
            type: 'object',
            properties: {
              title: { type: 'string' },
              amount: { type: 'number' },
              currency: { type: 'string' },
              vendor: { type: 'string' },
              date: { type: 'string' },
              category: { type: 'string' },
              payment_method: { type: 'string' },
              receipt_number: { type: 'string' },
              transaction_type: { type: 'string' },
              product_name: { type: 'string' },
              length: { type: 'string' },
              subtotal: { type: 'number' },
              tax_amount: { type: 'number' },
              icann_fee: { type: 'number' },
              notes: { type: 'string' }
            }
          }
        });

        if (extraction && extraction.amount) {
          await base44.asServiceRole.entities.Expense.create({
            title: extraction.title || doc.title,
            amount: extraction.amount,
            currency: extraction.currency || 'HKD',
            vendor: extraction.vendor || '',
            date: extraction.date || new Date().toISOString().split('T')[0],
            category: extraction.category || 'Other',
            payment_method: extraction.payment_method || 'Other',
            receipt_url: doc.file_url,
            file_name: doc.file_name || '',
            receipt_number: extraction.receipt_number || '',
            transaction_type: extraction.transaction_type || '',
            product_name: extraction.product_name || '',
            length: extraction.length || '',
            subtotal: extraction.subtotal,
            tax_amount: extraction.tax_amount,
            icann_fee: extraction.icann_fee,
            status: 'Pending',
            notes: extraction.notes || ''
          });

          results.push({ doc_id: doc.id, status: 'success', amount: extraction.amount });
        }
      } catch (e) {
        results.push({ doc_id: doc.id, status: 'error', error: e.message });
      }
    }

    return Response.json({ 
      message: `Processed ${docs.length} finance documents`,
      created: results.filter(r => r.status === 'success').length,
      results 
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});