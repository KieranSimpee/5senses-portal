import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const compliance = await base44.entities.ComplianceItem.list();
    const today = new Date();
    const in7Days = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);

    // Get overdue and upcoming compliance items
    const urgentItems = compliance.filter(c => {
      if (c.reminder_sent || c.status === 'Completed') return false;
      const dueDate = new Date(c.due_date);
      return dueDate <= in7Days;
    });

    if (urgentItems.length === 0) {
      return Response.json({ sent: 0, message: 'No urgent compliance items' });
    }

    const overdue = urgentItems.filter(c => new Date(c.due_date) < today);
    const upcoming = urgentItems.filter(c => new Date(c.due_date) >= today);

    let emailBody = `Hi ${user.full_name},\n\n`;

    if (overdue.length > 0) {
      emailBody += `⚠️ OVERDUE COMPLIANCE ITEMS (${overdue.length}):\n`;
      overdue.forEach(c => {
        emailBody += `\n• ${c.title}\n  Category: ${c.category}\n  Due: ${c.due_date}\n  Status: ${c.status}\n`;
      });
      emailBody += '\n---\n\n';
    }

    if (upcoming.length > 0) {
      emailBody += `📋 UPCOMING (Next 7 days):\n`;
      upcoming.forEach(c => {
        const daysLeft = Math.ceil((new Date(c.due_date) - today) / (24 * 60 * 60 * 1000));
        emailBody += `\n• ${c.title} (${daysLeft} days)\n  Category: ${c.category}\n  Due: ${c.due_date}\n`;
      });
    }

    emailBody += '\n\nPlease prioritize these items.\n\n5S Portal';

    await base44.integrations.Core.SendEmail({
      to: user.email,
      subject: `🚨 Compliance Alert: ${overdue.length} Overdue, ${upcoming.length} Due Soon`,
      body: emailBody
    });

    // Mark reminders as sent
    for (const item of urgentItems) {
      await base44.entities.ComplianceItem.update(item.id, { reminder_sent: true });
    }

    return Response.json({ 
      sent: urgentItems.length,
      overdue: overdue.length,
      upcoming: upcoming.length
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});