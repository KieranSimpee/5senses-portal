import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { approval_request_id } = body;

    // Get the approval request
    const request = await base44.asServiceRole.entities.SimpeeApprovalRequest.list();
    const approvalRequest = request.find(r => r.id === approval_request_id);

    if (!approvalRequest) {
      return Response.json({ error: 'Approval request not found' }, { status: 404 });
    }

    if (approvalRequest.status !== 'approved') {
      return Response.json({ error: 'Request is not approved' }, { status: 400 });
    }

    try {
      // Execute the instruction on the target app
      let result;
      
      switch (approvalRequest.request_type) {
        case 'create':
          result = await base44.asServiceRole.entities[approvalRequest.entity_name].create(
            approvalRequest.data
          );
          break;
        case 'update':
          const updateId = approvalRequest.data.id;
          const updateData = { ...approvalRequest.data };
          delete updateData.id;
          result = await base44.asServiceRole.entities[approvalRequest.entity_name].update(
            updateId,
            updateData
          );
          break;
        case 'delete':
          result = await base44.asServiceRole.entities[approvalRequest.entity_name].delete(
            approvalRequest.data.id
          );
          break;
        case 'query':
          result = await base44.asServiceRole.entities[approvalRequest.entity_name].list();
          break;
        default:
          return Response.json({ error: 'Unknown request type' }, { status: 400 });
      }

      // Update approval request with execution result
      await base44.asServiceRole.entities.SimpeeApprovalRequest.update(approval_request_id, {
        status: 'executed',
        executed_at: new Date().toISOString(),
        execution_result: result
      });

      return Response.json({
        success: true,
        result,
        message: `${approvalRequest.request_type} executed successfully on ${approvalRequest.entity_name}`
      });
    } catch (execError) {
      // Update with error
      await base44.asServiceRole.entities.SimpeeApprovalRequest.update(approval_request_id, {
        status: 'executed',
        executed_at: new Date().toISOString(),
        execution_error: execError.message
      });

      return Response.json({
        success: false,
        error: execError.message,
        message: 'Execution failed'
      }, { status: 500 });
    }
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});