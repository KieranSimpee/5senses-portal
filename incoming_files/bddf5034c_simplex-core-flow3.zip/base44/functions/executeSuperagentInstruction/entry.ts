import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { instructionId } = body;

    if (!instructionId) {
      return Response.json({ error: 'instructionId required' }, { status: 400 });
    }

    // Fetch instruction
    const instruction = await base44.asServiceRole.entities.SuperagentInstruction.get(instructionId);

    if (!instruction) {
      return Response.json({ error: 'Instruction not found' }, { status: 404 });
    }

    // Update status to executing
    await base44.asServiceRole.entities.SuperagentInstruction.update(instructionId, {
      status: 'executing'
    });

    let result = null;
    let error = null;

    try {
      const { instruction_type, entity_name, data, target_app_id } = instruction;

      // Execute based on instruction type
      if (instruction_type === 'create') {
        result = await base44.asServiceRole.entities[entity_name]?.create(data);
      } else if (instruction_type === 'update') {
        const { id, ...updateData } = data;
        result = await base44.asServiceRole.entities[entity_name]?.update(id, updateData);
      } else if (instruction_type === 'delete') {
        const { id } = data;
        result = await base44.asServiceRole.entities[entity_name]?.delete(id);
      } else if (instruction_type === 'query') {
        result = await base44.asServiceRole.entities[entity_name]?.list();
      }

      // Update instruction with success result
      await base44.asServiceRole.entities.SuperagentInstruction.update(instructionId, {
        status: 'completed',
        result: result,
        executed_at: new Date().toISOString()
      });

      return Response.json({ success: true, result });
    } catch (e) {
      error = e.message;
      await base44.asServiceRole.entities.SuperagentInstruction.update(instructionId, {
        status: 'failed',
        error: error,
        executed_at: new Date().toISOString()
      });
      return Response.json({ success: false, error }, { status: 500 });
    }
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});