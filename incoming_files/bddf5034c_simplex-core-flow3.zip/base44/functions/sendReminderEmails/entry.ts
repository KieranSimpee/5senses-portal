import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin only' }, { status: 403 });
    }

    const today = new Date();
    const in7Days = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
    const in30Days = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000);

    // Get all renewal items expiring within 7 days
    const renewals = await base44.asServiceRole.entities.RenewalItem.list().catch(() => []);
    const urgentRenewals = renewals.filter(r => {
      const renDate = new Date(r.renewal_date);
      return renDate <= in7Days && renDate >= today && !r.reminder_sent;
    });

    // Get compliance items due within 7 days
    const compliance = await base44.asServiceRole.entities.ComplianceItem.list().catch(() => []);
    const urgentCompliance = compliance.filter(c => {
      const dueDate = new Date(c.due_date);
      return dueDate <= in7Days && dueDate >= today && c.status !== 'Completed' && !c.reminder_sent;
    });

    // Get pending expenses
    const expenses = await base44.asServiceRole.entities.Expense.list().catch(() => []);
    const pendingExpenses = expenses.filter(e => e.status === 'Pending' || e.status === 'pending');

    let sent = 0;

    // Send renewal reminders
    for (const renewal of urgentRenewals) {
      await base44.integrations.Core.SendEmail({
        to: user.email,
        subject: `⚠️ REMINDER: ${renewal.title} renews on ${renewal.renewal_date}`,
        body: `Your subscription/license "${renewal.title}" will expire on ${renewal.renewal_date}.\n\nVendor: ${renewal.vendor}\nCost: ${renewal.currency} ${renewal.cost}\n\nPlease renew to avoid service interruption.`
      }).catch(() => null);
      
      await base44.asServiceRole.entities.RenewalItem.update(renewal.id, { reminder_sent: true }).catch(() => null);
      sent++;
    }

    // Send compliance reminders
    for (const comp of urgentCompliance) {
      await base44.integrations.Core.SendEmail({
        to: user.email,
        subject: `⚠️ COMPLIANCE DEADLINE: ${comp.title} due ${comp.due_date}`,
        body: `Compliance item "${comp.title}" is due on ${comp.due_date}.\n\nCategory: ${comp.category}\nStatus: ${comp.status}\n\nPlease complete this task to avoid penalties.`
      }).catch(() => null);
      
      await base44.asServiceRole.entities.ComplianceItem.update(comp.id, { reminder_sent: true }).catch(() => null);
      sent++;
    }

    // Daily summary email if there are pending items
    if (pendingExpenses.length > 0) {
      const total = pendingExpenses.reduce((s, e) => s + (e.amount || 0), 0);
      await base44.integrations.Core.SendEmail({
        to: user.email,
        subject: `📊 Daily Summary: ${pendingExpenses.length} pending expenses (HKD ${total.toLocaleString()})`,
        body: `You have ${pendingExpenses.length} expenses awaiting approval totaling HKD ${total.toLocaleString()}.\n\nPlease review and approve/reject in Finance → Expenses.`
      }).catch(() => null);
    }

    return Response.json({ 
      success: true,
      reminders_sent: sent,
      urgent_renewals: urgentRenewals.length,
      urgent_compliance: urgentCompliance.length,
      pending_expenses: pendingExpenses.length
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});