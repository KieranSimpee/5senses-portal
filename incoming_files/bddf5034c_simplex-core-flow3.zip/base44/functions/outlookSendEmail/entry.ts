import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { to, cc, subject, body, account = 'me' } = await req.json();

    if (!to || !subject || !body) {
      return Response.json({ error: 'Missing required fields: to, subject, body' }, { status: 400 });
    }

    const { accessToken } = await base44.asServiceRole.connectors.getConnection('outlook');

    const messagePayload = {
      message: {
        subject,
        body: {
          contentType: 'HTML',
          content: body
        },
        toRecipients: [{ emailAddress: { address: to.trim() } }],
        ...(cc && {
          ccRecipients: cc.split(',').map(e => ({
            emailAddress: { address: e.trim() }
          }))
        })
      },
      saveToSentItems: true
    };

    const graphBase = account === 'me' ? '/me' : `/users/${account}`;
    const response = await fetch(`https://graph.microsoft.com/v1.0${graphBase}/sendMail`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(messagePayload)
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`Graph API error: ${response.status} ${JSON.stringify(error)}`);
    }

    return Response.json({ success: true, message: 'Email sent successfully' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});