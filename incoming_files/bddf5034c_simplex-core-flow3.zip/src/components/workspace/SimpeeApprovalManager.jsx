import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle2, XCircle, Clock, Zap } from "lucide-react";
import { format, parseISO } from "date-fns";

const statusConfig = {
  pending: { icon: Clock, color: "text-yellow-600", bg: "bg-yellow-50", label: "Pending" },
  approved: { icon: CheckCircle2, color: "text-green-600", bg: "bg-green-50", label: "Approved" },
  rejected: { icon: XCircle, color: "text-red-600", bg: "bg-red-50", label: "Rejected" },
  executed: { icon: CheckCircle2, color: "text-blue-600", bg: "bg-blue-50", label: "Executed" }
};

function ApprovalCard({ request, onApprove, onReject }) {
  const [expanded, setExpanded] = useState(false);
  const config = statusConfig[request.status] || statusConfig.pending;
  const Icon = config.icon;

  return (
    <Card className={`${config.bg} border-l-4`} style={{ borderLeftColor: config.color === "text-yellow-600" ? "#ca8a04" : config.color === "text-green-600" ? "#16a34a" : config.color === "text-red-600" ? "#dc2626" : "#2563eb" }}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3 flex-1">
            <Icon className={`${config.color} h-5 w-5 mt-1`} />
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm text-gray-900">{request.instruction}</p>
              <div className="flex gap-2 mt-1 flex-wrap">
                <Badge variant="outline" className="text-xs">{request.request_type}</Badge>
                <Badge variant="outline" className="text-xs">{request.target_app_name}</Badge>
                {request.entity_name && <Badge variant="outline" className="text-xs">{request.entity_name}</Badge>}
              </div>
            </div>
          </div>
          <button onClick={() => setExpanded(!expanded)} className="ml-2 text-gray-400 hover:text-gray-600">
            {expanded ? "▼" : "▶"}
          </button>
        </div>
      </CardHeader>

      {expanded && (
        <CardContent className="space-y-3 text-xs">
          <div>
            <p className="text-gray-600 font-medium">Status</p>
            <p className={`${config.color} font-semibold`}>{config.label}</p>
          </div>

          {request.data && (
            <div>
              <p className="text-gray-600 font-medium">Data</p>
              <pre className="bg-white p-2 rounded border text-[10px] overflow-x-auto max-h-32 overflow-y-auto">
                {JSON.stringify(request.data, null, 2)}
              </pre>
            </div>
          )}

          {request.execution_result && (
            <div>
              <p className="text-gray-600 font-medium">Execution Result</p>
              <pre className="bg-white p-2 rounded border text-[10px] overflow-x-auto max-h-32 overflow-y-auto">
                {JSON.stringify(request.execution_result, null, 2)}
              </pre>
            </div>
          )}

          {request.execution_error && (
            <div>
              <p className="text-gray-600 font-medium">Error</p>
              <p className="text-red-600 bg-white p-2 rounded border">{request.execution_error}</p>
            </div>
          )}

          {request.status === "pending" && (
            <div className="flex gap-2 pt-2 border-t">
              <Button size="sm" onClick={() => onApprove(request.id)} className="bg-green-600 hover:bg-green-700">
                Approve
              </Button>
              <Button size="sm" variant="destructive" onClick={() => onReject(request.id)}>
                Reject
              </Button>
            </div>
          )}

          <div className="text-gray-500 border-t pt-2">
            <p>ID: {request.id}</p>
            <p>Created: {format(parseISO(request.created_date), "PPpp")}</p>
          </div>
        </CardContent>
      )}
    </Card>
  );
}

export default function SimpeeApprovalManager() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("pending");

  useEffect(() => {
    const fetchRequests = async () => {
      try {
        const data = await base44.entities.SimpeeApprovalRequest.list('-updated_date', 100);
        setRequests(data || []);
      } catch (error) {
        console.error("Failed to fetch requests:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchRequests();
    const interval = setInterval(fetchRequests, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleApprove = async (requestId) => {
    try {
      await base44.entities.SimpeeApprovalRequest.update(requestId, {
        status: 'approved',
        approved_at: new Date().toISOString()
      });
      
      // Execute the approved request
      await base44.functions.invoke('executeSimpeeApprovedRequest', { approval_request_id: requestId });
      
      setRequests(prev => prev.map(r => r.id === requestId ? { ...r, status: 'approved' } : r));
    } catch (error) {
      console.error("Error approving request:", error);
    }
  };

  const handleReject = async (requestId) => {
    try {
      await base44.entities.SimpeeApprovalRequest.update(requestId, {
        status: 'rejected',
        rejected_reason: 'Manually rejected by user'
      });
      setRequests(prev => prev.map(r => r.id === requestId ? { ...r, status: 'rejected' } : r));
    } catch (error) {
      console.error("Error rejecting request:", error);
    }
  };

  const filteredRequests = filter === "all" ? requests : requests.filter(r => r.status === filter);
  const statusCounts = {
    pending: requests.filter(r => r.status === "pending").length,
    approved: requests.filter(r => r.status === "approved").length,
    rejected: requests.filter(r => r.status === "rejected").length,
    executed: requests.filter(r => r.status === "executed").length
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-bold text-gray-900 mb-3">5S Portal Approvals</h2>
        
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
          {Object.entries(statusCounts).map(([status, count]) => (
            <button
              key={status}
              onClick={() => setFilter(filter === status ? "all" : status)}
              className={`p-3 rounded-lg border-2 transition-all ${
                filter === status ? "border-blue-500 bg-blue-50" : "border-gray-200 bg-white hover:border-gray-300"
              }`}
            >
              <p className="text-xs font-medium text-gray-600 capitalize">{status}</p>
              <p className="text-lg font-bold text-gray-900">{count}</p>
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-8">
          <p className="text-gray-600">Loading approvals...</p>
        </div>
      ) : filteredRequests.length === 0 ? (
        <Card className="bg-gray-50 border-dashed">
          <CardContent className="py-8 text-center">
            <Zap className="h-8 w-8 text-gray-400 mx-auto mb-2 opacity-50" />
            <p className="text-sm text-gray-600">
              {filter === "all" ? "No approval requests" : `No ${filter} requests`}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {filteredRequests.map(request => (
            <ApprovalCard 
              key={request.id} 
              request={request} 
              onApprove={handleApprove}
              onReject={handleReject}
            />
          ))}
        </div>
      )}
    </div>
  );
}