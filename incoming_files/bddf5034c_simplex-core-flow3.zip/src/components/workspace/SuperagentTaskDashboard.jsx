import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle2, AlertCircle, Clock, Zap, ChevronDown, ChevronUp } from "lucide-react";
import { format, parseISO } from "date-fns";

const statusConfig = {
  pending: { icon: Clock, color: "text-yellow-600", bg: "bg-yellow-50", label: "Pending" },
  executing: { icon: Loader2, color: "text-blue-600", bg: "bg-blue-50", label: "Executing", spin: true },
  completed: { icon: CheckCircle2, color: "text-green-600", bg: "bg-green-50", label: "Completed" },
  failed: { icon: AlertCircle, color: "text-red-600", bg: "bg-red-50", label: "Failed" }
};

function TaskCard({ task }) {
  const [expanded, setExpanded] = useState(false);
  const config = statusConfig[task.status] || statusConfig.pending;
  const Icon = config.icon;

  return (
    <Card className={`${config.bg} border-l-4`} style={{ borderLeftColor: config.color === "text-yellow-600" ? "#ca8a04" : config.color === "text-blue-600" ? "#2563eb" : config.color === "text-green-600" ? "#16a34a" : "#dc2626" }}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3 flex-1">
            <Icon className={`${config.color} h-5 w-5 mt-1 ${config.spin && "animate-spin"}`} />
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm text-gray-900 truncate">{task.instruction}</p>
              <div className="flex gap-2 mt-1 flex-wrap">
                <Badge variant="outline" className="text-xs">{task.instruction_type}</Badge>
                <Badge variant="outline" className="text-xs">{task.entity_name}</Badge>
              </div>
            </div>
          </div>
          <button
            onClick={() => setExpanded(!expanded)}
            className="ml-2 p-1 hover:bg-gray-200 rounded"
          >
            {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </button>
        </div>
      </CardHeader>

      {expanded && (
        <CardContent className="space-y-3 text-xs">
          <div>
            <p className="text-gray-600 font-medium">Status</p>
            <p className={`${config.color} font-semibold`}>{config.label}</p>
          </div>

          {task.executed_at && (
            <div>
              <p className="text-gray-600 font-medium">Executed</p>
              <p className="text-gray-700">{format(parseISO(task.executed_at), "PPpp")}</p>
            </div>
          )}

          {task.result && (
            <div>
              <p className="text-gray-600 font-medium">Result</p>
              <pre className="bg-white p-2 rounded border text-[10px] overflow-x-auto max-h-32 overflow-y-auto">
                {JSON.stringify(task.result, null, 2)}
              </pre>
            </div>
          )}

          {task.error && (
            <div>
              <p className="text-gray-600 font-medium">Error</p>
              <p className="text-red-600 bg-white p-2 rounded border">{task.error}</p>
            </div>
          )}

          <div className="text-gray-500 border-t pt-2">
            <p>ID: {task.id}</p>
            <p>Created: {format(parseISO(task.created_date), "PPpp")}</p>
          </div>
        </CardContent>
      )}
    </Card>
  );
}

export default function SuperagentTaskDashboard() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const data = await base44.entities.SuperagentInstruction.list('-updated_date', 100);
        setTasks(data || []);
      } catch (error) {
        console.error("Failed to fetch tasks:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchTasks();
    const interval = setInterval(fetchTasks, 5000);
    return () => clearInterval(interval);
  }, []);

  const filteredTasks = filter === "all" ? tasks : tasks.filter(t => t.status === filter);
  const statusCounts = {
    pending: tasks.filter(t => t.status === "pending").length,
    executing: tasks.filter(t => t.status === "executing").length,
    completed: tasks.filter(t => t.status === "completed").length,
    failed: tasks.filter(t => t.status === "failed").length
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-lg font-bold text-gray-900 mb-3">5S Portal Tasks</h2>
        
        {/* Status Summary */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
          {Object.entries(statusCounts).map(([status, count]) => (
            <button
              key={status}
              onClick={() => setFilter(filter === status ? "all" : status)}
              className={`p-3 rounded-lg border-2 transition-all ${
                filter === status ? "border-blue-500 bg-blue-50" : "border-gray-200 bg-white hover:border-gray-300"
              }`}
            >
              <p className="text-xs font-medium text-gray-600 capitalize">{status}</p>
              <p className="text-lg font-bold text-gray-900">{count}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Task List */}
      {loading ? (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
          <p className="ml-2 text-gray-600">Loading tasks...</p>
        </div>
      ) : filteredTasks.length === 0 ? (
        <Card className="bg-gray-50 border-dashed">
          <CardContent className="py-8 text-center">
            <Zap className="h-8 w-8 text-gray-400 mx-auto mb-2 opacity-50" />
            <p className="text-sm text-gray-600">
              {filter === "all" ? "No tasks yet" : `No ${filter} tasks`}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {filteredTasks.map(task => (
            <TaskCard key={task.id} task={task} />
          ))}
        </div>
      )}
    </div>
  );
}