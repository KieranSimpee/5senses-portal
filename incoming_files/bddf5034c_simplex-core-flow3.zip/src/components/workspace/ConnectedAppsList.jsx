import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Trash2, ExternalLink, CheckCircle, AlertCircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function ConnectedAppsList({ apps, onDelete }) {
  if (apps.length === 0) {
    return (
      <Card className="p-8 text-center">
        <AlertCircle className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
        <p className="text-muted-foreground">No apps connected yet</p>
        <p className="text-xs text-muted-foreground mt-1">Connect your Base44 apps to enable cross-app functionality</p>
      </Card>
    );
  }

  return (
    <div className="grid gap-4">
      {apps.map((app) => (
        <Card key={app.id} className="p-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="font-semibold text-foreground">{app.app_name}</h3>
                <Badge variant={app.status === 'connected' ? 'default' : 'outline'} className="text-xs">
                  {app.status === 'connected' ? (
                    <><CheckCircle className="w-3 h-3 mr-1" /> Connected</>
                  ) : (
                    <><AlertCircle className="w-3 h-3 mr-1" /> {app.status}</>
                  )}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground mb-2">ID: {app.app_id}</p>
              {app.last_sync && (
                <p className="text-xs text-muted-foreground">
                  Last synced: {formatDistanceToNow(new Date(app.last_sync), { addSuffix: true })}
                </p>
              )}
              {app.accessible_entities && app.accessible_entities.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1">
                  {app.accessible_entities.map((entity) => (
                    <Badge key={entity} variant="secondary" className="text-xs">
                      {entity}
                    </Badge>
                  ))}
                </div>
              )}
              {app.notes && (
                <p className="text-xs text-foreground mt-2 italic">"{app.notes}"</p>
              )}
            </div>
            <div className="flex items-center gap-2">
              {app.app_url && (
                <Button size="sm" variant="ghost" asChild>
                  <a href={app.app_url} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </Button>
              )}
              <Button
                size="sm"
                variant="ghost"
                className="text-destructive hover:text-destructive"
                onClick={() => onDelete(app.id)}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}