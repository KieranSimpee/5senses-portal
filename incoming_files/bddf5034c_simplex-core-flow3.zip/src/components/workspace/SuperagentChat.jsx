import React, { useState, useRef, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Send, Loader2, CheckCircle, AlertCircle, Clock } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

export default function SuperagentChat({ superagents, connectedApps }) {
  const [selectedAgent, setSelectedAgent] = useState(superagents[0]?.id || '');
  const [selectedApp, setSelectedApp] = useState(connectedApps[0]?.id || '');
  const [command, setCommand] = useState('');
  const [instructions, setInstructions] = useState([]);
  const [sending, setSending] = useState(false);
  const [executing, setExecuting] = useState({});
  const scrollRef = useRef(null);
  const { toast } = useToast();

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [instructions]);

  const handleSendCommand = async (e) => {
    e.preventDefault();
    if (!command.trim() || !selectedAgent || !selectedApp) {
      toast({ title: 'Please fill all fields', variant: 'destructive' });
      return;
    }

    setSending(true);
    try {
      const instruction = await base44.entities.SuperagentInstruction.create({
        superagent_id: selectedAgent,
        target_app_id: selectedApp,
        instruction: command,
        instruction_type: 'custom',
        status: 'pending'
      });

      setInstructions(prev => [...prev, instruction]);
      setCommand('');

      // Auto-execute instruction
      setTimeout(() => executeInstruction(instruction.id), 500);
    } catch (e) {
      toast({ title: 'Failed to send command', description: e.message, variant: 'destructive' });
    } finally {
      setSending(false);
    }
  };

  const executeInstruction = async (instructionId) => {
    setExecuting(prev => ({ ...prev, [instructionId]: true }));
    try {
      await base44.functions.invoke('executeSuperagentInstruction', { instructionId });
      
      // Refresh instruction to get updated status
      const updated = await base44.entities.SuperagentInstruction.get(instructionId);
      setInstructions(prev => prev.map(i => i.id === instructionId ? updated : i));

      if (updated.status === 'completed') {
        toast({ title: 'Command executed successfully!' });
      }
    } catch (e) {
      toast({ title: 'Execution failed', description: e.message, variant: 'destructive' });
    } finally {
      setExecuting(prev => ({ ...prev, [instructionId]: false }));
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'failed':
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      case 'executing':
        return <Loader2 className="w-4 h-4 text-primary animate-spin" />;
      default:
        return <Clock className="w-4 h-4 text-yellow-600" />;
    }
  };

  const agent = superagents.find(a => a.id === selectedAgent);
  const targetApp = connectedApps.find(a => a.id === selectedApp);

  return (
    <div className="space-y-4">
      {/* Control Panel */}
      <Card className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
          <div>
            <label className="text-xs font-semibold text-muted-foreground mb-1 block">Superagent</label>
            <Select value={selectedAgent} onValueChange={setSelectedAgent}>
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {superagents.map(a => (
                  <SelectItem key={a.id} value={a.id}>{a.app_name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground mb-1 block">Target App</label>
            <Select value={selectedApp} onValueChange={setSelectedApp}>
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {connectedApps.map(a => (
                  <SelectItem key={a.id} value={a.id}>{a.app_name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-xs font-semibold text-muted-foreground mb-1 block">Status</label>
            <div className="h-9 px-3 rounded-md border border-input bg-background flex items-center text-sm">
              {agent?.status === 'connected' ? (
                <span className="text-green-600 flex items-center gap-1">
                  <CheckCircle className="w-3 h-3" /> Connected
                </span>
              ) : (
                <span className="text-muted-foreground">Offline</span>
              )}
            </div>
          </div>
        </div>

        {/* Command Input */}
        <form onSubmit={handleSendCommand} className="flex gap-2">
          <Input
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            placeholder="Enter instruction for Superagent (e.g., 'Create new expense record for office supplies')"
            disabled={sending || !selectedAgent || !selectedApp}
          />
          <Button
            type="submit"
            disabled={sending || !selectedAgent || !selectedApp}
            className="gap-2"
          >
            {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            {sending ? 'Sending...' : 'Send'}
          </Button>
        </form>
      </Card>

      {/* Chat History */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto bg-card rounded-lg border border-border p-4 space-y-3 max-h-96"
      >
        {instructions.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-sm text-muted-foreground">No instructions sent yet</p>
          </div>
        ) : (
          instructions.map((instr) => (
            <div key={instr.id} className="space-y-2">
              {/* User Message */}
              <div className="flex justify-end">
                <div className="max-w-xs bg-primary text-primary-foreground rounded-lg px-3 py-2">
                  <p className="text-sm">{instr.instruction}</p>
                </div>
              </div>

              {/* Agent Response */}
              <div className="flex items-start gap-2">
                <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  {getStatusIcon(instr.status)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-semibold text-foreground">{agent?.app_name}</span>
                    <Badge variant="outline" className="text-xs">
                      {instr.status}
                    </Badge>
                    {instr.status === 'pending' && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-5 text-xs"
                        onClick={() => executeInstruction(instr.id)}
                        disabled={executing[instr.id]}
                      >
                        {executing[instr.id] ? (
                          <>
                            <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                            Executing...
                          </>
                        ) : (
                          'Execute'
                        )}
                      </Button>
                    )}
                  </div>
                  {instr.result && (
                    <p className="text-xs text-green-600 bg-green-50 p-2 rounded">
                      ✓ Success: {JSON.stringify(instr.result).substring(0, 100)}...
                    </p>
                  )}
                  {instr.error && (
                    <p className="text-xs text-red-600 bg-red-50 p-2 rounded">
                      ✗ Error: {instr.error}
                    </p>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}