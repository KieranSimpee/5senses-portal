import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { ExternalLink } from "lucide-react";
import { format, parseISO } from "date-fns";

export default function InvoiceDetailModal({ expense, open, onOpenChange }) {
  if (!expense) return null;

  const isCredit = expense.amount < 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg p-6">
        <DialogHeader className="pb-4 border-b">
          <DialogTitle style={{fontFamily:'Exo 2, sans-serif'}} className="text-lg">
            {expense.receipt_number || "Invoice"}
          </DialogTitle>
          <p className="text-xs text-gray-400 mt-1" style={{fontFamily:'Montserrat, sans-serif'}}>
            Line item from receipt
          </p>
        </DialogHeader>

        <div className="space-y-4 mt-6">
          {/* Description */}
          <Card className="border-[#e8e6fe]">
            <CardContent className="p-4">
              <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">Description</p>
              <p className="text-sm font-medium text-gray-800">{expense.product_name || expense.title}</p>
              {expense.length && <p className="text-xs text-gray-600 mt-1">Term: {expense.length}</p>}
            </CardContent>
          </Card>

          {/* Amount */}
          <Card className={`border-2 ${isCredit ? "border-orange-300 bg-orange-50" : "border-[#e8e6fe]"}`}>
            <CardContent className="p-4">
              <p className="text-xs text-gray-500 uppercase tracking-wide mb-2">
                {isCredit ? "💳 Credit / Refund" : "💰 Total Cost"}
              </p>
              <p className={`text-2xl font-bold ${isCredit ? "text-orange-600" : "text-[#5e50fb]"}`}>
                {isCredit ? "- " : ""}{expense.currency} {Math.abs(expense.amount || 0).toLocaleString(undefined, {minimumFractionDigits: 0})}
              </p>
              {expense.subtotal && (
                <p className="text-xs text-gray-600 mt-2">
                  Subtotal: {expense.currency} {(expense.subtotal || 0).toLocaleString(undefined, {minimumFractionDigits: 0})}
                </p>
              )}
              {expense.tax_amount !== undefined && expense.tax_amount > 0 && (
                <p className="text-xs text-gray-600">
                  Tax: {expense.currency} {(expense.tax_amount || 0).toLocaleString(undefined, {minimumFractionDigits: 0})}
                </p>
              )}
              {expense.icann_fee && (
                <p className="text-xs text-gray-600">
                  ICANN: {expense.currency} {(expense.icann_fee || 0).toLocaleString(undefined, {minimumFractionDigits: 0})}
                </p>
              )}
            </CardContent>
          </Card>

          {/* Renewal Date */}
          {expense.length && (
            <Card className="border-[#e8e6fe]">
              <CardContent className="p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">🔄 Renewal</p>
                <p className="text-sm text-gray-700">{expense.length}</p>
              </CardContent>
            </Card>
          )}

          {/* Metadata */}
          <Card className="border-[#e8e6fe]">
            <CardContent className="p-4">
              <div className="space-y-2 text-xs">
                {expense.date && <div><span className="text-gray-500">Date:</span> <span className="text-gray-700">{format(parseISO(expense.date), "d MMM yyyy")}</span></div>}
                {expense.vendor && <div><span className="text-gray-500">Vendor:</span> <span className="text-gray-700">{expense.vendor}</span></div>}
                {expense.status && <div><span className="text-gray-500">Status:</span> <span className="font-medium text-[#5e50fb]">{expense.status}</span></div>}
                {expense.payment_method && <div><span className="text-gray-500">Payment:</span> <span className="text-gray-700">{expense.payment_method}</span></div>}
              </div>
            </CardContent>
          </Card>

          {/* Notes */}
          {expense.notes && (
            <Card className="border-[#e8e6fe]">
              <CardContent className="p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wide mb-2">Notes</p>
                <p className="text-xs text-gray-700">{expense.notes}</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Receipt Link */}
        {expense.receipt_url && (
          <div className="mt-6 pt-4 border-t flex justify-end">
            <a href={expense.receipt_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-xs text-[#8c82fc] hover:text-[#5e50fb] font-medium">
              View Original Receipt <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}