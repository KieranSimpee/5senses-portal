import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Trash2, Edit, X, Check } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const emptyBank = {
  bank_name: "", account_name: "5SENSESBEAUTY LIMITED", account_number: "",
  currency: "HKD", type: "Current", entity: "5SENSESBEAUTY LIMITED", notes: "", balance: 0
};

const F = ({ label, children }) => (
  <div className="space-y-1.5">
    <Label className="text-xs font-bold text-gray-500 uppercase tracking-wide">{label}</Label>
    {children}
  </div>
);

export default function BankAccountsTab({ banks, onRefresh }) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyBank);
  const [saving, setSaving] = useState(false);

  const openAdd = () => { setEditing(null); setForm(emptyBank); setShowForm(true); };
  const openEdit = (b) => { setEditing(b); setForm({ ...b }); setShowForm(true); };

  const save = async () => {
    setSaving(true);
    if (editing) await base44.entities.BankAccount.update(editing.id, form);
    else await base44.entities.BankAccount.create(form);
    await onRefresh();
    setShowForm(false);
    setSaving(false);
  };

  const remove = async (id) => {
    if (confirm("Remove this bank account?")) {
      await base44.entities.BankAccount.delete(id);
      await onRefresh();
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <p className="text-sm text-gray-500" style={{fontFamily:'Montserrat, sans-serif'}}>{banks.length} account{banks.length !== 1 ? "s" : ""} on record</p>
        <Button onClick={openAdd} className="bg-[#8c82fc] hover:bg-[#5e50fb] text-white gap-2 font-semibold text-sm">
          <Plus className="w-4 h-4" /> Add Bank Account
        </Button>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {banks.map(b => (
          <Card key={b.id} className="border-[#e8e6fe]">
            <CardContent className="p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#e8e6fe] flex items-center justify-center text-xl">🏦</div>
                  <div>
                    <p className="font-bold text-sm text-[#1a1a1f]" style={{fontFamily:'Montserrat, sans-serif'}}>{b.bank_name}</p>
                    <p className="text-xs text-gray-400">{b.account_name}</p>
                  </div>
                </div>
                <div className="flex gap-1">
                  <button onClick={() => openEdit(b)} className="p-1.5 hover:bg-[#e8e6fe] rounded-lg transition-colors">
                    <Edit className="w-3.5 h-3.5 text-gray-400" />
                  </button>
                  <button onClick={() => remove(b.id)} className="p-1.5 hover:bg-red-50 rounded-lg transition-colors">
                    <Trash2 className="w-3.5 h-3.5 text-red-400" />
                  </button>
                </div>
              </div>
              <div className="space-y-1 text-xs" style={{fontFamily:'Montserrat, sans-serif'}}>
                {b.account_number && <div className="flex justify-between"><span className="text-gray-400">Account No.</span><span className="font-mono font-semibold">{b.account_number}</span></div>}
                <div className="flex justify-between"><span className="text-gray-400">Currency</span><span className="font-semibold">{b.currency}</span></div>
                <div className="flex justify-between"><span className="text-gray-400">Type</span><span className="font-semibold">{b.type}</span></div>
                {b.entity && <div className="flex justify-between"><span className="text-gray-400">Entity</span><span className="font-semibold">{b.entity}</span></div>}
                {b.notes && <p className="text-gray-400 pt-1 border-t border-gray-100 mt-1">{b.notes}</p>}
              </div>
            </CardContent>
          </Card>
        ))}
        {banks.length === 0 && (
          <div className="col-span-2 text-center py-10 text-gray-400 text-sm">
            No bank accounts yet. Click "Add Bank Account" to get started.
          </div>
        )}
      </div>

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle style={{fontFamily:'Exo 2, sans-serif'}}>{editing ? "Edit Bank Account" : "Add Bank Account"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <F label="Bank Name"><Input value={form.bank_name} onChange={e => setForm(f => ({...f, bank_name: e.target.value}))} placeholder="e.g. HSBC Hong Kong" /></F>
            <F label="Account Name"><Input value={form.account_name} onChange={e => setForm(f => ({...f, account_name: e.target.value}))} /></F>
            <F label="Account Number"><Input value={form.account_number || ""} onChange={e => setForm(f => ({...f, account_number: e.target.value}))} placeholder="e.g. 123-456789-001" /></F>
            <div className="grid grid-cols-2 gap-3">
              <F label="Currency">
                <Select value={form.currency} onValueChange={v => setForm(f => ({...f, currency: v}))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["HKD","USD","EUR","GBP","CNY"].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </F>
              <F label="Type">
                <Select value={form.type} onValueChange={v => setForm(f => ({...f, type: v}))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["Current","Savings","Multi-currency","Credit"].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </F>
            </div>
            <F label="Legal Entity"><Input value={form.entity || ""} onChange={e => setForm(f => ({...f, entity: e.target.value}))} placeholder="e.g. 5SENSESBEAUTY LIMITED" /></F>
            <F label="Notes"><Input value={form.notes || ""} onChange={e => setForm(f => ({...f, notes: e.target.value}))} placeholder="Optional notes" /></F>
            <div className="flex gap-3 pt-2">
              <Button onClick={save} disabled={saving} className="flex-1 bg-[#8c82fc] hover:bg-[#5e50fb]">
                {saving ? "Saving..." : editing ? "Update" : "Add Account"}
              </Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}