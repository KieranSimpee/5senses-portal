import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Edit, Trash2, Info, ExternalLink, Upload } from "lucide-react";
import { format, parseISO, differenceInDays } from "date-fns";

const CATS = ["Business Registration", "Audit", "License", "Domain", "Hosting", "Software", "Microsoft License", "Insurance", "Company Secretarial", "Tax", "MPF", "Other"];
const FREQS = ["Monthly", "Quarterly", "Bi-Annual", "Annual", "One-time"];
const STATUSES = ["Active", "Expired", "Pending Renewal", "Cancelled"];

const CAT_ICONS = {
  "Business Registration": "🏛️",
  "Audit": "📋",
  "License": "📜",
  "Domain": "🌐",
  "Hosting": "🖥️",
  "Software": "💾",
  "Microsoft License": "💻",
  "Insurance": "🛡️",
  "Company Secretarial": "📁",
  "Tax": "💰",
  "MPF": "👴",
  "Other": "📌",
};

const empty = { title: "", category: "Other", renewal_date: "", last_renewed: "", cost: 0, currency: "HKD", vendor: "", frequency: "Annual", status: "Active", notes: "", auto_renew: false, invoice_url: "" };

const F = ({ label, children }) => (
  <div className="space-y-1.5">
    <Label className="text-xs font-bold text-gray-500 uppercase tracking-wide">{label}</Label>
    {children}
  </div>
);

function getUrgency(renewal_date) {
  if (!renewal_date) return null;
  const days = differenceInDays(parseISO(renewal_date), new Date());
  if (days < 0) return { label: `${Math.abs(days)}d overdue`, color: "bg-red-100 text-red-700", border: "border-red-200 bg-red-50", dot: "bg-red-500" };
  if (days <= 30) return { label: `${days}d left`, color: "bg-red-100 text-red-700", border: "border-red-200", dot: "bg-red-400" };
  if (days <= 90) return { label: `${days}d left`, color: "bg-yellow-100 text-yellow-700", border: "border-yellow-200", dot: "bg-yellow-400" };
  return { label: `${days}d left`, color: "bg-green-100 text-green-700", border: "border-[#e8e6fe]", dot: "bg-green-400" };
}

export default function RenewalsTracker() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [catFilter, setCatFilter] = useState("All");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [detail, setDetail] = useState(null);

  useEffect(() => { load(); }, []);

  const load = async () => {
    const data = await base44.entities.RenewalItem.list("renewal_date").catch(() => []);
    setItems(data);
    setLoading(false);
  };

  const save = async () => {
    setSaving(true);
    if (editing) await base44.entities.RenewalItem.update(editing.id, form);
    else await base44.entities.RenewalItem.create(form);
    await load();
    setShowForm(false);
    setSaving(false);
  };

  const remove = async (id) => {
    if (confirm("Delete this renewal?")) {
      await base44.entities.RenewalItem.delete(id);
      await load();
    }
  };

  const filtered = catFilter === "All" ? items : items.filter(i => i.category === catFilter);
  const overdue = items.filter(i => i.renewal_date && differenceInDays(parseISO(i.renewal_date), new Date()) < 0);
  const dueSoon = items.filter(i => i.renewal_date && differenceInDays(parseISO(i.renewal_date), new Date()) >= 0 && differenceInDays(parseISO(i.renewal_date), new Date()) <= 30);
  const upcoming = items.filter(i => i.renewal_date && differenceInDays(parseISO(i.renewal_date), new Date()) > 30 && differenceInDays(parseISO(i.renewal_date), new Date()) <= 90);

  // Total annual cost estimate
  const annualCostMap = { Monthly: 12, Quarterly: 4, "Bi-Annual": 2, Annual: 1, "One-time": 0 };
  const totalAnnual = items.filter(i => i.status === "Active").reduce((s, i) => s + ((i.cost || 0) * (annualCostMap[i.frequency] || 1)), 0);

  return (
    <div className="space-y-4">
      {/* Summary stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="border-[#e8e6fe]">
          <CardContent className="p-4">
            <p className="text-xs text-gray-400 mb-1">Total Tracked</p>
            <p className="text-xl font-extrabold text-[#1a1a1f]">{items.length}</p>
          </CardContent>
        </Card>
        <Card className={overdue.length > 0 ? "border-red-300 bg-red-50" : "border-[#e8e6fe]"}>
          <CardContent className="p-4">
            <p className="text-xs text-gray-400 mb-1">Overdue</p>
            <p className={`text-xl font-extrabold ${overdue.length > 0 ? "text-red-600" : "text-green-600"}`}>{overdue.length}</p>
          </CardContent>
        </Card>
        <Card className={dueSoon.length > 0 ? "border-yellow-300 bg-yellow-50" : "border-[#e8e6fe]"}>
          <CardContent className="p-4">
            <p className="text-xs text-gray-400 mb-1">Due in 30 days</p>
            <p className={`text-xl font-extrabold ${dueSoon.length > 0 ? "text-yellow-600" : "text-[#1a1a1f]"}`}>{dueSoon.length}</p>
          </CardContent>
        </Card>
        <Card className="border-[#e8e6fe]">
          <CardContent className="p-4">
            <p className="text-xs text-gray-400 mb-1">Est. Annual Cost</p>
            <p className="text-xl font-extrabold text-[#5e50fb]">HKD {totalAnnual.toLocaleString()}</p>
          </CardContent>
        </Card>
      </div>

      {/* Urgent alerts */}
      {(overdue.length > 0 || dueSoon.length > 0) && (
        <div className="space-y-2">
          {[...overdue, ...dueSoon].map(i => {
            const u = getUrgency(i.renewal_date);
            return (
              <Card key={i.id} className={`border ${u.border}`}>
                <CardContent className="p-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-base">{CAT_ICONS[i.category] || "📌"}</span>
                    <div>
                      <p className="font-bold text-sm text-[#1a1a1f]">{i.title}</p>
                      <p className="text-xs text-gray-500">{i.category} · {i.vendor} · Renews {i.renewal_date ? format(parseISO(i.renewal_date), "d MMM yyyy") : "—"}</p>
                    </div>
                  </div>
                  <Badge className={`font-bold border-0 text-xs ${u.color}`}>{u.label}</Badge>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2">
          {["All", ...CATS].map(c => (
            <button key={c} onClick={() => setCatFilter(c)}
              className={`px-3 py-1 rounded-full text-xs font-bold border transition-all ${catFilter === c ? "bg-[#8c82fc] text-white border-[#8c82fc]" : "text-gray-500 border-gray-200 hover:border-[#8c82fc]"}`}
              style={{ fontFamily: "Montserrat, sans-serif" }}>{c}</button>
          ))}
        </div>
        <Button onClick={() => { setEditing(null); setForm(empty); setShowForm(true); }} className="bg-[#8c82fc] hover:bg-[#5e50fb] text-white gap-2 font-semibold">
          <Plus className="w-4 h-4" /> Add Renewal
        </Button>
      </div>

      {/* Renewals list */}
      {loading ? <p className="text-center text-gray-400 py-8 text-sm">Loading...</p> : (
        <div className="space-y-2">
          {filtered.map(i => {
            const u = getUrgency(i.renewal_date);
            return (
              <Card key={i.id} className={`border ${u?.border || "border-[#e8e6fe]"}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <div className="w-9 h-9 rounded-lg bg-[#f5f4ff] flex items-center justify-center text-lg flex-shrink-0">{CAT_ICONS[i.category] || "📌"}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <p className="font-bold text-sm text-[#1a1a1f]" style={{ fontFamily: "Montserrat, sans-serif" }}>{i.title}</p>
                          {i.auto_renew && <span className="text-[10px] bg-blue-100 text-blue-600 px-1.5 py-0.5 rounded font-semibold">AUTO</span>}
                        </div>
                        <div className="flex flex-wrap gap-3 text-xs text-gray-500">
                          <span>{i.category}</span>
                          {i.vendor && <span>· {i.vendor}</span>}
                          <span>· {i.frequency}</span>
                          {i.cost > 0 && <span className="font-semibold text-[#5e50fb]">· {i.currency} {i.cost.toLocaleString()}</span>}
                        </div>
                        <div className="flex flex-wrap gap-3 text-xs text-gray-400 mt-1">
                          <span>Renews: <span className="font-semibold text-[#1a1a1f]">{i.renewal_date ? format(parseISO(i.renewal_date), "d MMM yyyy") : "—"}</span></span>
                          {i.last_renewed && <span>Last: {format(parseISO(i.last_renewed), "d MMM yyyy")}</span>}
                        </div>
                        {i.notes && <p className="text-xs text-gray-400 mt-1 italic">{i.notes}</p>}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2 flex-shrink-0">
                      {u && <Badge className={`font-bold border-0 text-xs ${u.color}`}>{u.label}</Badge>}
                      <Badge className={`text-xs border-0 ${i.status === "Active" ? "bg-green-100 text-green-700" : i.status === "Expired" ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-500"}`}>{i.status}</Badge>
                      <div className="flex gap-1 mt-1">
                        <button onClick={() => setDetail(i)} className="p-1 hover:bg-[#e8e6fe] rounded" title="View details"><Info className="w-3.5 h-3.5 text-[#8c82fc]" /></button>
                        <button onClick={() => { setEditing(i); setForm({ ...i }); setShowForm(true); }} className="p-1 hover:bg-[#e8e6fe] rounded"><Edit className="w-3.5 h-3.5 text-gray-400" /></button>
                        <button onClick={() => remove(i.id)} className="p-1 hover:bg-red-50 rounded"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
          {filtered.length === 0 && <p className="text-center text-gray-400 py-8 text-sm">No renewals found</p>}
        </div>
      )}

      {/* Detail dialog */}
      <Dialog open={!!detail} onOpenChange={() => setDetail(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle style={{ fontFamily: "Exo 2, sans-serif" }}>Renewal Details</DialogTitle></DialogHeader>
          {detail && (() => {
            const u = getUrgency(detail.renewal_date);
            const annualCostMap = { Monthly: 12, Quarterly: 4, "Bi-Annual": 2, Annual: 1, "One-time": 0 };
            const annualCost = (detail.cost || 0) * (annualCostMap[detail.frequency] || 1);
            return (
              <div className="space-y-4 py-2">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-[#f5f4ff] flex items-center justify-center text-2xl">{CAT_ICONS[detail.category] || "📌"}</div>
                  <div>
                    <p className="font-extrabold text-[#1a1a1f] text-base" style={{ fontFamily: "Exo 2, sans-serif" }}>{detail.title}</p>
                    <p className="text-xs text-gray-400">{detail.category}{detail.vendor ? ` · ${detail.vendor}` : ""}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-[#f5f4ff] rounded-xl p-3">
                    <p className="text-[10px] text-gray-400 uppercase font-bold mb-1">Next Renewal</p>
                    <p className="font-bold text-sm text-[#1a1a1f]">{detail.renewal_date ? format(parseISO(detail.renewal_date), "d MMM yyyy") : "—"}</p>
                    {u && <Badge className={`text-[10px] border-0 mt-1 ${u.color}`}>{u.label}</Badge>}
                  </div>
                  <div className="bg-[#f5f4ff] rounded-xl p-3">
                    <p className="text-[10px] text-gray-400 uppercase font-bold mb-1">Cost</p>
                    <p className="font-bold text-sm text-[#5e50fb]">{detail.currency} {(detail.cost || 0).toLocaleString()}</p>
                    <p className="text-[10px] text-gray-400 mt-0.5">{detail.frequency}</p>
                  </div>
                  {detail.last_renewed && (
                    <div className="bg-[#f5f4ff] rounded-xl p-3">
                      <p className="text-[10px] text-gray-400 uppercase font-bold mb-1">Last Renewed</p>
                      <p className="font-bold text-sm text-[#1a1a1f]">{format(parseISO(detail.last_renewed), "d MMM yyyy")}</p>
                    </div>
                  )}
                  {annualCost > 0 && (
                    <div className="bg-[#f5f4ff] rounded-xl p-3">
                      <p className="text-[10px] text-gray-400 uppercase font-bold mb-1">Est. Annual Cost</p>
                      <p className="font-bold text-sm text-[#5e50fb]">{detail.currency} {annualCost.toLocaleString()}</p>
                    </div>
                  )}
                </div>

                <div className="flex flex-wrap gap-2">
                  <Badge className={`text-xs border-0 ${detail.status === "Active" ? "bg-green-100 text-green-700" : detail.status === "Expired" ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-500"}`}>{detail.status}</Badge>
                  {detail.auto_renew && <Badge className="text-xs border-0 bg-blue-100 text-blue-600">Auto-renew</Badge>}
                </div>

                {detail.notes && <p className="text-xs text-gray-500 italic">{detail.notes}</p>}

                {detail.invoice_url && (
                  <a href={detail.invoice_url} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-2 text-xs font-semibold text-[#8c82fc] hover:underline">
                    <ExternalLink className="w-3.5 h-3.5" />
                    View Invoice / Receipt
                  </a>
                )}

                <div className="flex gap-2 pt-1">
                  <Button size="sm" onClick={() => { setDetail(null); setEditing(detail); setForm({ ...detail }); setShowForm(true); }} variant="outline" className="flex-1">Edit</Button>
                  <Button size="sm" onClick={() => setDetail(null)} className="flex-1 bg-[#8c82fc] hover:bg-[#5e50fb]">Close</Button>
                </div>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      {/* Form dialog */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle style={{ fontFamily: "Exo 2, sans-serif" }}>{editing ? "Edit Renewal" : "Add Renewal"}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <F label="Title"><Input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} /></F>
            <div className="grid grid-cols-2 gap-3">
              <F label="Category">
                <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{CATS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </F>
              <F label="Frequency">
                <Select value={form.frequency} onValueChange={v => setForm(f => ({ ...f, frequency: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{FREQS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </F>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <F label="Renewal Date"><Input type="date" value={form.renewal_date || ""} onChange={e => setForm(f => ({ ...f, renewal_date: e.target.value }))} /></F>
              <F label="Last Renewed"><Input type="date" value={form.last_renewed || ""} onChange={e => setForm(f => ({ ...f, last_renewed: e.target.value }))} /></F>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <F label="Cost"><Input type="number" value={form.cost || ""} onChange={e => setForm(f => ({ ...f, cost: parseFloat(e.target.value) || 0 }))} /></F>
              <F label="Currency">
                <Select value={form.currency} onValueChange={v => setForm(f => ({ ...f, currency: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="HKD">HKD</SelectItem><SelectItem value="USD">USD</SelectItem><SelectItem value="EUR">EUR</SelectItem></SelectContent>
                </Select>
              </F>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <F label="Vendor"><Input value={form.vendor || ""} onChange={e => setForm(f => ({ ...f, vendor: e.target.value }))} /></F>
              <F label="Status">
                <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </F>
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" id="auto_renew" checked={form.auto_renew || false} onChange={e => setForm(f => ({ ...f, auto_renew: e.target.checked }))} className="w-4 h-4 rounded accent-[#8c82fc]" />
              <label htmlFor="auto_renew" className="text-xs font-semibold text-gray-600">Auto-renews</label>
            </div>
            <F label="Invoice / Receipt URL">
              <div className="flex gap-2">
                <Input value={form.invoice_url || ""} onChange={e => setForm(f => ({ ...f, invoice_url: e.target.value }))} placeholder="Paste URL or upload" className="flex-1" />
                {form.invoice_url && (
                  <a href={form.invoice_url} target="_blank" rel="noopener noreferrer" className="p-2 border rounded-md hover:bg-[#e8e6fe]">
                    <ExternalLink className="w-4 h-4 text-[#8c82fc]" />
                  </a>
                )}
              </div>
              <label className="flex items-center gap-2 mt-1 cursor-pointer text-xs text-[#8c82fc] font-semibold hover:underline">
                <Upload className="w-3.5 h-3.5" />
                Upload file
                <input type="file" className="hidden" onChange={async (ev) => {
                  const file = ev.target.files[0];
                  if (!file) return;
                  const { file_url } = await base44.integrations.Core.UploadFile({ file });
                  setForm(f => ({ ...f, invoice_url: file_url }));
                }} />
              </label>
            </F>
            <F label="Notes"><Input value={form.notes || ""} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} /></F>
            <div className="flex gap-3 pt-2">
              <Button onClick={save} disabled={saving} className="flex-1 bg-[#8c82fc] hover:bg-[#5e50fb]">{saving ? "Saving..." : editing ? "Update" : "Add"}</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}