import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { base44 } from '@/api/base44Client';
import { Send, Loader2, X } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

export default function ComposeEmail({ open, onClose, account = 'me' }) {
  const [to, setTo] = useState('');
  const [cc, setCc] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);
  const { toast } = useToast();

  const handleSend = async () => {
    if (!to.trim() || !subject.trim() || !body.trim()) {
      toast({
        title: 'Missing fields',
        description: 'Please fill in recipient, subject, and message body.',
        variant: 'destructive'
      });
      return;
    }

    setSending(true);
    try {
      await base44.functions.invoke('outlookSendEmail', {
        to: to.trim(),
        cc: cc.trim() || undefined,
        subject: subject.trim(),
        body: body.trim(),
        account
      });
      toast({
        title: 'Email sent!',
        description: 'Your message has been sent successfully.'
      });
      setTo('');
      setCc('');
      setSubject('');
      setBody('');
      onClose();
    } catch (e) {
      toast({
        title: 'Failed to send',
        description: e.message,
        variant: 'destructive'
      });
    }
    setSending(false);
  };

  const handleClose = () => {
    if (!sending) onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Compose Email</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1 text-foreground">To</label>
            <Input
              placeholder="recipient@example.com"
              value={to}
              onChange={e => setTo(e.target.value)}
              disabled={sending}
              className="text-sm"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1 text-foreground">CC (optional)</label>
            <Input
              placeholder="cc@example.com"
              value={cc}
              onChange={e => setCc(e.target.value)}
              disabled={sending}
              className="text-sm"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1 text-foreground">Subject</label>
            <Input
              placeholder="Email subject"
              value={subject}
              onChange={e => setSubject(e.target.value)}
              disabled={sending}
              className="text-sm"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1 text-foreground">Message</label>
            <Textarea
              placeholder="Write your email..."
              value={body}
              onChange={e => setBody(e.target.value)}
              disabled={sending}
              className="min-h-[200px] text-sm"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose} disabled={sending}>
            Cancel
          </Button>
          <Button onClick={handleSend} disabled={sending || !to.trim() || !subject.trim() || !body.trim()}>
            {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            Send
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}