import { useState } from "react";
import { Outlet, NavLink } from "react-router-dom";
import { Home, ShieldCheck, DollarSign, Users, Sparkles, Wrench, Menu, FileText, Zap, Mail, AlertCircle, Lock, NotebookPen } from "lucide-react";

const NAV = [
  { to: "/", icon: Home, label: "Home" },
  { to: "/finance", icon: DollarSign, label: "Finance" },
  { to: "/compliance", icon: AlertCircle, label: "Compliance" },
  { to: "/hr", icon: Users, label: "HR" },
  { to: "/documents", icon: FileText, label: "Documents" },
  { to: "/brand", icon: Sparkles, label: "Brand" },
  { to: "/notes", icon: NotebookPen, label: "Notes" },
  { to: "/vault", icon: Lock, label: "Vault" },
  { to: "/inbox", icon: Mail, label: "Inbox" },
  { to: "/tools", icon: Wrench, label: "Tools" },
  { to: "/admin", icon: ShieldCheck, label: "Admin" },
  { to: "/workspace-hub", icon: Zap, label: "Workspace Hub" },
];

export default function Layout() {
  const [open, setOpen] = useState(false);
  return (
    <div className="min-h-screen bg-[#f5f4ff] flex">
      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-40 w-56 bg-white border-r border-[#e8e6fe] flex flex-col transition-transform duration-200 ${open ? "translate-x-0" : "-translate-x-full"} md:translate-x-0`}>
        <div className="px-5 py-5 border-b border-[#e8e6fe]">
          <p className="text-lg font-extrabold text-[#5e50fb]" style={{fontFamily:'Exo 2, sans-serif'}}>5S Portal</p>
          <p className="text-[10px] text-gray-400 font-semibold tracking-widest" style={{fontFamily:'Montserrat, sans-serif'}}>SIMPLEX-ITY · 5SENSESBEAUTY</p>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {NAV.map(({ to, icon: Icon, label }) => (
            <NavLink key={to} to={to} end={to === "/"} onClick={() => setOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                  isActive ? "bg-[#8c82fc] text-white" : "text-gray-500 hover:bg-[#e8e6fe] hover:text-[#5e50fb]"
                }`
              }
              style={{fontFamily:'Montserrat, sans-serif'}}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="px-5 py-4 border-t border-[#e8e6fe]">
          <p className="text-[10px] text-gray-300 font-semibold" style={{fontFamily:'Montserrat, sans-serif'}}>© 2026 5SENSESBEAUTY LIMITED</p>
        </div>
      </aside>

      {/* Mobile overlay */}
      {open && <div className="fixed inset-0 z-30 bg-black/20 md:hidden" onClick={() => setOpen(false)} />}

      {/* Main */}
      <div className="flex-1 md:ml-56 flex flex-col min-h-screen">
        <header className="sticky top-0 z-20 bg-white border-b border-[#e8e6fe] px-4 py-3 flex items-center gap-3 md:hidden">
          <button onClick={() => setOpen(true)} className="p-1.5 rounded-lg hover:bg-[#e8e6fe]">
            <Menu className="w-5 h-5 text-[#8c82fc]" />
          </button>
          <p className="font-extrabold text-[#5e50fb]" style={{fontFamily:'Exo 2, sans-serif'}}>5S Portal</p>
        </header>
        <main className="flex-1 p-5 md:p-8 max-w-7xl mx-auto w-full">
          <Outlet />
        </main>
      </div>
    </div>
  );
}