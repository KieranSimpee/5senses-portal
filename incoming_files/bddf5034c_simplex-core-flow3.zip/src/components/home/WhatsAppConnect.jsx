import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MessageCircle, Copy, CheckCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

export default function PortalConnect() {
  const [whatsappUrl, setWhatsappUrl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const handleConnect = async () => {
    setLoading(true);
    try {
      const url = base44.agents.getWhatsAppConnectURL('simpee');
      setWhatsappUrl(url);
    } catch (e) {
      toast({ title: 'Failed to get WhatsApp URL', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(whatsappUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return null;













































}