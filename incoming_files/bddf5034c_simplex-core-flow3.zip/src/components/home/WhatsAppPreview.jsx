import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MessageCircle, CheckCircle, AlertCircle, Clock, Zap } from 'lucide-react';

export default function SimpeeNoticeBoard() {
  const [instructions, setInstructions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchInstructions = async () => {
      try {
        const data = await base44.entities.SuperagentInstruction.list('-created_date', 5);
        setInstructions(data || []);
      } catch (e) {
        console.error('Failed to fetch instructions:', e);
      } finally {
        setLoading(false);
      }
    };

    fetchInstructions();
    const interval = setInterval(fetchInstructions, 3000);
    return () => clearInterval(interval);
  }, []);

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'failed':
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      case 'executing':
        return <Zap className="w-4 h-4 text-primary animate-pulse" />;
      default:
        return <Clock className="w-4 h-4 text-yellow-600" />;
    }
  };

  if (loading) {
    return (
      <Card className="p-6 bg-gradient-to-br from-green-50 to-green-100 border-green-200">
        <div className="flex items-center gap-2 mb-4">
          <MessageCircle className="w-5 h-5 text-green-600" />
          <h3 className="font-semibold text-green-900">Simpee Notice Board</h3>
        </div>
        <div className="space-y-2">
          <div className="h-16 bg-white/50 rounded animate-pulse"></div>
          <div className="h-16 bg-white/50 rounded animate-pulse"></div>
        </div>
      </Card>);

  }

  return null;





























































}