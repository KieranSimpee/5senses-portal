import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { differenceInDays, parseISO, format } from 'date-fns';

export default function ComplianceWidget() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCompliance();
  }, []);

  const loadCompliance = async () => {
    try {
      const data = await base44.entities.ComplianceItem.list().catch(() => []);
      const today = new Date();
      const urgent = data.filter(c => {
        if (c.status === 'Completed') return false;
        const daysUntil = differenceInDays(parseISO(c.due_date), today);
        return daysUntil <= 30 && daysUntil >= -365;
      }).sort((a, b) => new Date(a.due_date) - new Date(b.due_date)).slice(0, 5);
      setItems(urgent);
    } catch (error) {
      console.error('Failed to load compliance:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <p className="text-xs text-gray-400">Loading...</p>;
  if (items.length === 0) return null;

  return (
    <Card className="border-[#e8e6fe]">
      <CardContent className="p-4">
        <h3 className="font-bold text-sm text-[#1a1a1f] mb-3">📋 Compliance Checklist</h3>
        <div className="space-y-2">
          {items.map(item => {
            const daysLeft = differenceInDays(parseISO(item.due_date), new Date());
            const isOverdue = daysLeft < 0;
            const isUrgent = daysLeft <= 7;
            
            return (
              <div key={item.id} className={`p-2.5 rounded text-xs ${isOverdue ? 'bg-red-50 border border-red-200' : isUrgent ? 'bg-yellow-50 border border-yellow-200' : 'bg-[#f5f4ff] border border-[#e8e6fe]'}`}>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <p className={`font-semibold ${isOverdue ? 'text-red-800' : isUrgent ? 'text-yellow-800' : 'text-[#1a1a1f]'}`}>
                      {item.title}
                    </p>
                    <p className={`text-[11px] ${isOverdue ? 'text-red-600' : isUrgent ? 'text-yellow-600' : 'text-gray-500'}`}>
                      {item.category}
                    </p>
                  </div>
                  <Badge className={`text-xs border-0 whitespace-nowrap ${isOverdue ? 'bg-red-100 text-red-700' : isUrgent ? 'bg-yellow-100 text-yellow-700' : 'bg-[#e8e6fe] text-[#5e50fb]'}`}>
                    {isOverdue ? `${Math.abs(daysLeft)}d overdue` : `${daysLeft}d left`}
                  </Badge>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}