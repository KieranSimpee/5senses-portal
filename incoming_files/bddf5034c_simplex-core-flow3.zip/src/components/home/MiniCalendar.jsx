import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay, isSameDay, isToday, parseISO, addMonths, subMonths } from "date-fns";

export default function MiniCalendar() {
  const [current, setCurrent] = useState(new Date());
  const [events, setEvents] = useState([]);
  const [renewals, setRenewals] = useState([]);

  useEffect(() => {
    Promise.all([
      base44.entities.CalendarEvent.list().catch(() => []),
      base44.entities.RenewalItem.list().catch(() => []),
    ]).then(([ev, rn]) => { setEvents(ev); setRenewals(rn); });
  }, []);

  const monthStart = startOfMonth(current);
  const monthEnd = endOfMonth(current);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });
  const startPad = getDay(monthStart); // 0=Sun

  const getEventsForDay = (day) => {
    const calEvents = events.filter(e => e.start_date && isSameDay(parseISO(e.start_date), day));
    const renewalEvents = renewals.filter(r => r.renewal_date && isSameDay(parseISO(r.renewal_date), day));
    return { calEvents, renewalEvents };
  };

  const DOW = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];

  return (
    <div className="bg-white rounded-2xl border border-[#e8e6fe] p-5">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-base font-extrabold text-[#1a1a1f]" style={{fontFamily:'Exo 2, sans-serif'}}>
          {format(current, "MMMM yyyy")}
        </h2>
        <div className="flex gap-1">
          <button onClick={() => setCurrent(d => subMonths(d, 1))} className="p-1.5 rounded-lg hover:bg-[#e8e6fe] transition-colors">
            <ChevronLeft className="w-4 h-4 text-[#8c82fc]" />
          </button>
          <button onClick={() => setCurrent(new Date())} className="px-2 py-1 rounded-lg hover:bg-[#e8e6fe] text-[10px] font-bold text-[#8c82fc] transition-colors" style={{fontFamily:'Montserrat, sans-serif'}}>
            Today
          </button>
          <button onClick={() => setCurrent(d => addMonths(d, 1))} className="p-1.5 rounded-lg hover:bg-[#e8e6fe] transition-colors">
            <ChevronRight className="w-4 h-4 text-[#8c82fc]" />
          </button>
        </div>
      </div>

      {/* Day headers */}
      <div className="grid grid-cols-7 mb-1">
        {DOW.map(d => (
          <div key={d} className="text-center text-[10px] font-bold text-gray-400 py-1" style={{fontFamily:'Montserrat, sans-serif'}}>{d}</div>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-7 gap-0.5">
        {/* Padding */}
        {Array.from({ length: startPad }).map((_, i) => (
          <div key={`pad-${i}`} className="h-10" />
        ))}
        {/* Days */}
        {days.map(day => {
          const { calEvents, renewalEvents } = getEventsForDay(day);
          const hasEvent = calEvents.length > 0;
          const hasRenewal = renewalEvents.length > 0;
          const today = isToday(day);
          return (
            <div key={day.toISOString()} className={`h-10 flex flex-col items-center justify-center rounded-lg relative cursor-default transition-colors
              ${today ? "bg-[#8c82fc] text-white" : "hover:bg-[#f5f4ff]"}`}>
              <span className={`text-xs font-semibold ${today ? "text-white" : "text-[#1a1a1f]"}`} style={{fontFamily:'Montserrat, sans-serif'}}>
                {format(day, "d")}
              </span>
              {(hasEvent || hasRenewal) && (
                <div className="flex gap-0.5 mt-0.5">
                  {hasEvent && <div className={`w-1 h-1 rounded-full ${today ? "bg-white" : "bg-[#8c82fc]"}`} />}
                  {hasRenewal && <div className={`w-1 h-1 rounded-full ${today ? "bg-yellow-200" : "bg-yellow-400"}`} />}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Legend */}
      <div className="flex gap-4 mt-3 pt-3 border-t border-[#e8e6fe]">
        <div className="flex items-center gap-1.5 text-[10px] text-gray-400" style={{fontFamily:'Montserrat, sans-serif'}}>
          <div className="w-2 h-2 rounded-full bg-[#8c82fc]" />Event
        </div>
        <div className="flex items-center gap-1.5 text-[10px] text-gray-400" style={{fontFamily:'Montserrat, sans-serif'}}>
          <div className="w-2 h-2 rounded-full bg-yellow-400" />Renewal
        </div>
      </div>
    </div>
  );
}