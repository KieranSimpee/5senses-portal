import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { differenceInDays, parseISO } from 'date-fns';

export default function StatsStrip() {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const [expenses, renewals, compliance] = await Promise.all([
        base44.entities.Expense.list().catch(() => []),
        base44.entities.RenewalItem.list().catch(() => []),
        base44.entities.ComplianceItem.list().catch(() => [])
      ]);

      const total = expenses.reduce((s, e) => s + (e.amount || 0), 0);
      const pending = expenses.filter(e => e.status === 'Pending' || e.status === 'pending').length;
      const renewalsUrgent = renewals.filter(r => {
        const days = differenceInDays(parseISO(r.renewal_date), new Date());
        return days >= 0 && days <= 30;
      }).length;
      const complianceOverdue = compliance.filter(c => c.status === 'Overdue').length;

      setStats({ total, pending, renewalsUrgent, complianceOverdue });
    } catch (error) {
      console.error('Failed to load stats:', error);
    }
  };

  if (!stats) return null;

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
      <Card className="border-[#e8e6fe]">
        <div className="p-3">
          <p className="text-xs text-gray-400">Total Spent</p>
          <p className="text-lg font-extrabold text-[#5e50fb]">HKD {stats.total.toLocaleString()}</p>
        </div>
      </Card>
      <Card className={`border-2 ${stats.pending > 0 ? 'border-yellow-300' : 'border-[#e8e6fe]'}`}>
        <div className="p-3">
          <p className={`text-xs ${stats.pending > 0 ? 'text-yellow-600 font-bold' : 'text-gray-400'}`}>Pending Approval</p>
          <p className={`text-lg font-extrabold ${stats.pending > 0 ? 'text-yellow-700' : 'text-[#1a1a1f]'}`}>{stats.pending}</p>
        </div>
      </Card>
      <Card className={`border-2 ${stats.renewalsUrgent > 0 ? 'border-orange-300' : 'border-[#e8e6fe]'}`}>
        <div className="p-3">
          <p className={`text-xs ${stats.renewalsUrgent > 0 ? 'text-orange-600 font-bold' : 'text-gray-400'}`}>Renewals Due</p>
          <p className={`text-lg font-extrabold ${stats.renewalsUrgent > 0 ? 'text-orange-700' : 'text-[#1a1a1f]'}`}>{stats.renewalsUrgent}</p>
        </div>
      </Card>
      <Card className={`border-2 ${stats.complianceOverdue > 0 ? 'border-red-300' : 'border-[#e8e6fe]'}`}>
        <div className="p-3">
          <p className={`text-xs ${stats.complianceOverdue > 0 ? 'text-red-600 font-bold' : 'text-gray-400'}`}>Overdue</p>
          <p className={`text-lg font-extrabold ${stats.complianceOverdue > 0 ? 'text-red-700' : 'text-[#1a1a1f]'}`}>{stats.complianceOverdue}</p>
        </div>
      </Card>
    </div>
  );
}