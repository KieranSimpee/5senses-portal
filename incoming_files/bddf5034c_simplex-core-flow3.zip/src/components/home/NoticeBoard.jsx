import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Trash2, Pin } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { format, parseISO, isPast } from "date-fns";

const TYPE_STYLES = {
  urgent:    "bg-red-50 border-red-300",
  important: "bg-yellow-50 border-yellow-300",
  normal:    "bg-[#f5f4ff] border-[#e8e6fe]",
  success:   "bg-green-50 border-green-300",
  info:      "bg-blue-50 border-blue-200",
};

const TYPE_BADGE = {
  urgent:    "bg-red-100 text-red-700",
  important: "bg-yellow-100 text-yellow-700",
  normal:    "bg-[#e8e6fe] text-[#5e50fb]",
  success:   "bg-green-100 text-green-700",
  info:      "bg-blue-100 text-blue-700",
};

const CAT_ICONS = { HR: "👥", Admin: "🏛️", Finance: "💰", General: "📋" };

const empty = { title: "", body: "", category: "General", priority: "normal", pinned: false, expires_on: "", posted_by: "Kieran", section: "" };

export default function NoticeBoard({ isAdmin }) {
  const [notices, setNotices] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    const data = await base44.entities.NoticeBoard.list("-created_date").catch(() => []);
    setNotices(data.filter(n => !n.expires_on || !isPast(parseISO(n.expires_on))));
  };

  useEffect(() => {
    load();
    // Real-time subscription — updates instantly when Simpee posts
    const unsubscribe = base44.entities.NoticeBoard.subscribe((event) => {
      if (event.type === "create") {
        setNotices(prev => {
          const n = event.data;
          if (!n.expires_on || !isPast(parseISO(n.expires_on))) {
            return [n, ...prev];
          }
          return prev;
        });
      } else if (event.type === "update") {
        setNotices(prev => prev.map(n => n.id === event.id ? event.data : n));
      } else if (event.type === "delete") {
        setNotices(prev => prev.filter(n => n.id !== event.id));
      }
    });
    return () => unsubscribe();
  }, []);

  const save = async () => {
    setSaving(true);
    await base44.entities.NoticeBoard.create(form);
    setShowForm(false); setSaving(false); setForm(empty);
  };

  const remove = async (id) => {
    if (confirm("Remove notice?")) { await base44.entities.NoticeBoard.delete(id); }
  };

  const sorted = [...notices].sort((a, b) => {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    const p = { urgent: 0, important: 1, normal: 2, info: 2, success: 2 };
    return (p[a.priority] ?? 2) - (p[b.priority] ?? 2);
  });

  return (
    <div className="bg-white rounded-2xl border border-[#e8e6fe] p-5 w-full">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-base font-extrabold text-[#1a1a1f]" style={{fontFamily:'Exo 2, sans-serif'}}>📋 Notice Board</h2>
        {isAdmin && (
          <Button size="sm" onClick={() => setShowForm(true)} className="bg-[#8c82fc] hover:bg-[#5e50fb] text-white gap-1 h-7 text-xs font-semibold">
            <Plus className="w-3 h-3" /> Post
          </Button>
        )}
      </div>

      {sorted.length === 0 && (
        <p className="text-center text-sm text-gray-400 py-6" style={{fontFamily:'Montserrat, sans-serif'}}>No notices yet</p>
      )}

      <div className="space-y-2 max-h-[480px] overflow-y-auto pr-1">
        {sorted.map(n => (
          <div key={n.id} className={`rounded-xl p-3 border relative ${n.pinned ? "bg-[#f0effe] border-[#8c82fc]" : TYPE_STYLES[n.priority] || TYPE_STYLES.normal}`}>
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-start gap-2 flex-1 min-w-0">
                <span className="text-sm mt-0.5">{CAT_ICONS[n.category] || "📌"}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    {n.pinned && <Pin className="w-3 h-3 text-[#8c82fc] flex-shrink-0" />}
                    <p className="text-sm font-bold text-[#1a1a1f]" style={{fontFamily:'Montserrat, sans-serif'}}>{n.title}</p>
                    <Badge className={`text-[10px] border-0 px-1.5 py-0 ${TYPE_BADGE[n.priority] || TYPE_BADGE.normal}`}>{n.priority}</Badge>
                  </div>
                  {n.body && <p className="text-xs text-gray-500 mt-1 leading-relaxed" style={{fontFamily:'Montserrat, sans-serif'}}>{n.body}</p>}
                  <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                    <span className="text-[10px] text-gray-400" style={{fontFamily:'Montserrat, sans-serif'}}>{n.category}</span>
                    {n.posted_by && <span className="text-[10px] bg-[#e8e6fe] text-[#5e50fb] font-semibold px-1.5 py-0.5 rounded-full">{n.posted_by}</span>}
                    {n.section && <span className="text-[10px] text-gray-400">· {n.section}</span>}
                    <span className="text-[10px] text-gray-300">· {n.created_date ? format(parseISO(n.created_date), "d MMM yyyy HH:mm") : "—"}</span>
                  </div>
                </div>
              </div>
              {isAdmin && (
                <button onClick={() => remove(n.id)} className="p-1 hover:bg-red-100 rounded flex-shrink-0">
                  <Trash2 className="w-3 h-3 text-red-400" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle style={{fontFamily:'Exo 2, sans-serif'}}>Post Notice</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            {[["Title","title","text"],["Body","body","text"],["Posted By","posted_by","text"],["Section","section","text"]].map(([label, key, type]) => (
              <div key={key} className="space-y-1.5">
                <Label className="text-xs font-bold text-gray-500 uppercase tracking-wide">{label}</Label>
                <Input type={type} value={form[key] || ""} onChange={e => setForm(f => ({...f, [key]: e.target.value}))} />
              </div>
            ))}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Category</Label>
                <Select value={form.category} onValueChange={v => setForm(f => ({...f, category: v}))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{["HR","Admin","Finance","General"].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Priority</Label>
                <Select value={form.priority} onValueChange={v => setForm(f => ({...f, priority: v}))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{["normal","important","urgent","success","info"].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 items-center">
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Expires On</Label>
                <Input type="date" value={form.expires_on || ""} onChange={e => setForm(f => ({...f, expires_on: e.target.value}))} />
              </div>
              <div className="flex items-center gap-2 mt-5">
                <input type="checkbox" id="pinned" checked={form.pinned} onChange={e => setForm(f => ({...f, pinned: e.target.checked}))} className="w-4 h-4 accent-[#8c82fc]" />
                <label htmlFor="pinned" className="text-xs font-semibold text-gray-600">Pin to top</label>
              </div>
            </div>
            <div className="flex gap-3 pt-2">
              <Button onClick={save} disabled={saving} className="flex-1 bg-[#8c82fc] hover:bg-[#5e50fb]">{saving ? "Posting..." : "Post Notice"}</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}