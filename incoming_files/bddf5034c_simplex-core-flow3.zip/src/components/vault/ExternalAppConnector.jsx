import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, Copy, Eye, EyeOff } from 'lucide-react';

const COMMON_APPS = [
  { name: 'Gmail', url: 'https://mail.google.com', category: 'Email' },
  { name: 'Google Drive', url: 'https://drive.google.com', category: 'Cloud Storage' },
  { name: 'Outlook', url: 'https://outlook.office.com', category: 'Email' },
  { name: 'OneDrive', url: 'https://onedrive.live.com', category: 'Cloud Storage' },
  { name: 'Shopify', url: 'https://admin.shopify.com', category: 'eCommerce' },
  { name: 'GitHub', url: 'https://github.com', category: 'Development' },
  { name: 'Google Analytics', url: 'https://analytics.google.com', category: 'Analytics' },
  { name: 'Xero', url: 'https://www.xero.com', category: 'Finance' },
];

export default function ExternalAppConnector({ vaultItem, onAutoFill }) {
  const [revealed, setRevealed] = useState(false);

  const handleQuickConnect = (app) => {
    window.open(app.url, '_blank');
    onAutoFill?.({
      service_name: app.name,
      url: app.url,
      category: app.category
    });
  };

  if (!vaultItem) {
    return (
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <h3 className="font-bold text-sm text-blue-900 mb-3">🔗 Quick App Access</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {COMMON_APPS.map(app => (
              <Button
                key={app.name}
                variant="outline"
                size="sm"
                onClick={() => handleQuickConnect(app)}
                className="text-xs h-auto py-2 flex flex-col items-center gap-1 border-blue-200 hover:bg-blue-100"
              >
                <span className="text-lg">
                  {app.name === 'Gmail' ? '📧'
                    : app.name === 'Google Drive' ? '☁️'
                    : app.name === 'Outlook' ? '📧'
                    : app.name === 'OneDrive' ? '☁️'
                    : app.name === 'Shopify' ? '🛒'
                    : app.name === 'GitHub' ? '⚙️'
                    : app.name === 'Google Analytics' ? '📊'
                    : '💼'}
                </span>
                {app.name}
              </Button>
            ))}
          </div>
          <p className="text-xs text-blue-700 mt-3">Click any app above to open & save credentials</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
      <div className="flex items-center justify-between">
        <div>
          <p className="font-semibold text-sm text-blue-900">{vaultItem.service_name}</p>
          {vaultItem.username && (
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs text-blue-700">Login:</span>
              <span className="text-xs font-mono bg-white px-2 py-0.5 rounded">
                {revealed ? vaultItem.username : '•'.repeat(vaultItem.username.length)}
              </span>
            </div>
          )}
        </div>
        <div className="flex gap-1">
          {vaultItem.url && (
            <a href={vaultItem.url} target="_blank" rel="noopener noreferrer" className="p-1 hover:bg-blue-100 rounded">
              <ExternalLink className="w-3.5 h-3.5 text-blue-600" />
            </a>
          )}
          {vaultItem.username && (
            <button onClick={() => setRevealed(!revealed)} className="p-1 hover:bg-blue-100 rounded">
              {revealed ? <EyeOff className="w-3.5 h-3.5 text-blue-600" /> : <Eye className="w-3.5 h-3.5 text-blue-600" />}
            </button>
          )}
          {vaultItem.password && (
            <button onClick={() => navigator.clipboard.writeText(vaultItem.password)} className="p-1 hover:bg-blue-100 rounded">
              <Copy className="w-3.5 h-3.5 text-blue-600" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}