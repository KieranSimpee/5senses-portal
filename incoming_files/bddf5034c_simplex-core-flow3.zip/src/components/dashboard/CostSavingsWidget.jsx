import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { TrendingDown, Zap } from 'lucide-react';

export default function CostSavingsWidget() {
  const [savings, setSavings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSavings();
  }, []);

  const loadSavings = async () => {
    try {
      const [expenses, renewals] = await Promise.all([
        base44.entities.Expense.list().catch(() => []),
        base44.entities.RenewalItem.list().catch(() => [])
      ]);

      const suggestions = [];

      // Duplicate vendor detection
      const vendorMap = {};
      expenses.forEach(e => {
        if (e.vendor) {
          vendorMap[e.vendor] = (vendorMap[e.vendor] || 0) + (e.amount || 0);
        }
      });

      const topVendors = Object.entries(vendorMap).sort((a, b) => b[1] - a[1]).slice(0, 2);
      topVendors.forEach(([vendor, total]) => {
        if (total > 10000) {
          suggestions.push({
            type: 'consolidation',
            text: `Consolidate ${vendor} services`,
            potential: Math.round(total * 0.1) // 10% savings estimate
          });
        }
      });

      // Unused subscriptions
      const msExpenses = expenses.filter(e => e.category === 'Microsoft Licenses').length;
      if (msExpenses > 3) {
        suggestions.push({
          type: 'audit',
          text: 'Audit unused Microsoft licenses',
          potential: 200
        });
      }

      setSavings(suggestions.slice(0, 3));
    } catch (error) {
      console.error('Failed to load savings:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="border-green-200 bg-green-50">
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-3">
          <TrendingDown className="w-5 h-5 text-green-600" />
          <h3 className="font-bold text-sm text-green-900">Cost Reduction Opportunities</h3>
        </div>

        {loading ? (
          <p className="text-xs text-green-600">Analyzing...</p>
        ) : savings.length === 0 ? (
          <p className="text-xs text-green-700">✓ No quick wins identified. Keep optimizing!</p>
        ) : (
          <div className="space-y-2">
            {savings.map((s, idx) => (
              <div key={idx} className="text-xs bg-white rounded p-2 border border-green-100">
                <p className="font-semibold text-green-900">{s.text}</p>
                <p className="text-green-700">Potential: HKD {s.potential.toLocaleString()}</p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}