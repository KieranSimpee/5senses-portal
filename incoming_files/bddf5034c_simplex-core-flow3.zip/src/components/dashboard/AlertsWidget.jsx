import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { AlertCircle, Clock, DollarSign } from 'lucide-react';
import { format, parseISO, differenceInDays } from 'date-fns';

export default function AlertsWidget() {
  const [alerts, setAlerts] = useState({ overdue: 0, upcoming: 0, pending: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAlerts();
  }, []);

  const loadAlerts = async () => {
    try {
      const [compliance, expenses, renewals] = await Promise.all([
        base44.entities.ComplianceItem.list().catch(() => []),
        base44.entities.Expense.list().catch(() => []),
        base44.entities.RenewalItem.list().catch(() => [])
      ]);

      const today = new Date();
      const overdue = compliance.filter(c => c.status === 'Overdue' || (new Date(c.due_date) < today && c.status !== 'Completed')).length;
      const upcoming = compliance.filter(c => {
        const daysLeft = differenceInDays(parseISO(c.due_date), today);
        return daysLeft > 0 && daysLeft <= 30 && c.status !== 'Completed';
      }).length;
      const pending = expenses.filter(e => e.status === 'Pending' || e.status === 'pending').length;

      setAlerts({ overdue, upcoming, pending });
    } catch (error) {
      console.error('Failed to load alerts:', error);
    } finally {
      setLoading(false);
    }
  };

  const severityColor = (count, threshold) => {
    if (count === 0) return 'text-green-600';
    if (count <= threshold) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="grid grid-cols-3 gap-3">
      <Card className="border-[#e8e6fe]">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className={`w-4 h-4 ${severityColor(alerts.overdue, 0)}`} />
            <span className="text-xs text-gray-500">Overdue</span>
          </div>
          <p className={`text-2xl font-bold ${severityColor(alerts.overdue, 0)}`}>{alerts.overdue}</p>
        </CardContent>
      </Card>

      <Card className="border-[#e8e6fe]">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <Clock className={`w-4 h-4 ${severityColor(alerts.upcoming, 5)}`} />
            <span className="text-xs text-gray-500">Due Soon</span>
          </div>
          <p className={`text-2xl font-bold ${severityColor(alerts.upcoming, 5)}`}>{alerts.upcoming}</p>
        </CardContent>
      </Card>

      <Card className="border-[#e8e6fe]">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className={`w-4 h-4 ${severityColor(alerts.pending, 5)}`} />
            <span className="text-xs text-gray-500">Pending Approval</span>
          </div>
          <p className={`text-2xl font-bold ${severityColor(alerts.pending, 5)}`}>{alerts.pending}</p>
        </CardContent>
      </Card>
    </div>
  );
}