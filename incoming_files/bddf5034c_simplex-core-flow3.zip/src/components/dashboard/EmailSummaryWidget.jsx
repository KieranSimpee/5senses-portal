import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Mail, AlertCircle, CheckCircle2, Clock } from 'lucide-react';

export default function EmailSummaryWidget() {
  const [emails, setEmails] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadEmails();
  }, []);

  const loadEmails = async () => {
    try {
      const result = await base44.functions.invoke('outlookGetEmails', { limit: 5 });
      setEmails(result.data?.emails || []);
    } catch (error) {
      console.error('Failed to load emails:', error);
    } finally {
      setLoading(false);
    }
  };

  const unreadCount = emails.filter(e => !e.isRead).length;

  return (
    <Card className="border-[#e8e6fe]">
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Mail className="w-5 h-5 text-[#8c82fc]" />
            <h3 className="font-bold text-sm text-[#1a1a1f]">Email Summary</h3>
          </div>
          {unreadCount > 0 && (
            <Badge className="bg-red-100 text-red-700 border-0">{unreadCount} Unread</Badge>
          )}
        </div>

        {loading ? (
          <p className="text-xs text-gray-400">Loading emails...</p>
        ) : emails.length === 0 ? (
          <p className="text-xs text-gray-400">No recent emails</p>
        ) : (
          <div className="space-y-2">
            {emails.slice(0, 3).map((email, idx) => (
              <div key={idx} className="text-xs border-l-2 border-[#e8e6fe] pl-2 py-1">
                <p className="font-semibold text-[#1a1a1f] truncate">{email.from}</p>
                <p className="text-gray-500 truncate">{email.subject}</p>
              </div>
            ))}
          </div>
        )}

        <button onClick={loadEmails} className="text-xs text-[#8c82fc] font-semibold mt-3 hover:underline">
          View all emails →
        </button>
      </CardContent>
    </Card>
  );
}