import React, { useState, useEffect } from "react";
import { ChevronDown, Save, X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

const FLOW_SECTIONS = [
  {
    id: "nav",
    title: "🧭 NAVIGATION (Sidebar)",
    current: "Home, Admin, Finance, HR, Brand, Documents, Tools",
    canEdit: true
  },
  {
    id: "home",
    title: "🏠 HOME",
    current: "Header, Renewal Alerts, Nav Cards (5), Mini Calendar, Notice Board",
    canEdit: true
  },
  {
    id: "admin",
    title: "🏛️ ADMIN",
    current: "Vault (credentials), Bank Accounts, Company Info",
    canEdit: true
  },
  {
    id: "finance",
    title: "💰 FINANCE",
    current: "Expenses (with Upload), Monthly Summary, Hosting, MS Licenses, Renewals",
    canEdit: true
  },
  {
    id: "hr",
    title: "👥 HR",
    current: "Contracts, Insurance, MPF, Payroll, Other — with expiry warnings & Upload button",
    canEdit: true
  },
  {
    id: "brand",
    title: "✨ BRAND",
    current: "SIMPLEX-ITY tab, 5SENSESBEAUTY tab, Documents, Upload button",
    canEdit: true
  },
  {
    id: "documents",
    title: "📄 DOCUMENTS",
    current: "Folder sidebar, Document cards, AI-powered upload → auto-create expenses",
    canEdit: true
  },
  {
    id: "tools",
    title: "🔧 TOOLS",
    current: "Built-in tools, Custom tools (add/edit/delete)",
    canEdit: true
  },
  {
    id: "vault",
    title: "🔐 VAULT",
    current: "Secure credentials (admin-only), copy/open actions",
    canEdit: true
  },
  {
    id: "compliance",
    title: "🔒 COMPLIANCE",
    current: "Due dates, status tracking, filter & manage items",
    canEdit: true
  }
];

export default function Management() {
  const [comments, setComments] = useState({});
  const [expanded, setExpanded] = useState({});

  useEffect(() => {
    const saved = localStorage.getItem("flowComments");
    if (saved) setComments(JSON.parse(saved));
  }, []);

  const handleCommentChange = (id, value) => {
    const updated = { ...comments, [id]: value };
    setComments(updated);
  };

  const handleSave = () => {
    localStorage.setItem("flowComments", JSON.stringify(comments));
    alert("✅ Comments saved locally!");
  };

  const handleExport = () => {
    const text = FLOW_SECTIONS.map(s => {
      const comment = comments[s.id] || "";
      return `${s.title}\nCurrent: ${s.current}\nYour Notes:\n${comment || "(no notes)"}\n\n`;
    }).join("---\n");
    
    const blob = new Blob([text], { type: "text/plain" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "app-flow-notes.txt";
    a.click();
  };

  const toggleExpand = (id) => {
    setExpanded(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="min-h-screen bg-[#f5f4ff] p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-extrabold text-[#1a1a1f] mb-2" style={{fontFamily:'Exo 2, sans-serif'}}>
            App Flow Editor
          </h1>
          <p className="text-sm text-gray-500" style={{fontFamily:'Montserrat, sans-serif'}}>
            Review the current app structure and add your comments/requests for each section.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 mb-6">
          <Button onClick={handleSave} className="bg-[#8c82fc] hover:bg-[#5e50fb] text-white gap-2">
            <Save className="w-4 h-4" /> Save Comments
          </Button>
          <Button onClick={handleExport} variant="outline" className="gap-2">
            Export Notes
          </Button>
          <Button onClick={() => {
            setComments({});
            localStorage.removeItem("flowComments");
          }} variant="ghost" className="text-red-500">
            <X className="w-4 h-4" /> Clear All
          </Button>
        </div>

        {/* Flow Sections */}
        <div className="space-y-4">
          {FLOW_SECTIONS.map(section => (
            <Card key={section.id} className="border-[#e8e6fe]">
              <div
                onClick={() => toggleExpand(section.id)}
                className="p-6 cursor-pointer hover:bg-[#f5f4ff] transition-colors flex items-center justify-between"
              >
                <div className="flex-1">
                  <h2 className="text-lg font-semibold text-[#1a1a1f]" style={{fontFamily:'Exo 2, sans-serif'}}>
                    {section.title}
                  </h2>
                  <p className="text-sm text-gray-500 mt-1" style={{fontFamily:'Montserrat, sans-serif'}}>
                    {section.current}
                  </p>
                </div>
                <ChevronDown
                  className={`w-5 h-5 text-[#8c82fc] transition-transform ${expanded[section.id] ? "rotate-180" : ""}`}
                />
              </div>

              {expanded[section.id] && (
                <CardContent className="pt-0 pb-6 border-t border-[#e8e6fe]">
                  <div className="mt-4">
                    <label className="text-xs font-semibold text-gray-600 mb-2 block" style={{fontFamily:'Montserrat, sans-serif'}}>
                      Your Comments / Requests:
                    </label>
                    <Textarea
                      value={comments[section.id] || ""}
                      onChange={(e) => handleCommentChange(section.id, e.target.value)}
                      placeholder="Add changes, features, or improvements you want for this section..."
                      className="min-h-24 resize-none"
                    />
                    <p className="text-[10px] text-gray-400 mt-2" style={{fontFamily:'Montserrat, sans-serif'}}>
                      💡 Example: "Add picture preview of receipts", "Remove this tab", "Change filters to..."
                    </p>
                  </div>
                </CardContent>
              )}
            </Card>
          ))}
        </div>

        {/* Summary */}
        <Card className="mt-8 bg-[#8c82fc] text-white border-none">
          <CardContent className="p-6">
            <p className="font-semibold mb-2" style={{fontFamily:'Exo 2, sans-serif'}}>
              📝 How to Use:
            </p>
            <ul className="text-sm space-y-1" style={{fontFamily:'Montserrat, sans-serif'}}>
              <li>✓ Click any section to expand and add your notes</li>
              <li>✓ Use the comment field to request changes, additions, or removals</li>
              <li>✓ Click "Save Comments" to store locally</li>
              <li>✓ Click "Export Notes" to download for review</li>
              <li>✓ Share the exported file or your comments, and I'll make all changes</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}