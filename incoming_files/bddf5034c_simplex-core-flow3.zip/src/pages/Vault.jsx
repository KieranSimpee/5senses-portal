import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Eye, EyeOff, ExternalLink, Trash2, Edit, Search, Lock, ShieldCheck, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const VAULT_CATS = ["Company Admin","Microsoft Licenses","Website & Hosting","Branding & Design","AI & Platform","Finance & Trading","Internal Tools","Other"];
const CAT_ICONS = {
  "Company Admin": "🏛️", "Microsoft Licenses": "💻", "Website & Hosting": "🌐",
  "Branding & Design": "🎨", "AI & Platform": "🤖", "Finance & Trading": "💰",
  "Internal Tools": "🔧", "Other": "🔒",
};

const empty = { service_name:"", category:"Company Admin", url:"", username:"", password:"", notes:"", is_admin_only:true };

const F = ({ label, children }) => (
  <div className="space-y-1.5">
    <Label className="text-xs font-bold text-gray-500 uppercase tracking-wide" style={{fontFamily:'Montserrat, sans-serif'}}>{label}</Label>
    {children}
  </div>
);

export default function Vault() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("All");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [revealed, setRevealed] = useState({});
  const [user, setUser] = useState(null);
  const [accessChecked, setAccessChecked] = useState(false);

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      setAccessChecked(true);
      if (u?.role === "admin") {
        base44.entities.VaultItem.list().then(d => { setItems(d); setLoading(false); });
      } else {
        setLoading(false);
      }
    }).catch(() => setAccessChecked(true));
  }, []);

  const load = async () => {
    const d = await base44.entities.VaultItem.list().catch(() => []);
    setItems(d);
  };

  const save = async () => {
    setSaving(true);
    if (editing) await base44.entities.VaultItem.update(editing.id, form);
    else await base44.entities.VaultItem.create(form);
    await load(); setShowForm(false); setSaving(false);
  };

  const remove = async (id) => {
    if (confirm("Delete this vault entry?")) { await base44.entities.VaultItem.delete(id); await load(); }
  };

  if (!accessChecked) return (
    <div className="flex items-center justify-center py-20">
      <div className="w-6 h-6 border-2 border-[#8c82fc] border-t-transparent rounded-full animate-spin" />
    </div>
  );

  if (!user || user.role !== "admin") {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <div className="w-16 h-16 bg-[#e8e6fe] rounded-2xl flex items-center justify-center">
          <Lock className="w-8 h-8 text-[#8c82fc]" />
        </div>
        <h2 className="text-xl font-extrabold text-[#1a1a1f]" style={{fontFamily:'Exo 2, sans-serif'}}>Admin Access Required</h2>
        <p className="text-sm text-gray-500 text-center max-w-sm" style={{fontFamily:'Montserrat, sans-serif'}}>The Vault is restricted to admin users only.</p>
      </div>
    );
  }

  const cats = ["All", ...VAULT_CATS.filter(c => items.some(i => i.category === c))];
  const filtered = items.filter(i => {
    const matchSearch = !search || i.service_name?.toLowerCase().includes(search.toLowerCase()) || i.username?.toLowerCase().includes(search.toLowerCase()) || i.url?.toLowerCase().includes(search.toLowerCase());
    const matchCat = catFilter === "All" || i.category === catFilter;
    return matchSearch && matchCat;
  });

  const grouped = cats.filter(c => c !== "All").reduce((acc, cat) => {
    const catItems = filtered.filter(i => i.category === cat);
    if (catItems.length > 0) acc[cat] = catItems;
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <ShieldCheck className="w-4 h-4 text-[#8c82fc]" />
            <span className="text-xs font-bold text-[#8c82fc] uppercase tracking-wider" style={{fontFamily:'Montserrat, sans-serif'}}>ADMIN ONLY</span>
          </div>
          <h1 className="text-2xl font-extrabold text-[#1a1a1f]" style={{fontFamily:'Exo 2, sans-serif'}}>Vault</h1>
          <p className="text-sm text-gray-500 mt-0.5" style={{fontFamily:'Montserrat, sans-serif'}}>Service credentials · Logins · API keys</p>
        </div>
        <Button onClick={() => { setEditing(null); setForm(empty); setShowForm(true); }} className="bg-[#8c82fc] hover:bg-[#5e50fb] text-white gap-2 font-semibold" style={{fontFamily:'Montserrat, sans-serif'}}>
          <Plus className="w-4 h-4" /> Add Entry
        </Button>
      </div>

      <div className="flex flex-wrap gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input placeholder="Search vault..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 w-56" style={{fontFamily:'Montserrat, sans-serif'}} />
        </div>
        <div className="flex flex-wrap gap-2">
          {cats.map(c => (
            <button key={c} onClick={() => setCatFilter(c)} className={`px-3 py-1.5 rounded-full text-xs font-bold border transition-all ${catFilter === c ? "bg-[#8c82fc] text-white border-[#8c82fc]" : "text-gray-500 border-gray-200 hover:border-[#8c82fc]"}`} style={{fontFamily:'Montserrat, sans-serif'}}>{c}</button>
          ))}
        </div>
      </div>

      {loading ? (
        <p className="text-center py-8 text-gray-400 text-sm">Loading vault...</p>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          <Lock className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm" style={{fontFamily:'Montserrat, sans-serif'}}>No entries yet</p>
        </div>
      ) : catFilter === "All" ? (
        <div className="space-y-6">
          {Object.entries(grouped).map(([cat, catItems]) => (
            <div key={cat}>
              <h3 className="text-xs font-bold text-[#8c82fc] uppercase tracking-widest mb-2 flex items-center gap-2" style={{fontFamily:'Montserrat, sans-serif'}}>
                <span>{CAT_ICONS[cat] || "🔒"}</span>{cat}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {catItems.map(item => <VaultCard key={item.id} item={item} revealed={revealed} setRevealed={setRevealed} onEdit={() => { setEditing(item); setForm({...item}); setShowForm(true); }} onDelete={() => remove(item.id)} />)}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filtered.map(item => <VaultCard key={item.id} item={item} revealed={revealed} setRevealed={setRevealed} onEdit={() => { setEditing(item); setForm({...item}); setShowForm(true); }} onDelete={() => remove(item.id)} />)}
        </div>
      )}

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle style={{fontFamily:'Exo 2, sans-serif'}}>{editing ? "Edit Entry" : "Add Vault Entry"}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <F label="Service Name"><Input value={form.service_name} onChange={e => setForm(f => ({...f, service_name: e.target.value}))} placeholder="e.g. GoDaddy" style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <F label="Category">
              <Select value={form.category} onValueChange={v => setForm(f => ({...f, category: v}))}>
                <SelectTrigger style={{fontFamily:'Montserrat, sans-serif'}}><SelectValue /></SelectTrigger>
                <SelectContent>{VAULT_CATS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </F>
            <F label="URL"><Input value={form.url || ""} onChange={e => setForm(f => ({...f, url: e.target.value}))} placeholder="https://" style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <F label="Username / Email"><Input value={form.username || ""} onChange={e => setForm(f => ({...f, username: e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <F label="Password"><Input type="text" value={form.password || ""} onChange={e => setForm(f => ({...f, password: e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <F label="Notes"><Input value={form.notes || ""} onChange={e => setForm(f => ({...f, notes: e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <div className="flex gap-3 pt-2">
              <Button onClick={save} disabled={saving} className="flex-1 bg-[#8c82fc] hover:bg-[#5e50fb]">{saving ? "Saving..." : editing ? "Update" : "Add"}</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function VaultCard({ item, revealed, setRevealed, onEdit, onDelete }) {
  const toggle = (key) => setRevealed(r => ({...r, [key]: !r[key]}));
  return (
    <Card className="border-[#e8e6fe] hover:border-[#bab4fd] transition-all group">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <span className="text-lg">{CAT_ICONS[item.category] || "🔒"}</span>
            <div>
              <p className="font-bold text-sm text-[#1a1a1f]" style={{fontFamily:'Montserrat, sans-serif'}}>{item.service_name}</p>
              <Badge className="bg-[#e8e6fe] text-[#5e50fb] border-0 text-[10px] mt-0.5">{item.category}</Badge>
            </div>
          </div>
          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            {item.url && <a href={item.url} target="_blank" rel="noopener noreferrer" className="p-1 hover:bg-[#e8e6fe] rounded"><ExternalLink className="w-3.5 h-3.5 text-[#8c82fc]" /></a>}
            <button onClick={onEdit} className="p-1 hover:bg-[#e8e6fe] rounded"><Edit className="w-3.5 h-3.5 text-gray-400" /></button>
            <button onClick={onDelete} className="p-1 hover:bg-red-100 rounded"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
          </div>
        </div>
        {item.username && (
          <div className="text-xs text-gray-500 mb-1.5" style={{fontFamily:'Montserrat, sans-serif'}}>👤 {item.username}</div>
        )}
        {item.password && (
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-xs font-mono bg-[#f5f4ff] px-2 py-0.5 rounded flex-1 truncate">
              {revealed[item.id] ? item.password : "••••••••••"}
            </span>
            <button onClick={() => toggle(item.id)} className="p-1 hover:bg-[#e8e6fe] rounded flex-shrink-0">
              {revealed[item.id] ? <EyeOff className="w-3 h-3 text-gray-400" /> : <Eye className="w-3 h-3 text-gray-400" />}
            </button>
            <button onClick={() => navigator.clipboard.writeText(item.password)} className="p-1 hover:bg-[#e8e6fe] rounded flex-shrink-0">
              <Copy className="w-3 h-3 text-gray-400" />
            </button>
          </div>
        )}
        {item.notes && <p className="text-[11px] text-gray-400 leading-relaxed" style={{fontFamily:'Montserrat, sans-serif'}}>{item.notes}</p>}
      </CardContent>
    </Card>
  );
}