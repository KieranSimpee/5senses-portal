import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Trash2, Link as LinkIcon, Zap, MessageCircle, CheckCircle, AlertCircle, Loader2, MoreVertical } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import ConnectedAppsList from '@/components/workspace/ConnectedAppsList';
import SuperagentChat from '@/components/workspace/SuperagentChat';
import SuperagentTaskDashboard from '@/components/workspace/SuperagentTaskDashboard';
import SimpeeApprovalManager from '@/components/workspace/SimpeeApprovalManager';

export default function WorkspaceHub() {
  const [connectedApps, setConnectedApps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddApp, setShowAddApp] = useState(false);
  const [newAppId, setNewAppId] = useState('');
  const [newAppName, setNewAppName] = useState('');
  const [addingApp, setAddingApp] = useState(false);
  const [editingAgentId, setEditingAgentId] = useState(null);
  const [editingAgentName, setEditingAgentName] = useState('');
  const { toast } = useToast();

  // Fetch connected apps
  const fetchApps = useCallback(async () => {
    try {
      setLoading(true);
      const apps = await base44.entities.ConnectedApp.list();
      setConnectedApps(apps || []);
    } catch (e) {
      toast({ title: 'Failed to load apps', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchApps();
  }, [fetchApps]);

  const handleAddApp = async (e) => {
    e.preventDefault();
    if (!newAppId || !newAppName) {
      toast({ title: 'Please fill all fields', variant: 'destructive' });
      return;
    }

    setAddingApp(true);
    try {
      await base44.entities.ConnectedApp.create({
        app_id: newAppId,
        app_name: newAppName,
        app_type: 'app',
        status: 'connected',
        last_sync: new Date().toISOString(),
        accessible_entities: []
      });

      toast({ title: 'App connected successfully!' });
      setNewAppId('');
      setNewAppName('');
      setShowAddApp(false);
      fetchApps();
    } catch (e) {
      toast({ title: 'Failed to connect app', description: e.message, variant: 'destructive' });
    } finally {
      setAddingApp(false);
    }
  };

  const handleDeleteApp = async (id) => {
    if (!confirm('Disconnect this app?')) return;
    try {
      await base44.entities.ConnectedApp.delete(id);
      toast({ title: 'App disconnected' });
      fetchApps();
    } catch (e) {
      toast({ title: 'Failed to disconnect', description: e.message, variant: 'destructive' });
    }
  };

  const handleRenameAgent = async (id, currentName) => {
    setEditingAgentId(id);
    setEditingAgentName(currentName);
  };

  const handleSaveRename = async (id) => {
    if (!editingAgentName.trim()) {
      toast({ title: 'Name cannot be empty', variant: 'destructive' });
      return;
    }
    try {
      await base44.entities.ConnectedApp.update(id, { app_name: editingAgentName });
      toast({ title: 'Agent renamed successfully!' });
      setEditingAgentId(null);
      fetchApps();
    } catch (e) {
      toast({ title: 'Failed to rename', description: e.message, variant: 'destructive' });
    }
  };

  const superagents = connectedApps.filter(a => a.app_type === 'superagent');
  const apps = connectedApps.filter(a => a.app_type === 'app');

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col bg-background p-6">
      <div className="max-w-7xl mx-auto w-full">
        <div className="mb-6">
          <h1 className="text-3xl font-exo font-semibold text-foreground mb-2">Workspace Hub</h1>
          <p className="text-sm text-muted-foreground">Manage connected apps and Superagents in your workspace</p>
        </div>

        <Tabs defaultValue="apps" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="apps">Connected Apps ({apps.length})</TabsTrigger>
            <TabsTrigger value="superagents">Superagents ({superagents.length})</TabsTrigger>
            <TabsTrigger value="tasks">Active Tasks</TabsTrigger>
            <TabsTrigger value="approvals">Approvals</TabsTrigger>
          </TabsList>

          {/* Apps Tab */}
          <TabsContent value="apps" className="space-y-4">
            {!showAddApp ? (
              <Button onClick={() => setShowAddApp(true)} className="gap-2">
                <Plus className="w-4 h-4" />
                Connect App
              </Button>
            ) : (
              <Card className="p-4">
                <form onSubmit={handleAddApp} className="space-y-3">
                  <Input
                    placeholder="App ID"
                    value={newAppId}
                    onChange={(e) => setNewAppId(e.target.value)}
                    required
                  />
                  <Input
                    placeholder="App Name"
                    value={newAppName}
                    onChange={(e) => setNewAppName(e.target.value)}
                    required
                  />
                  <div className="flex gap-2">
                    <Button type="submit" disabled={addingApp}>
                      {addingApp ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Connect'}
                    </Button>
                    <Button type="button" variant="outline" onClick={() => setShowAddApp(false)}>Cancel</Button>
                  </div>
                </form>
              </Card>
            )}

            {loading ? (
              <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
            ) : (
              <ConnectedAppsList apps={apps} onDelete={handleDeleteApp} />
            )}
          </TabsContent>

          {/* Tasks Tab */}
          <TabsContent value="tasks">
            <SuperagentTaskDashboard />
          </TabsContent>

          {/* Superagents Tab */}
           <TabsContent value="superagents">
            {superagents.length === 0 ? (
              <Card className="p-8 text-center">
                <Zap className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-muted-foreground">No Superagents connected yet</p>
                <p className="text-xs text-muted-foreground mt-1">Connect 5S Portal or other Superagents to execute cross-app tasks</p>
              </Card>
            ) : (
              <div className="space-y-4">
                {superagents.map((agent) => (
                  <Card key={agent.id} className="p-6 border-2" style={{borderColor: agent.app_name.toLowerCase().includes('5s portal') ? '#8c82fc' : '#e8e6fe'}}>
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-lg flex items-center justify-center" style={{backgroundColor: agent.app_name.toLowerCase().includes('5s portal') ? '#f5f4ff' : '#f0f0f0'}}>
                          {agent.app_name.toLowerCase().includes('5s portal') ? (
                            <MessageCircle className="w-6 h-6" style={{color: '#8c82fc'}} />
                          ) : (
                            <Zap className="w-6 h-6 text-primary" />
                          )}
                        </div>
                        <div>
                          {editingAgentId === agent.id ? (
                            <Input
                              value={editingAgentName}
                              onChange={(e) => setEditingAgentName(e.target.value)}
                              autoFocus
                              className="h-7 text-lg font-bold"
                            />
                          ) : (
                            <h3 className="font-bold text-lg text-foreground">{agent.app_name}</h3>
                          )}
                          <p className="text-xs text-muted-foreground mt-0.5">ID: {agent.app_id}</p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <div className="flex gap-1">
                          {editingAgentId === agent.id ? (
                            <>
                              <Button 
                                size="sm" 
                                variant="default"
                                onClick={() => handleSaveRename(agent.id)}
                                className="h-8"
                              >
                                Save
                              </Button>
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => setEditingAgentId(null)}
                                className="h-8"
                              >
                                Cancel
                              </Button>
                            </>
                          ) : (
                            <>
                              <Badge variant={agent.status === 'connected' ? 'default' : 'outline'} className="capitalize">
                                {agent.status === 'connected' ? '✓ Connected' : agent.status}
                              </Badge>
                              <div className="relative group">
                                <Button 
                                  size="sm" 
                                  variant="ghost"
                                  className="h-8 w-8 p-0"
                                >
                                  <MoreVertical className="w-4 h-4" />
                                </Button>
                                <div className="absolute right-0 top-8 bg-white border border-border rounded-lg shadow-lg p-1 hidden group-hover:block z-10">
                                  <button
                                    onClick={() => handleRenameAgent(agent.id, agent.app_name)}
                                    className="block w-full text-left px-3 py-2 text-sm hover:bg-muted rounded"
                                  >
                                    Rename
                                  </button>
                                  <button
                                    onClick={() => handleDeleteApp(agent.id)}
                                    className="block w-full text-left px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded"
                                  >
                                    Disconnect
                                  </button>
                                </div>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 bg-muted/50 p-4 rounded-lg">
                      <div>
                        <p className="text-xs font-semibold text-muted-foreground uppercase mb-1">Type</p>
                        <p className="text-sm text-foreground capitalize">{agent.app_type}</p>
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-muted-foreground uppercase mb-1">Status</p>
                        <p className="text-sm text-foreground capitalize">{agent.status}</p>
                      </div>
                      {agent.last_sync && (
                        <div>
                          <p className="text-xs font-semibold text-muted-foreground uppercase mb-1">Last Sync</p>
                          <p className="text-sm text-foreground">{new Date(agent.last_sync).toLocaleDateString()}</p>
                        </div>
                      )}
                      {agent.accessible_entities && agent.accessible_entities.length > 0 && (
                        <div>
                          <p className="text-xs font-semibold text-muted-foreground uppercase mb-1">Entities</p>
                          <p className="text-sm text-foreground">{agent.accessible_entities.length} accessible</p>
                        </div>
                      )}
                    </div>

                    {agent.notes && (
                      <div className="mt-4 pt-4 border-t border-border">
                        <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">Notes</p>
                        <p className="text-sm text-foreground">{agent.notes}</p>
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Approvals Tab */}
          <TabsContent value="approvals">
            <SimpeeApprovalManager />
          </TabsContent>
          </Tabs>

          {/* Superagent Chat Section */}
        {superagents.length > 0 && (
          <div className="mt-8 pt-8 border-t border-border">
            <h2 className="text-xl font-exo font-semibold text-foreground mb-4">Superagent Command Center</h2>
            <SuperagentChat superagents={superagents} connectedApps={connectedApps} />
          </div>
        )}
      </div>
    </div>
  );
}