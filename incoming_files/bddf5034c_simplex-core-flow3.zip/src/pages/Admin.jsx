import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Eye, EyeOff, ExternalLink, Trash2, Edit, Mail, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { format, parseISO } from "date-fns";
import ExternalAppConnector from "@/components/vault/ExternalAppConnector";

const BANK_TYPES = ["Current","Savings","Multi-currency","Credit"];
const emptyBank = { bank_name:"", account_name:"", account_number:"", currency:"HKD", type:"Current", entity:"5SENSESBEAUTY LIMITED", balance:0, notes:"", is_admin_only:true };
const emptyMember = { name:"", email:"", role:"member", department:"", status:"Active", access_admin:false, access_finance:true, access_hr:false, access_brand:true, access_tools:true, access_compliance:true, access_expenses:true, access_projects:true, access_notes:true };

const F = ({ label, children }) => (
  <div className="space-y-1.5">
    <Label className="text-xs font-bold text-gray-500 uppercase tracking-wide" style={{fontFamily:'Montserrat, sans-serif'}}>{label}</Label>
    {children}
  </div>
);

const AccessToggle = ({ label, checked, onChange }) => (
  <div className="flex items-center justify-between py-1.5 border-b border-gray-50 last:border-0">
    <span className="text-xs text-gray-600" style={{fontFamily:'Montserrat, sans-serif'}}>{label}</span>
    <input type="checkbox" checked={checked} onChange={e => onChange(e.target.checked)} className="w-4 h-4 accent-[#8c82fc]" />
  </div>
);

export default function Admin() {
  const [banks, setBanks] = useState([]);
  const [members, setMembers] = useState([]);
  const [activityLog, setActivityLog] = useState([]);
  const [tradeLog, setTradeLog] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showBankForm, setShowBankForm] = useState(false);
  const [showMemberForm, setShowMemberForm] = useState(false);
  const [bankForm, setBankForm] = useState(emptyBank);
  const [memberForm, setMemberForm] = useState(emptyMember);
  const [editingBank, setEditingBank] = useState(null);
  const [editingMember, setEditingMember] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => { load(); }, []);

  const load = async () => {
    const [b, m, al, tl] = await Promise.all([
      base44.entities.BankAccount.list().catch(() => []),
      base44.entities.TeamMember.list().catch(() => []),
      base44.entities.ActivityLog.list("-date", 50).catch(() => []),
      base44.entities.TradeLog.list("-date", 50).catch(() => []),
    ]);
    setBanks(b); setMembers(m); setActivityLog(al); setTradeLog(tl); setLoading(false);
  };

  const saveBank = async () => { setSaving(true); if (editingBank) await base44.entities.BankAccount.update(editingBank.id, bankForm); else await base44.entities.BankAccount.create(bankForm); await load(); setShowBankForm(false); setSaving(false); };
  const saveMember = async () => { setSaving(true); if (editingMember) await base44.entities.TeamMember.update(editingMember.id, memberForm); else await base44.entities.TeamMember.create(memberForm); await load(); setShowMemberForm(false); setSaving(false); };
  const deleteBank = async (id) => { if (confirm("Delete?")) { await base44.entities.BankAccount.delete(id); await load(); }};
  const deleteMember = async (id) => { if (confirm("Delete team member?")) { await base44.entities.TeamMember.delete(id); await load(); }};

  const ACCESS_FIELDS = [
    { key:"access_admin", label:"Admin" }, { key:"access_finance", label:"Finance" },
    { key:"access_hr", label:"HR" }, { key:"access_brand", label:"Brand" },
    { key:"access_tools", label:"Tools" }, { key:"access_compliance", label:"Compliance" },
    { key:"access_expenses", label:"Expenses" }, { key:"access_projects", label:"Projects" },
    { key:"access_notes", label:"Notes" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-[#1a1a1f]" style={{fontFamily:'Exo 2, sans-serif'}}>Admin</h1>
        <p className="text-sm text-gray-500 mt-0.5" style={{fontFamily:'Montserrat, sans-serif'}}>Team · Bank accounts · Activity · Trade log</p>
      </div>

      <Tabs defaultValue="team">
        <TabsList className="bg-[#e8e6fe] flex-wrap h-auto gap-1">
          <TabsTrigger value="team" style={{fontFamily:'Montserrat, sans-serif'}}>👥 Team ({members.length})</TabsTrigger>
          <TabsTrigger value="bank" style={{fontFamily:'Montserrat, sans-serif'}}>🏦 Bank Accounts</TabsTrigger>
          <TabsTrigger value="apps" style={{fontFamily:'Montserrat, sans-serif'}}>🔗 External Apps</TabsTrigger>
          <TabsTrigger value="company" style={{fontFamily:'Montserrat, sans-serif'}}>🏢 Company Info</TabsTrigger>
          <TabsTrigger value="activity" style={{fontFamily:'Montserrat, sans-serif'}}>📋 Activity Log</TabsTrigger>
          <TabsTrigger value="trades" style={{fontFamily:'Montserrat, sans-serif'}}>📈 Trade Log</TabsTrigger>
        </TabsList>

        {/* TEAM */}
        <TabsContent value="team" className="mt-4 space-y-4">
          <div className="flex justify-end">
            <Button onClick={() => { setEditingMember(null); setMemberForm(emptyMember); setShowMemberForm(true); }} className="bg-[#8c82fc] hover:bg-[#5e50fb] text-white gap-2 font-semibold" style={{fontFamily:'Montserrat, sans-serif'}}>
              <Plus className="w-4 h-4" /> Add Member
            </Button>
          </div>
          {loading ? <p className="text-center py-8 text-gray-400 text-sm">Loading...</p> : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {members.map(m => (
                <Card key={m.id} className="border-[#e8e6fe]">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <p className="font-bold text-sm text-[#1a1a1f]" style={{fontFamily:'Montserrat, sans-serif'}}>{m.name}</p>
                        <p className="text-xs text-gray-400">{m.email}</p>
                        {m.department && <p className="text-xs text-gray-400">{m.department}</p>}
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={`text-[10px] border-0 ${m.role === "admin" ? "bg-[#e8e6fe] text-[#5e50fb]" : "bg-gray-100 text-gray-500"}`}>{m.role}</Badge>
                        <button onClick={() => { setEditingMember(m); setMemberForm({...m}); setShowMemberForm(true); }} className="p-1 hover:bg-[#e8e6fe] rounded"><Edit className="w-3.5 h-3.5 text-gray-400" /></button>
                        <button onClick={() => deleteMember(m.id)} className="p-1 hover:bg-red-100 rounded"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {ACCESS_FIELDS.filter(f => m[f.key]).map(f => (
                        <span key={f.key} className="text-[10px] bg-[#e8e6fe] text-[#5e50fb] px-2 py-0.5 rounded-full font-semibold" style={{fontFamily:'Montserrat, sans-serif'}}>{f.label}</span>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
              {members.length === 0 && <p className="text-center text-gray-400 py-8 text-sm col-span-2">No team members yet</p>}
            </div>
          )}
        </TabsContent>

        {/* BANK */}
        <TabsContent value="bank" className="mt-4">
          <div className="flex justify-end mb-4">
            <Button onClick={() => { setEditingBank(null); setBankForm(emptyBank); setShowBankForm(true); }} className="bg-[#8c82fc] hover:bg-[#5e50fb] text-white gap-2 font-semibold" style={{fontFamily:'Montserrat, sans-serif'}}>
              <Plus className="w-4 h-4" /> Add Account
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {banks.map(b => (
              <Card key={b.id} className="border-[#e8e6fe]">
                <CardContent className="p-5">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="font-bold text-[#1a1a1f]" style={{fontFamily:'Exo 2, sans-serif'}}>{b.bank_name}</div>
                      <div className="text-xs text-gray-500">{b.account_name}</div>
                    </div>
                    <Badge className="bg-[#e8e6fe] text-[#5e50fb] border-0 text-xs font-bold">{b.currency}</Badge>
                  </div>
                  <div className="text-xs text-gray-500 mb-1">A/C: {b.account_number}</div>
                  <div className="text-xs text-gray-500 mb-3">{b.entity} · {b.type}</div>
                  {b.balance > 0 && <p className="text-sm font-extrabold text-[#5e50fb] mb-2">{b.currency} {b.balance.toLocaleString()}</p>}
                  {b.notes && <p className="text-[11px] text-gray-400">{b.notes}</p>}
                  <div className="flex gap-2 mt-3">
                    <button onClick={() => { setEditingBank(b); setBankForm({...b}); setShowBankForm(true); }} className="p-1.5 hover:bg-[#e8e6fe] rounded-lg"><Edit className="w-3.5 h-3.5 text-gray-400" /></button>
                    <button onClick={() => deleteBank(b.id)} className="p-1.5 hover:bg-red-100 rounded-lg"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
                  </div>
                </CardContent>
              </Card>
            ))}
            {banks.length === 0 && <p className="text-gray-400 text-sm py-4">No bank accounts added yet</p>}
          </div>
        </TabsContent>

        {/* EXTERNAL APPS */}
        <TabsContent value="apps" className="mt-4">
          <ExternalAppConnector />
        </TabsContent>

        {/* COMPANY INFO */}
        <TabsContent value="company" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              { label:"5SENSESBEAUTY LIMITED", items:[
                {k:"Type", v:"Private Limited Company"},
                {k:"BR Number", v:"78459506-000-07-25-9"},
                {k:"BR Expires", v:"14 Jul 2026 ⚠️"},
                {k:"Company Secretary", v:"Reap Business Limited"},
              ]},
              { label:"SIMPLEX-ITY (Branch)", items:[
                {k:"Branch Cert No", v:"78459506-001-07-25-A"},
                {k:"Branch Expires", v:"14 Jul 2026 ⚠️"},
                {k:"Nature", v:"Marketing Service"},
                {k:"Address", v:"Rm 1608, 16/F APEC Plaza, 49 Hoi Yuen Rd, KLN"},
                {k:"Commenced", v:"12 Jan 2026"},
              ]},
              { label:"Key Contacts", items:[
                {k:"Reap Business (Carrie)", v:"(852) 3166 1298"},
                {k:"FundFluent (Wilson)", v:"wilson.tai@fundfluent.io"},
                {k:"Loreen (Internal)", v:"Loreen@5senses.global"},
              ]},
              { label:"Payment Info", items:[
                {k:"HSBC Account", v:"4544-8741-4001"},
                {k:"HSBC FPS", v:"65438388"},
                {k:"Hang Seng (FundFluent)", v:"239 778269 883"},
              ]},
            ].map(section => (
              <Card key={section.label} className="border-[#e8e6fe]">
                <CardContent className="p-5">
                  <h3 className="font-extrabold text-sm text-[#5e50fb] mb-3" style={{fontFamily:'Exo 2, sans-serif'}}>{section.label}</h3>
                  <div className="space-y-2">
                    {section.items.map(i => (
                      <div key={i.k} className="flex items-start gap-2">
                        <span className="text-xs text-gray-400 w-36 flex-shrink-0 pt-0.5" style={{fontFamily:'Montserrat, sans-serif'}}>{i.k}</span>
                        <span className="text-xs font-semibold text-[#1a1a1f] flex-1" style={{fontFamily:'Montserrat, sans-serif'}}>{i.v}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* ACTIVITY LOG */}
        <TabsContent value="activity" className="mt-4">
          <Card className="border-[#e8e6fe]">
            <CardContent className="p-0">
              <div className="hidden md:grid grid-cols-[1fr_1fr_2fr_1fr] gap-4 px-5 py-3 bg-[#f5f4ff] text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                <div>Date</div><div>Area</div><div>Action</div><div>Detail</div>
              </div>
              {loading ? <p className="text-center py-8 text-gray-400 text-sm">Loading...</p> : activityLog.length === 0 ? (
                <p className="text-center py-8 text-gray-400 text-sm">No activity logged yet</p>
              ) : activityLog.map(a => (
                <div key={a.id} className="grid grid-cols-[1fr_1fr_2fr_1fr] gap-4 px-5 py-3 border-b border-[#e8e6fe] last:border-0 hover:bg-[#f5f4ff] text-xs">
                  <span className="text-gray-400">{a.date ? format(parseISO(a.date), "d MMM yy") : "—"}</span>
                  <Badge className="bg-[#e8e6fe] text-[#5e50fb] border-0 text-[10px] w-fit">{a.area}</Badge>
                  <span className="font-semibold text-[#1a1a1f]" style={{fontFamily:'Montserrat, sans-serif'}}>{a.action}</span>
                  <span className="text-gray-400 truncate">{a.detail}</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* TRADE LOG */}
        <TabsContent value="trades" className="mt-4">
          <Card className="border-[#e8e6fe]">
            <CardContent className="p-0">
              <div className="hidden md:grid grid-cols-[1fr_1fr_1fr_1fr_1fr_1fr_1fr] gap-2 px-5 py-3 bg-[#f5f4ff] text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                <div>Date</div><div>Platform</div><div>Instrument</div><div>Direction</div><div>Entry</div><div>Exit</div><div>Net P&L</div>
              </div>
              {loading ? <p className="text-center py-8 text-gray-400 text-sm">Loading...</p> : tradeLog.length === 0 ? (
                <p className="text-center py-8 text-gray-400 text-sm">No trades logged yet</p>
              ) : tradeLog.map(t => (
                <div key={t.id} className="grid grid-cols-[1fr_1fr_1fr_1fr_1fr_1fr_1fr] gap-2 px-5 py-3 border-b border-[#e8e6fe] last:border-0 hover:bg-[#f5f4ff] text-xs items-center">
                  <span className="text-gray-400">{t.date ? format(parseISO(t.date), "d MMM yy") : "—"}</span>
                  <span className="text-gray-600">{t.platform}</span>
                  <span className="font-semibold text-[#1a1a1f]">{t.instrument}</span>
                  <Badge className={`text-[10px] border-0 w-fit ${t.direction === "Long" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>{t.direction}</Badge>
                  <span className="text-gray-600">{t.entry_price}</span>
                  <span className="text-gray-600">{t.exit_price}</span>
                  <span className={`font-bold ${(t.net_pnl_hkd || 0) >= 0 ? "text-green-600" : "text-red-600"}`}>
                    {(t.net_pnl_hkd || 0) >= 0 ? "+" : ""}{(t.net_pnl_hkd || 0).toLocaleString()}
                  </span>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Bank Form */}
      <Dialog open={showBankForm} onOpenChange={setShowBankForm}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle style={{fontFamily:'Exo 2, sans-serif'}}>{editingBank ? "Edit Bank Account" : "Add Bank Account"}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <F label="Bank Name"><Input value={bankForm.bank_name} onChange={e=>setBankForm(f=>({...f,bank_name:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}}/></F>
            <F label="Account Name"><Input value={bankForm.account_name||""} onChange={e=>setBankForm(f=>({...f,account_name:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}}/></F>
            <F label="Account Number"><Input value={bankForm.account_number||""} onChange={e=>setBankForm(f=>({...f,account_number:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}}/></F>
            <div className="grid grid-cols-2 gap-3">
              <F label="Currency"><Input value={bankForm.currency||"HKD"} onChange={e=>setBankForm(f=>({...f,currency:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}}/></F>
              <F label="Type"><Select value={bankForm.type||"Current"} onValueChange={v=>setBankForm(f=>({...f,type:v}))}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent>{BANK_TYPES.map(t=><SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select></F>
            </div>
            <F label="Entity"><Input value={bankForm.entity||""} onChange={e=>setBankForm(f=>({...f,entity:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}}/></F>
            <F label="Balance"><Input type="number" value={bankForm.balance||0} onChange={e=>setBankForm(f=>({...f,balance:parseFloat(e.target.value)||0}))} /></F>
            <F label="Notes"><Input value={bankForm.notes||""} onChange={e=>setBankForm(f=>({...f,notes:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}}/></F>
            <div className="flex gap-3 pt-2">
              <Button onClick={saveBank} disabled={saving} className="flex-1 bg-[#8c82fc] hover:bg-[#5e50fb]">{saving?"Saving...":editingBank?"Update":"Add"}</Button>
              <Button variant="outline" onClick={()=>setShowBankForm(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Team Member Form */}
      <Dialog open={showMemberForm} onOpenChange={setShowMemberForm}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle style={{fontFamily:'Exo 2, sans-serif'}}>{editingMember ? "Edit Member" : "Add Team Member"}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <F label="Name"><Input value={memberForm.name} onChange={e=>setMemberForm(f=>({...f,name:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}}/></F>
            <F label="Email"><Input value={memberForm.email||""} onChange={e=>setMemberForm(f=>({...f,email:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}}/></F>
            <div className="grid grid-cols-2 gap-3">
              <F label="Role"><Select value={memberForm.role||"member"} onValueChange={v=>setMemberForm(f=>({...f,role:v}))}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent><SelectItem value="admin">Admin</SelectItem><SelectItem value="member">Member</SelectItem></SelectContent></Select></F>
              <F label="Department"><Input value={memberForm.department||""} onChange={e=>setMemberForm(f=>({...f,department:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}}/></F>
            </div>
            <div>
              <Label className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-2 block" style={{fontFamily:'Montserrat, sans-serif'}}>Section Access</Label>
              <Card className="border-[#e8e6fe]">
                <CardContent className="p-3">
                  {ACCESS_FIELDS.map(f => (
                    <AccessToggle key={f.key} label={f.label} checked={memberForm[f.key] || false} onChange={v => setMemberForm(m => ({...m, [f.key]: v}))} />
                  ))}
                </CardContent>
              </Card>
            </div>
            <div className="flex gap-3 pt-2">
              <Button onClick={saveMember} disabled={saving} className="flex-1 bg-[#8c82fc] hover:bg-[#5e50fb]">{saving?"Saving...":editingMember?"Update":"Add"}</Button>
              <Button variant="outline" onClick={()=>setShowMemberForm(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

const ACCESS_FIELDS = [
  { key:"access_admin", label:"Admin" }, { key:"access_finance", label:"Finance" },
  { key:"access_hr", label:"HR" }, { key:"access_brand", label:"Brand" },
  { key:"access_tools", label:"Tools" }, { key:"access_compliance", label:"Compliance" },
  { key:"access_expenses", label:"Expenses" }, { key:"access_projects", label:"Projects" },
  { key:"access_notes", label:"Notes" },
];