import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { format, parseISO, differenceInDays, startOfMonth, endOfMonth } from "date-fns";
import NoticeBoard from "@/components/home/NoticeBoard";
import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle, DollarSign, CheckCircle2, Folder, Clock } from "lucide-react";

const NAV_CARDS = [
  { label:"Finance", path:"/finance", icon:"💰", desc:"Expenses, renewals & bank accounts" },
  { label:"Compliance", path:"/compliance", icon:"⚖️", desc:"HK regulatory deadlines" },
  { label:"HR", path:"/hr", icon:"👥", desc:"Contracts, payroll & MPF" },
  { label:"Documents", path:"/documents", icon:"📁", desc:"Files, contracts & brand assets" },
  { label:"Brand", path:"/brand", icon:"✨", desc:"Brands, influencers & campaigns" },
  { label:"Vault", path:"/vault", icon:"🔐", desc:"Secure credentials & logins" },
  { label:"Notes", path:"/notes", icon:"📝", desc:"From WhatsApp, meetings & Simpee" },
  { label:"Admin", path:"/admin", icon:"🏛️", desc:"Team, activity & trade log" },
];

export default function Home() {
  const [user, setUser] = useState(null);
  const [metrics, setMetrics] = useState({ expenses: 0, overdue: 0, activeProjects: 0, expiringSoon: 0 });
  const [activity, setActivity] = useState([]);
  const [loadingMetrics, setLoadingMetrics] = useState(true);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
    loadMetrics();
  }, []);

  const loadMetrics = async () => {
    const now = new Date();
    const monthStart = startOfMonth(now).toISOString().split("T")[0];
    const monthEnd = endOfMonth(now).toISOString().split("T")[0];

    const [expenses, compliance, projects, actLog] = await Promise.all([
      base44.entities.Expense.list("-date").catch(() => []),
      base44.entities.ComplianceItem.list().catch(() => []),
      base44.entities.Project.list().catch(() => []),
      base44.entities.ActivityLog.list("-date", 10).catch(() => []),
    ]);

    const thisMonthExpenses = expenses.filter(e => e.date && e.date >= monthStart && e.date <= monthEnd);
    const monthlyTotal = thisMonthExpenses.reduce((s, e) => s + (e.amount || 0), 0);

    const overdueCompliance = compliance.filter(c => {
      if (c.status === "Completed") return false;
      if (!c.due_date) return false;
      return new Date(c.due_date) < now;
    });

    const activeProjects = projects.filter(p => p.status === "in_progress" || p.status === "active");

    const expiringSoon = compliance.filter(c => {
      if (c.status === "Completed" || !c.due_date) return false;
      const days = differenceInDays(new Date(c.due_date), now);
      return days >= 0 && days <= 30;
    });

    setMetrics({
      expenses: monthlyTotal,
      overdue: overdueCompliance.length,
      activeProjects: activeProjects.length,
      expiringSoon: expiringSoon.length,
    });
    setActivity(actLog);
    setLoadingMetrics(false);
  };

  const isAdmin = user?.role === "admin";

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="flex gap-2">
          <div className="h-9 w-9 rounded-xl bg-[#8c82fc] flex items-center justify-center text-white font-extrabold text-sm" style={{fontFamily:'Exo 2, sans-serif'}}>5S</div>
          <div className="h-9 w-9 rounded-xl bg-[#1a1a1f] flex items-center justify-center text-white font-extrabold text-[9px]" style={{fontFamily:'Exo 2, sans-serif'}}>SX</div>
        </div>
        <div>
          <h1 className="text-2xl font-extrabold text-[#1a1a1f] leading-tight" style={{fontFamily:'Exo 2, sans-serif'}}>5S Portal</h1>
          <p className="text-xs text-gray-400 font-medium" style={{fontFamily:'Montserrat, sans-serif'}}>
            {user ? `Welcome back, ${user.full_name?.split(" ")[0] || "there"}` : "Internal Operations Hub"}
          </p>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-[#e8e6fe]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 bg-[#e8e6fe] rounded-xl flex items-center justify-center flex-shrink-0">
              <DollarSign className="w-4 h-4 text-[#5e50fb]" />
            </div>
            <div>
              <p className="text-[10px] text-gray-400 font-semibold uppercase tracking-wide" style={{fontFamily:'Montserrat, sans-serif'}}>This Month</p>
              <p className="text-lg font-extrabold text-[#5e50fb]" style={{fontFamily:'Exo 2, sans-serif'}}>
                {loadingMetrics ? "—" : `HKD ${metrics.expenses.toLocaleString(undefined, {maximumFractionDigits:0})}`}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className={`border ${metrics.overdue > 0 ? "border-red-200 bg-red-50" : "border-[#e8e6fe]"}`}>
          <CardContent className="p-4 flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${metrics.overdue > 0 ? "bg-red-100" : "bg-[#e8e6fe]"}`}>
              <AlertCircle className={`w-4 h-4 ${metrics.overdue > 0 ? "text-red-500" : "text-[#5e50fb]"}`} />
            </div>
            <div>
              <p className="text-[10px] text-gray-400 font-semibold uppercase tracking-wide" style={{fontFamily:'Montserrat, sans-serif'}}>Overdue</p>
              <p className={`text-lg font-extrabold ${metrics.overdue > 0 ? "text-red-600" : "text-[#1a1a1f]"}`} style={{fontFamily:'Exo 2, sans-serif'}}>
                {loadingMetrics ? "—" : metrics.overdue} items
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className={`border ${metrics.expiringSoon > 0 ? "border-yellow-200 bg-yellow-50" : "border-[#e8e6fe]"}`}>
          <CardContent className="p-4 flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${metrics.expiringSoon > 0 ? "bg-yellow-100" : "bg-[#e8e6fe]"}`}>
              <Clock className={`w-4 h-4 ${metrics.expiringSoon > 0 ? "text-yellow-600" : "text-[#5e50fb]"}`} />
            </div>
            <div>
              <p className="text-[10px] text-gray-400 font-semibold uppercase tracking-wide" style={{fontFamily:'Montserrat, sans-serif'}}>Due in 30d</p>
              <p className={`text-lg font-extrabold ${metrics.expiringSoon > 0 ? "text-yellow-600" : "text-[#1a1a1f]"}`} style={{fontFamily:'Exo 2, sans-serif'}}>
                {loadingMetrics ? "—" : metrics.expiringSoon} items
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-[#e8e6fe]">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-9 h-9 bg-[#e8e6fe] rounded-xl flex items-center justify-center flex-shrink-0">
              <Folder className="w-4 h-4 text-[#5e50fb]" />
            </div>
            <div>
              <p className="text-[10px] text-gray-400 font-semibold uppercase tracking-wide" style={{fontFamily:'Montserrat, sans-serif'}}>Active Projects</p>
              <p className="text-lg font-extrabold text-[#1a1a1f]" style={{fontFamily:'Exo 2, sans-serif'}}>
                {loadingMetrics ? "—" : metrics.activeProjects}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Nav Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {NAV_CARDS.map(card => (
          <Link key={card.path} to={card.path}
            className="bg-white rounded-2xl border border-[#e8e6fe] p-4 hover:border-[#8c82fc] hover:shadow-md transition-all group cursor-pointer">
            <div className="text-2xl mb-2">{card.icon}</div>
            <p className="text-sm font-extrabold text-[#1a1a1f] group-hover:text-[#8c82fc] transition-colors" style={{fontFamily:'Exo 2, sans-serif'}}>{card.label}</p>
            <p className="text-[10px] text-gray-400 mt-0.5 leading-relaxed" style={{fontFamily:'Montserrat, sans-serif'}}>{card.desc}</p>
          </Link>
        ))}
      </div>

      {/* Notice Board + Activity Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <NoticeBoard isAdmin={isAdmin} />
        </div>
        <div>
          <div className="bg-white rounded-2xl border border-[#e8e6fe] p-5">
            <h2 className="text-base font-extrabold text-[#1a1a1f] mb-4" style={{fontFamily:'Exo 2, sans-serif'}}>📋 Recent Activity</h2>
            {activity.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-4" style={{fontFamily:'Montserrat, sans-serif'}}>No activity yet</p>
            ) : (
              <div className="space-y-3">
                {activity.map(a => (
                  <div key={a.id} className="flex items-start gap-3">
                    <div className="w-7 h-7 bg-[#e8e6fe] rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#8c82fc]" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-[#1a1a1f] leading-snug" style={{fontFamily:'Montserrat, sans-serif'}}>{a.action}</p>
                      {a.detail && <p className="text-[10px] text-gray-400 mt-0.5 truncate">{a.detail}</p>}
                      <p className="text-[10px] text-gray-300 mt-0.5">{a.area} · {a.date ? format(parseISO(a.date), "d MMM yyyy") : "—"}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}