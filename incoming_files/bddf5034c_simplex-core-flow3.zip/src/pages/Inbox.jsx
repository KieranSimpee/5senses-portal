import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Mail, Reply, Archive, Trash2, Clock, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatDistanceToNow, parseISO } from 'date-fns';

export default function Inbox() {
  const [emails, setEmails] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('unread'); // unread, replied, archived, all

  useEffect(() => {
    loadEmails();
  }, []);

  const loadEmails = async () => {
    try {
      const res = await base44.functions.invoke('outlookGetEmails', {}).catch(() => null);
      if (res?.data?.emails) {
        setEmails(res.data.emails);
      }
    } catch (error) {
      console.error('Failed to load emails:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredEmails = emails.filter(e => {
    if (filter === 'unread') return !e.isRead;
    if (filter === 'replied') return e.replied;
    if (filter === 'archived') return e.isArchived;
    return true;
  });

  const unreadCount = emails.filter(e => !e.isRead).length;
  const needsReplyCount = emails.filter(e => !e.isRead && !e.replied).length;

  if (loading) {
    return <div className="text-center py-8 text-gray-400">Loading emails...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-extrabold text-[#1a1a1f]" style={{fontFamily:'Exo 2, sans-serif'}}>Inbox</h1>
        <p className="text-sm text-gray-500 mt-1">Email management & reply tracking</p>
      </div>

      {/* Alert */}
      {needsReplyCount > 0 && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
              <div>
                <p className="font-bold text-red-800 text-sm">⚠️ {needsReplyCount} Email(s) Need Response</p>
                <p className="text-xs text-red-700">Click emails below to compose replies</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className={`border-2 ${unreadCount > 0 ? 'border-blue-300' : 'border-[#e8e6fe]'}`}>
          <CardContent className="p-3">
            <p className={`text-xs ${unreadCount > 0 ? 'text-blue-600 font-bold' : 'text-gray-400'}`}>Unread</p>
            <p className={`text-2xl font-extrabold ${unreadCount > 0 ? 'text-blue-700' : 'text-[#1a1a1f]'}`}>{unreadCount}</p>
          </CardContent>
        </Card>
        <Card className="border-[#e8e6fe]">
          <CardContent className="p-3">
            <p className="text-xs text-gray-400">Total Emails</p>
            <p className="text-2xl font-extrabold text-[#1a1a1f]">{emails.length}</p>
          </CardContent>
        </Card>
        <Card className="border-[#e8e6fe]">
          <CardContent className="p-3">
            <p className="text-xs text-gray-400">Replied</p>
            <p className="text-2xl font-extrabold text-green-600">{emails.filter(e => e.replied).length}</p>
          </CardContent>
        </Card>
        <Card className="border-[#e8e6fe]">
          <CardContent className="p-3">
            <p className="text-xs text-gray-400">Archived</p>
            <p className="text-2xl font-extrabold text-[#1a1a1f]">{emails.filter(e => e.isArchived).length}</p>
          </CardContent>
        </Card>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-2">
        {[
          { id: 'unread', label: 'Unread', count: unreadCount },
          { id: 'replied', label: 'Replied', count: emails.filter(e => e.replied).length },
          { id: 'archived', label: 'Archived', count: emails.filter(e => e.isArchived).length },
          { id: 'all', label: 'All', count: emails.length }
        ].map(f => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
              filter === f.id
                ? 'bg-[#8c82fc] text-white'
                : 'bg-[#e8e6fe] text-[#5e50fb] hover:bg-[#d9d5fc]'
            }`}
            style={{fontFamily:'Montserrat, sans-serif'}}
          >
            {f.label} ({f.count})
          </button>
        ))}
      </div>

      {/* Email List */}
      <Card className="border-[#e8e6fe]">
        <CardContent className="p-0">
          {filteredEmails.length === 0 ? (
            <p className="text-center py-8 text-gray-400 text-sm">No emails</p>
          ) : (
            <div className="divide-y divide-[#e8e6fe]">
              {filteredEmails.map((email, idx) => (
                <div
                  key={idx}
                  className={`p-4 hover:bg-[#f5f4ff] transition-colors ${!email.isRead ? 'bg-[#f9f8ff] border-l-4 border-blue-400' : ''}`}
                >
                  <div className="flex items-start gap-3">
                    <Mail className={`w-5 h-5 flex-shrink-0 mt-1 ${email.isRead ? 'text-gray-300' : 'text-blue-500'}`} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <div className="flex-1">
                          <p className={`font-semibold text-sm ${email.isRead ? 'text-gray-600' : 'text-[#1a1a1f]'}`}>
                            {email.from}
                          </p>
                          <p className={`text-sm ${email.isRead ? 'text-gray-500' : 'text-[#1a1a1f] font-medium'}`}>
                            {email.subject}
                          </p>
                        </div>
                        <span className="text-xs text-gray-400 flex-shrink-0 whitespace-nowrap">
                          {email.receivedDateTime ? formatDistanceToNow(parseISO(email.receivedDateTime), { addSuffix: true }) : '—'}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 line-clamp-2 mb-2">{email.bodyPreview}</p>
                      <div className="flex items-center gap-2">
                        {!email.isRead && <Badge className="bg-blue-100 text-blue-700 text-xs border-0">Unread</Badge>}
                        {email.replied && <Badge className="bg-green-100 text-green-700 text-xs border-0">Replied</Badge>}
                        {email.isArchived && <Badge className="bg-gray-100 text-gray-600 text-xs border-0">Archived</Badge>}
                      </div>
                    </div>
                    <div className="flex gap-1 flex-shrink-0">
                      <button className="p-1.5 hover:bg-[#e8e6fe] rounded" title="Reply">
                        <Reply className="w-4 h-4 text-[#8c82fc]" />
                      </button>
                      <button className="p-1.5 hover:bg-[#e8e6fe] rounded" title="Archive">
                        <Archive className="w-4 h-4 text-gray-400" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}