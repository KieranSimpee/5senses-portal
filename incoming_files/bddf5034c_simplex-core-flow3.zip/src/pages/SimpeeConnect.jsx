import { useEffect, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { base44 } from "@/api/base44Client";
import { CheckCircle, RefreshCw, Smartphone, Wifi, WifiOff } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function SimpeeConnect() {
  const [whatsappUrl, setWhatsappUrl] = useState("");
  const [loading, setLoading] = useState(true);
  const [connected, setConnected] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const url = base44.agents.getWhatsAppConnectURL("simpee");
      setWhatsappUrl(url);
      setConnected(!!url);
    } catch {
      setConnected(false);
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  return (
    <div className="max-w-lg mx-auto py-12 px-6 flex flex-col items-center gap-8">
      {/* Header */}
      <div className="text-center">
        <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
          <Smartphone className="w-8 h-8 text-primary" />
        </div>
        <h1 className="font-exo text-2xl font-bold text-foreground">Connect to Simpee</h1>
        <p className="text-sm text-muted-foreground font-montserrat mt-2">
          Scan this QR code with your phone's camera to open WhatsApp and connect to your Simpee assistant.
        </p>
      </div>

      {/* Status badge */}
      <div className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold font-montserrat ${
        connected ? "bg-green-100 text-green-700" : "bg-red-100 text-red-600"
      }`}>
        {connected
          ? <><Wifi className="w-4 h-4" /> WhatsApp channel is active</>
          : <><WifiOff className="w-4 h-4" /> WhatsApp not configured yet</>
        }
      </div>

      {/* QR Code */}
      {loading ? (
        <div className="w-64 h-64 flex items-center justify-center bg-muted rounded-2xl">
          <RefreshCw className="w-8 h-8 text-muted-foreground animate-spin" />
        </div>
      ) : whatsappUrl ? (
        <div className="p-5 bg-white rounded-2xl shadow-lg border border-border">
          <QRCodeSVG
            value={whatsappUrl}
            size={240}
            bgColor="#ffffff"
            fgColor="#1a1a2e"
            level="H"
            includeMargin={false}
            imageSettings={{
              src: "",
              excavate: false,
            }}
          />
        </div>
      ) : (
        <div className="w-64 h-64 flex flex-col items-center justify-center bg-muted rounded-2xl gap-3 text-center px-6">
          <WifiOff className="w-8 h-8 text-muted-foreground" />
          <p className="text-sm text-muted-foreground font-montserrat">
            WhatsApp is not connected yet. Please set up the WhatsApp channel in the Agents dashboard first.
          </p>
        </div>
      )}

      {/* Direct link */}
      {whatsappUrl && (
        <div className="w-full space-y-3">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center gap-2 w-full bg-green-500 hover:bg-green-600 text-white rounded-lg py-2.5 text-sm font-semibold font-montserrat transition-colors"
          >
            <CheckCircle className="w-4 h-4" />
            Open in WhatsApp directly
          </a>
          <p className="text-[11px] text-muted-foreground font-montserrat text-center">
            Or scan the QR code above with your phone camera
          </p>
        </div>
      )}

      {/* Refresh */}
      <Button variant="outline" onClick={load} className="font-montserrat text-sm gap-2">
        <RefreshCw className="w-4 h-4" /> Refresh
      </Button>

      {/* Instructions */}
      <div className="w-full bg-muted/60 rounded-xl p-4 space-y-2">
        <p className="text-xs font-semibold font-exo text-foreground">How to connect:</p>
        <ol className="text-xs text-muted-foreground font-montserrat space-y-1 list-decimal list-inside">
          <li>Open your phone camera and point at the QR code above</li>
          <li>Tap the WhatsApp link that appears</li>
          <li>Send the pre-filled message to start the connection</li>
          <li>Simpee will reply and you're connected! 🎉</li>
        </ol>
      </div>
    </div>
  );
}