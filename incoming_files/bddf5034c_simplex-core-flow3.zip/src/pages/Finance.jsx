import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Search, Trash2, Edit, Paperclip, ExternalLink, Upload, Eye } from "lucide-react";
import RenewalsTracker from "@/components/finance/RenewalsTracker";
import BankAccountsTab from "@/components/finance/BankAccountsTab";
import InvoiceDetailModal from "@/components/finance/InvoiceDetailModal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format, parseISO, differenceInDays } from "date-fns";

const CATS = ["Professional Fees","Government Fees","Software","Hosting","Microsoft Licenses","Design","Branding & Design","Marketing","Legal","Office & Admin","MPF","Salaries","Other","software","hosting","design","legal"];
const CAT_DISPLAY = {
  "software": "Software",
  "hosting": "Domain & Hosting",
  "design": "Branding & Design",
  "legal": "Legal",
  "Professional Fees": "Professional Fees",
  "Government Fees": "Government Fees",
  "Microsoft Licenses": "Microsoft Licenses",
  "Marketing": "Marketing",
  "Office & Admin": "Office & Admin",
  "MPF": "MPF",
  "Salaries": "Salaries",
  "Other": "Other",
};
const DISPLAY_CATS = ["Professional Fees","Legal","Domain & Hosting","Software","Microsoft Licenses","Branding & Design","Marketing","Office & Admin","MPF","Salaries","Other"];
const CAT_GROUPS = {
  "Domain & Hosting": ["hosting","Hosting","Domain & Hosting"],
  "Software": ["software","Software","Software & Subscriptions"],
  "Branding & Design": ["design","Design","Branding & Design"],
  "Legal": ["legal","Legal"],
  "Professional Fees": ["Professional Fees"],
  "Government Fees": ["Government Fees"],
  "Microsoft Licenses": ["Microsoft Licenses"],
  "Marketing": ["Marketing"],
  "Office & Admin": ["Office & Admin","Office"],
  "MPF": ["MPF"],
  "Salaries": ["Salaries"],
  "Other": ["Other","other"],
};
const METHODS = ["Bank Transfer / FPS","Credit Card","AMEX","PayPal","Shopify billing","Government Portal","Other"];
const empty = { title:"", amount:0, currency:"HKD", category:"Other", date:"", vendor:"", notes:"", status:"paid", payment_method:"Bank Transfer / FPS" };

const F = ({ label, children }) => (
  <div className="space-y-1.5">
    <Label className="text-xs font-bold text-gray-500 uppercase tracking-wide">{label}</Label>
    {children}
  </div>
);

export default function Finance() {
  const [expenses, setExpenses] = useState([]);
  const [compliance, setCompliance] = useState([]);
  const [banks, setBanks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("All");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [viewingInvoice, setViewingInvoice] = useState(null);

  useEffect(() => { load(); }, []);

  const load = async () => {
    const [exp, comp, bk] = await Promise.all([
      base44.entities.Expense.list("-date").catch(() => []),
      base44.entities.ComplianceItem.list().catch(() => []),
      base44.entities.BankAccount.list().catch(() => []),
    ]);
    setExpenses(exp); setCompliance(comp); setBanks(bk); setLoading(false);
  };

  const save = async () => {
    setSaving(true);
    if (editing) await base44.entities.Expense.update(editing.id, form);
    else await base44.entities.Expense.create(form);
    await load(); setShowForm(false); setSaving(false);
  };

  const remove = async (id) => { if (confirm("Delete?")) { await base44.entities.Expense.delete(id); await load(); } };

  const filtered = expenses.filter(e => {
    const catMatch = catFilter === "All" || (CAT_GROUPS[catFilter] || [catFilter]).includes(e.category);
    const searchMatch = !search || e.title?.toLowerCase().includes(search.toLowerCase()) || e.vendor?.toLowerCase().includes(search.toLowerCase());
    return catMatch && searchMatch;
  });

  const totalHKD = expenses.filter(e => e.currency === "HKD").reduce((s, e) => s + (e.amount || 0), 0);
  const totalUSD = expenses.filter(e => e.currency === "USD").reduce((s, e) => s + (e.amount || 0), 0);
  const urgentRenewals = compliance.filter(c => c.status !== "Completed" && c.due_date && differenceInDays(parseISO(c.due_date), new Date()) <= 60).sort((a, b) => new Date(a.due_date) - new Date(b.due_date));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-[#1a1a1f]" style={{fontFamily:'Exo 2, sans-serif'}}>Finance</h1>
          <p className="text-sm text-gray-500 mt-0.5" style={{fontFamily:'Montserrat, sans-serif'}}>Expenses · Renewals · Bank accounts</p>
        </div>
        <Button onClick={() => { setEditing(null); setForm(empty); setShowForm(true); }} className="bg-[#8c82fc] hover:bg-[#5e50fb] text-white gap-2 font-semibold">
          <Plus className="w-4 h-4" /> Add Expense
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total HKD Spent", value: `HKD ${totalHKD.toLocaleString()}`, color: "text-[#5e50fb]" },
          { label: "Total USD Spent", value: `USD ${totalUSD.toLocaleString()}`, color: "text-green-600" },
          { label: "Total Transactions", value: expenses.length, color: "text-[#1a1a1f]" },
          { label: "Urgent Renewals", value: urgentRenewals.length, color: "text-red-600" },
        ].map(s => (
          <Card key={s.label} className="border-[#e8e6fe]">
            <CardContent className="p-4">
              <p className="text-xs text-gray-400 mb-1" style={{fontFamily:'Montserrat, sans-serif'}}>{s.label}</p>
              <p className={`text-xl font-extrabold ${s.color}`} style={{fontFamily:'Exo 2, sans-serif'}}>{s.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="expenses">
        <TabsList className="bg-[#e8e6fe] flex-wrap h-auto gap-1">
          <TabsTrigger value="expenses" style={{fontFamily:'Montserrat, sans-serif'}}>💰 Expenses ({expenses.length})</TabsTrigger>
          <TabsTrigger value="summary" style={{fontFamily:'Montserrat, sans-serif'}}>📊 Monthly Summary</TabsTrigger>
          <TabsTrigger value="hosting" style={{fontFamily:'Montserrat, sans-serif'}}>🌐 Hosting Breakdown</TabsTrigger>
          <TabsTrigger value="microsoft" style={{fontFamily:'Montserrat, sans-serif'}}>💻 Microsoft 365</TabsTrigger>
          <TabsTrigger value="renewals" style={{fontFamily:'Montserrat, sans-serif'}}>🔄 Renewals & Deadlines</TabsTrigger>
          <TabsTrigger value="banks" style={{fontFamily:'Montserrat, sans-serif'}}>🏦 Bank Accounts</TabsTrigger>
        </TabsList>

        <TabsContent value="expenses" className="mt-4 space-y-4">
           {(() => {
             // Summary by month
             const monthlyBreakdown = {};
             const sortedByDate = [...expenses].sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
             sortedByDate.forEach(e => {
               const month = e.date ? e.date.slice(0, 7) : "No Date";
               if (!monthlyBreakdown[month]) monthlyBreakdown[month] = { total: 0, paid: 0, pending: 0, count: 0 };
               monthlyBreakdown[month].total += e.amount || 0;
               monthlyBreakdown[month].count += 1;
               if (e.status === "paid" || e.status === "Approved") monthlyBreakdown[month].paid += e.amount || 0;
               else monthlyBreakdown[month].pending += e.amount || 0;
             });
             const monthsList = Object.entries(monthlyBreakdown).sort(([a], [b]) => b.localeCompare(a)).slice(0, 3);
             return (
               <>
                 {monthsList.length > 0 && (
                   <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                     {monthsList.map(([month, data]) => (
                       <Card key={month} className="border-[#e8e6fe]">
                         <CardContent className="p-4">
                           <p className="text-xs text-gray-400 mb-1" style={{fontFamily:'Montserrat, sans-serif'}}>
                             {month === "No Date" ? "No Date" : format(new Date(month + "-01"), "MMMM yyyy")}
                           </p>
                           <p className="text-lg font-extrabold text-[#5e50fb] mb-2" style={{fontFamily:'Exo 2, sans-serif'}}>
                             HKD {data.total.toLocaleString(undefined, {maximumFractionDigits:0})}
                           </p>
                           <div className="text-xs space-y-1">
                             <div className="flex justify-between"><span className="text-gray-400">Paid:</span><span className="text-green-600 font-semibold">{data.paid.toLocaleString(undefined, {maximumFractionDigits:0})}</span></div>
                             <div className="flex justify-between"><span className="text-gray-400">Pending:</span><span className="text-yellow-600 font-semibold">{data.pending.toLocaleString(undefined, {maximumFractionDigits:0})}</span></div>
                             <div className="flex justify-between"><span className="text-gray-400">Items:</span><span className="font-semibold">{data.count}</span></div>
                           </div>
                         </CardContent>
                       </Card>
                     ))}
                   </div>
                 )}
               </>
             );
           })()}

           <div className="flex flex-wrap gap-3">
             <div className="relative">
               <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
               <Input placeholder="Search expenses..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 w-56" />
             </div>
             <div className="flex flex-wrap gap-2">
               {["All", ...DISPLAY_CATS].map(c => (
                 <button key={c} onClick={() => setCatFilter(c)} className={`px-3 py-1.5 rounded-full text-xs font-bold border transition-all ${catFilter === c ? "bg-[#8c82fc] text-white border-[#8c82fc]" : "text-gray-500 border-gray-200 hover:border-[#8c82fc]"}`} style={{fontFamily:'Montserrat, sans-serif'}}>{c}</button>
               ))}
             </div>
           </div>
          {(() => {
            // Separate pending/synced invoices for approval (top), then rest sorted by date
            const pendingForApproval = filtered.filter(e => (e.status === "Pending" || e.status === "pending") && e.receipt_url);
            const rest = filtered.filter(e => !((e.status === "Pending" || e.status === "pending") && e.receipt_url));
            const sortedRest = rest.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
            const displayList = [...pendingForApproval.sort((a, b) => new Date(b.created_date || 0) - new Date(a.created_date || 0)), ...sortedRest];

            return (
              <Card className="border-[#e8e6fe]">
                <CardContent className="p-0">
                  {loading ? <p className="text-center py-8 text-gray-400 text-sm">Loading...</p> : (
                    <div className="divide-y divide-[#e8e6fe]">
                      <div className="hidden md:grid grid-cols-[2.5fr_1fr_1fr_1fr_1fr_auto] gap-4 px-5 py-3 bg-[#f5f4ff] text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                        <div>Description</div><div>Vendor</div><div>Date</div><div>Amount</div><div>Status</div><div></div>
                      </div>
                      {displayList.map(e => (
                   <div key={e.id} className={`hover:bg-[#f5f4ff] ${(e.status === "Pending" || e.status === "pending") && e.receipt_url ? "border-l-4 border-yellow-400 bg-yellow-50" : ""}`}>
                     <div className="grid grid-cols-[2.5fr_1fr_1fr_1fr_1fr_auto] gap-4 px-5 py-3 items-center">
                       <div>
                         <div className="flex items-center gap-1.5">
                           <p className="text-sm font-semibold text-[#1a1a1f]" style={{fontFamily:'Montserrat, sans-serif'}}>
                             {e.title}
                             {(e.status === "Pending" || e.status === "pending") && e.receipt_url && <span className="ml-1.5 text-xs bg-yellow-200 text-yellow-700 font-bold px-1.5 py-0.5 rounded">FOR APPROVAL</span>}
                           </p>
                           {e.receipt_url && (
                             <a href={e.receipt_url} target="_blank" rel="noopener noreferrer" title="View attached file" className="flex-shrink-0">
                               <Paperclip className="w-3 h-3 text-[#8c82fc]" />
                             </a>
                           )}
                         </div>
                         <div className="flex items-center gap-2 text-xs text-gray-400">
                           <span>{CAT_DISPLAY[e.category] || e.category}</span>
                           {e.created_date && (
                             <>
                               <span>•</span>
                               <span>Uploaded {format(parseISO(e.created_date), "d MMM yyyy")}</span>
                             </>
                           )}
                         </div>
                       </div>
                       <p className="text-xs text-gray-500">{e.vendor}</p>
                       <p className="text-xs text-gray-500">{e.date ? format(parseISO(e.date), "d MMM yy") : "—"}</p>
                       <p className="text-sm font-bold text-[#1a1a1f]">{e.currency} {(e.amount || 0).toLocaleString()}</p>
                       <Badge className={`text-xs font-bold border-0 ${e.status === "paid" || e.status === "Approved" ? "bg-green-100 text-green-700" : e.status === "Pending" || e.status === "pending" ? "bg-yellow-100 text-yellow-700" : "bg-gray-100 text-gray-500"}`}>
                         {e.status === "paid" ? "✓ Paid" : e.status === "Approved" ? "✓ Approved" : e.status === "Pending" || e.status === "pending" ? "⏳ Pending" : e.status}
                       </Badge>
                       <div className="flex gap-1 items-center">
                         {e.receipt_url && <button onClick={() => setViewingInvoice(e)} className="p-1 hover:bg-[#e8e6fe] rounded" title="View details"><Eye className="w-3.5 h-3.5 text-[#8c82fc]" /></button>}
                         <button onClick={() => { setEditing(e); setForm({ ...e }); setShowForm(true); }} className="p-1 hover:bg-[#e8e6fe] rounded"><Edit className="w-3.5 h-3.5 text-gray-400" /></button>
                         <button onClick={() => remove(e.id)} className="p-1 hover:bg-red-50 rounded"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
                       </div>
                     </div>
                     {e.receipt_url && (
                       <div className="px-5 pb-2.5 -mt-1">
                         <a href={e.receipt_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-[10px] text-[#8c82fc] font-semibold bg-[#f0effe] hover:bg-[#e8e6fe] px-2 py-1 rounded-md transition-colors" style={{fontFamily:'Montserrat, sans-serif'}}>
                           <Paperclip className="w-3 h-3" />
                           {e.file_name || "View attached invoice / receipt"}
                         </a>
                       </div>
                     )}
                   </div>
                  ))}
                  {displayList.length === 0 && <p className="text-center text-gray-400 py-8 text-sm">No expenses found</p>}
                    </div>
                  )}
                  </CardContent>
                  </Card>
                  );
                  })()}
                  </TabsContent>

        <TabsContent value="summary" className="mt-4 space-y-4">
          {(() => {
            // Group by year-month
            const byMonth = {};
            expenses.forEach(e => {
              if (!e.date) return;
              const key = e.date.slice(0, 7); // "2026-05"
              if (!byMonth[key]) byMonth[key] = { paid: [], pending: [] };
              const isPending = e.status === "Pending" || e.status === "pending";
              if (isPending) byMonth[key].pending.push(e);
              else byMonth[key].paid.push(e);
            });
            const months = Object.keys(byMonth).sort((a, b) => b.localeCompare(a));
            const pendingAll = expenses.filter(e => e.status === "Pending" || e.status === "pending");
            const pendingTotal = pendingAll.reduce((s, e) => s + (e.amount || 0), 0);

            return (
              <>
                {pendingAll.length > 0 && (
                  <Card className="border-yellow-300 bg-yellow-50">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="font-bold text-yellow-800 text-sm">⚠️ {pendingAll.length} Unpaid / Pending Expense{pendingAll.length !== 1 ? "s" : ""}</p>
                          <p className="text-xs text-yellow-600 mt-0.5">These have not been marked as paid yet</p>
                        </div>
                        <p className="font-extrabold text-yellow-800">HKD {pendingTotal.toLocaleString()}</p>
                      </div>
                      <div className="divide-y divide-yellow-200">
                        {pendingAll.map(e => (
                          <div key={e.id} className="py-2 flex items-center justify-between text-xs">
                            <div>
                              <p className="font-semibold text-yellow-900">{e.title}</p>
                              <p className="text-yellow-600">{e.vendor} · {e.date ? format(parseISO(e.date), "d MMM yyyy") : "—"}</p>
                            </div>
                            <span className="font-bold text-yellow-800">HKD {(e.amount||0).toLocaleString()}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                <div className="space-y-3">
                  {months.map(m => {
                    const { paid, pending } = byMonth[m];
                    const allInMonth = [...paid, ...pending];
                    const monthTotal = allInMonth.reduce((s, e) => s + (e.amount || 0), 0);
                    const paidTotal = paid.reduce((s, e) => s + (e.amount || 0), 0);
                    const pendingMonthTotal = pending.reduce((s, e) => s + (e.amount || 0), 0);
                    // Category breakdown
                    const byCat = {};
                    allInMonth.forEach(e => {
                      const cat = CAT_DISPLAY[e.category] || e.category || "Other";
                      byCat[cat] = (byCat[cat] || 0) + (e.amount || 0);
                    });
                    const catBreakdown = Object.entries(byCat).sort((a, b) => b[1] - a[1]);
                    const [year, mon] = m.split("-");
                    const monthLabel = format(new Date(parseInt(year), parseInt(mon) - 1, 1), "MMMM yyyy");

                    return (
                      <Card key={m} className="border-[#e8e6fe]">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div>
                              <p className="font-extrabold text-[#1a1a1f] text-base" style={{fontFamily:'Exo 2, sans-serif'}}>{monthLabel}</p>
                              <p className="text-xs text-gray-400">{allInMonth.length} transaction{allInMonth.length !== 1 ? "s" : ""}</p>
                            </div>
                            <div className="text-right">
                              <p className="font-extrabold text-[#5e50fb] text-lg">HKD {monthTotal.toLocaleString(undefined, {maximumFractionDigits:0})}</p>
                              <div className="flex gap-2 justify-end mt-0.5">
                                {paidTotal > 0 && <span className="text-xs text-green-600 font-semibold">✓ {paidTotal.toLocaleString(undefined, {maximumFractionDigits:0})} paid</span>}
                                {pendingMonthTotal > 0 && <span className="text-xs text-yellow-600 font-semibold">⚠ {pendingMonthTotal.toLocaleString(undefined, {maximumFractionDigits:0})} pending</span>}
                              </div>
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {catBreakdown.map(([cat, amt]) => (
                              <div key={cat} className="flex items-center gap-1.5 bg-[#f5f4ff] rounded-full px-3 py-1 text-xs">
                                <span className="text-gray-500">{cat}</span>
                                <span className="font-bold text-[#5e50fb]">HKD {amt.toLocaleString(undefined, {maximumFractionDigits:0})}</span>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </>
            );
          })()}
        </TabsContent>

        <TabsContent value="hosting" className="mt-4 space-y-4">
          {(() => {
            const hostingExpenses = expenses.filter(e => (CAT_GROUPS["Domain & Hosting"] || []).includes(e.category));
            const byPlatform = hostingExpenses.reduce((acc, e) => {
              const key = e.vendor || "Unknown";
              if (!acc[key]) acc[key] = { vendor: key, items: [], total: 0 };
              acc[key].items.push(e);
              acc[key].total += e.amount || 0;
              return acc;
            }, {});
            const platforms = Object.values(byPlatform).sort((a, b) => b.total - a.total);
            const grandTotal = platforms.reduce((s, p) => s + p.total, 0);
            const platformEmojis = { GoDaddy: "🔵", Squarespace: "⬛", SiteGround: "🟢", Siteground: "🟢", "Squarespace Ireland Limited": "⬛" };
            return (
              <>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <Card className="border-[#e8e6fe] md:col-span-2">
                    <CardContent className="p-4">
                      <p className="text-xs text-gray-400 mb-1">Total Hosting Spend</p>
                      <p className="text-xl font-extrabold text-[#5e50fb]">HKD {grandTotal.toLocaleString(undefined, {maximumFractionDigits:0})}</p>
                    </CardContent>
                  </Card>
                  <Card className="border-[#e8e6fe]">
                    <CardContent className="p-4">
                      <p className="text-xs text-gray-400 mb-1">Platforms Used</p>
                      <p className="text-xl font-extrabold text-[#1a1a1f]">{platforms.length}</p>
                    </CardContent>
                  </Card>
                  <Card className="border-orange-100 bg-orange-50">
                    <CardContent className="p-4">
                      <p className="text-xs text-orange-600 mb-1 font-bold">💡 Consolidation Tip</p>
                      <p className="text-xs text-orange-700">You're spread across {platforms.length} hosting providers. Consider consolidating to 1–2 to reduce cost & admin.</p>
                    </CardContent>
                  </Card>
                </div>
                <div className="space-y-3">
                  {platforms.map(p => (
                    <Card key={p.vendor} className="border-[#e8e6fe]">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">{platformEmojis[p.vendor] || "🌐"}</span>
                            <div>
                              <p className="font-bold text-sm text-[#1a1a1f]">{p.vendor}</p>
                              <p className="text-xs text-gray-400">{p.items.length} invoice{p.items.length !== 1 ? "s" : ""}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-extrabold text-[#5e50fb]">HKD {p.total.toLocaleString(undefined, {maximumFractionDigits:0})}</p>
                            <p className="text-xs text-gray-400">{Math.round(p.total/grandTotal*100)}% of hosting spend</p>
                          </div>
                        </div>
                        <div className="w-full bg-[#e8e6fe] rounded-full h-1.5 mb-3">
                          <div className="bg-[#8c82fc] h-1.5 rounded-full" style={{width:`${Math.round(p.total/grandTotal*100)}%`}}></div>
                        </div>
                        <div className="divide-y divide-gray-100">
                          {p.items.map(item => (
                            <div key={item.id} className="py-2.5 text-xs">
                              <div className="flex items-center justify-between">
                                <span className="text-gray-700 font-semibold">{item.title}</span>
                                <div className="flex items-center gap-3">
                                  <span className="text-gray-400">{item.date ? format(parseISO(item.date), "d MMM yy") : "—"}</span>
                                  <span className="font-bold text-[#1a1a1f]">{item.currency || "HKD"} {(item.amount||0).toLocaleString()}</span>
                                </div>
                              </div>
                              {item.receipt_url && (
                                <a href={item.receipt_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 mt-1 text-[10px] text-[#8c82fc] font-semibold bg-[#f0effe] hover:bg-[#e8e6fe] px-2 py-0.5 rounded transition-colors" style={{fontFamily:'Montserrat, sans-serif'}}>
                                  <Paperclip className="w-2.5 h-2.5" />
                                  {item.file_name || "View invoice"}
                                </a>
                              )}
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                <Card className="border-blue-200 bg-blue-50">
                  <CardContent className="p-4">
                    <p className="font-bold text-blue-800 text-sm mb-2">🧠 Consolidation Recommendation</p>
                    <p className="text-xs text-blue-700 leading-relaxed">You're currently using <strong>GoDaddy</strong>, <strong>Squarespace</strong>, and <strong>SiteGround</strong> for hosting and domains. Once App S is rebuilt, consider migrating all domains to a single registrar (GoDaddy or Cloudflare) and all hosting to one provider (SiteGround or Cloudflare) to simplify billing and reduce renewal overhead.</p>
                  </CardContent>
                </Card>
              </>
            );
          })()}
        </TabsContent>

        <TabsContent value="microsoft" className="mt-4 space-y-4">
          {(() => {
            const msExpenses = expenses.filter(e => e.category === "Microsoft Licenses" || (e.title?.toLowerCase().includes("microsoft") && e.category === "Software"));
            const totalMs = msExpenses.reduce((s, e) => s + (e.amount || 0), 0);
            const activeMonthly = msExpenses.filter(e => e.title?.includes("Monthly") && e.date && e.date >= "2026-05-01");
            const monthlyTotal = activeMonthly.reduce((s, e) => s + (e.amount || 0), 0);
            return (
              <>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  <Card className="border-[#e8e6fe]">
                    <CardContent className="p-4">
                      <p className="text-xs text-gray-400 mb-1">Total MS 365 Spend</p>
                      <p className="text-xl font-extrabold text-[#5e50fb]">HKD {totalMs.toLocaleString(undefined, {maximumFractionDigits:0})}</p>
                    </CardContent>
                  </Card>
                  <Card className="border-[#e8e6fe]">
                    <CardContent className="p-4">
                      <p className="text-xs text-gray-400 mb-1">Active Monthly Licenses</p>
                      <p className="text-xl font-extrabold text-[#1a1a1f]">{activeMonthly.length}</p>
                    </CardContent>
                  </Card>
                  <Card className="border-[#e8e6fe]">
                    <CardContent className="p-4">
                      <p className="text-xs text-gray-400 mb-1">Monthly Cost (May 2026)</p>
                      <p className="text-xl font-extrabold text-green-600">HKD {monthlyTotal.toLocaleString()}</p>
                    </CardContent>
                  </Card>
                </div>
                {activeMonthly.length > 0 && (
                  <Card className="border-[#e8e6fe]">
                    <CardContent className="p-4">
                      <p className="font-bold text-sm text-[#1a1a1f] mb-3" style={{fontFamily:'Exo 2, sans-serif'}}>Active Monthly Licenses</p>
                      <div className="divide-y divide-[#e8e6fe]">
                        {activeMonthly.map(e => (
                          <div key={e.id} className="py-3 flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center text-base">💻</div>
                              <div>
                                <p className="text-sm font-semibold text-[#1a1a1f]">{e.title}</p>
                                <p className="text-xs text-gray-400">{e.vendor} · {e.date ? format(parseISO(e.date), "d MMM yyyy") : "—"}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              <Badge className={`text-xs border-0 ${e.status === "Approved" || e.status === "paid" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`}>{e.status}</Badge>
                              <p className="font-bold text-[#1a1a1f] text-sm">HKD {(e.amount||0).toLocaleString()}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
                <Card className="border-[#e8e6fe]">
                  <CardContent className="p-4">
                    <p className="font-bold text-sm text-[#1a1a1f] mb-3" style={{fontFamily:'Exo 2, sans-serif'}}>All Microsoft Invoices</p>
                    <div className="divide-y divide-[#e8e6fe]">
                      {msExpenses.sort((a,b) => new Date(b.date) - new Date(a.date)).map(e => (
                        <div key={e.id} className="py-2.5 flex items-center justify-between text-xs">
                          <div>
                            <p className="font-semibold text-[#1a1a1f] text-xs">{e.title}</p>
                            <p className="text-gray-400">{e.vendor} · {e.date ? format(parseISO(e.date), "d MMM yyyy") : "—"}</p>
                          </div>
                          <div className="flex items-center gap-3">
                            <Badge className={`text-xs border-0 ${e.status === "Approved" || e.status === "paid" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`}>{e.status}</Badge>
                            <span className="font-bold text-[#1a1a1f]">HKD {(e.amount||0).toLocaleString()}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </>
            );
          })()}
        </TabsContent>

        <TabsContent value="renewals" className="mt-4">
          <RenewalsTracker />
        </TabsContent>

        <TabsContent value="banks" className="mt-4 space-y-4">
          <BankAccountsTab banks={banks} onRefresh={load} />
        </TabsContent>
      </Tabs>

      <InvoiceDetailModal expense={viewingInvoice} open={!!viewingInvoice} onOpenChange={(open) => !open && setViewingInvoice(null)} />

      <Dialog open={showForm} onOpenChange={setShowForm}>
         <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
           <DialogHeader><DialogTitle style={{fontFamily:'Exo 2, sans-serif'}}>{editing ? "Edit Expense" : "Add Expense"}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <F label="Title"><Input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} /></F>
            <div className="grid grid-cols-2 gap-3">
              <F label="Amount"><Input type="number" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: parseFloat(e.target.value) || 0 }))} /></F>
              <F label="Currency">
                <Select value={form.currency} onValueChange={v => setForm(f => ({ ...f, currency: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="HKD">HKD</SelectItem><SelectItem value="USD">USD</SelectItem><SelectItem value="EUR">EUR</SelectItem><SelectItem value="GBP">GBP</SelectItem></SelectContent>
                </Select>
              </F>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <F label="Category">
                <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{DISPLAY_CATS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </F>
              <F label="Status">
                <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="paid">Paid</SelectItem><SelectItem value="pending">Pending</SelectItem><SelectItem value="overdue">Overdue</SelectItem></SelectContent>
                </Select>
              </F>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <F label="Vendor"><Input value={form.vendor || ""} onChange={e => setForm(f => ({ ...f, vendor: e.target.value }))} /></F>
              <F label="Date"><Input type="date" value={form.date || ""} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} /></F>
            </div>
            <F label="Payment Method">
              <Select value={form.payment_method} onValueChange={v => setForm(f => ({ ...f, payment_method: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{METHODS.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
              </Select>
            </F>
            <F label="Receipt / Invoice URL">
              <div className="flex gap-2">
                <Input value={form.receipt_url || ""} onChange={e => setForm(f => ({ ...f, receipt_url: e.target.value }))} placeholder="Paste URL or upload below" className="flex-1" />
                {form.receipt_url && (
                  <a href={form.receipt_url} target="_blank" rel="noopener noreferrer" className="p-2 border rounded-md hover:bg-[#e8e6fe]">
                    <ExternalLink className="w-4 h-4 text-[#8c82fc]" />
                  </a>
                )}
              </div>
              <label className="flex items-center gap-2 mt-1 cursor-pointer text-xs text-[#8c82fc] font-semibold hover:underline">
                <Upload className="w-3.5 h-3.5" />
                Upload file
                <input type="file" className="hidden" onChange={async (ev) => {
                  const file = ev.target.files[0];
                  if (!file) return;
                  const { file_url } = await base44.integrations.Core.UploadFile({ file });
                  setForm(f => ({ ...f, receipt_url: file_url }));
                }} />
              </label>
            </F>
            <F label="Notes"><Input value={form.notes || ""} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} /></F>
            <div className="flex gap-3 pt-2">
              <Button onClick={save} disabled={saving} className="flex-1 bg-[#8c82fc] hover:bg-[#5e50fb]">{saving ? "Saving..." : editing ? "Update" : "Add"}</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}