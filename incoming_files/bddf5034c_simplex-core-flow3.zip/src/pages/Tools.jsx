import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { ExternalLink, Plus, Trash2, Edit } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

const BUILT_IN_TOOLS = {
  "5SENSESBEAUTY": [
    { name: "Microsoft 365", desc: "Email, Teams, SharePoint", url: "https://office.com", icon: "📧", category: "Productivity" },
    { name: "Shopify", desc: "5sensesbeauty.com store", url: "https://admin.shopify.com", icon: "🛍️", category: "E-Commerce" },
    { name: "GoDaddy", desc: "Domain management", url: "https://godaddy.com", icon: "🌐", category: "Hosting" },
    { name: "SiteGround", desc: "Web hosting", url: "https://siteground.com", icon: "🖥️", category: "Hosting" },
    { name: "Squarespace", desc: "Website builder", url: "https://squarespace.com", icon: "⬛", category: "Hosting" },
    { name: "GlowFinder AI", desc: "Product database & backend", url: "https://app.base44.com/apps/68de61f48718b4d679503028", icon: "🔍", category: "AI & Platform" },
  ],
  "SIMPLEX-ITY": [
    { name: "Canva Pro", desc: "Brand design & social media", url: "https://canva.com", icon: "🎨", category: "Branding" },
    { name: "Looka", desc: "Logo & brand kit", url: "https://looka.com", icon: "✏️", category: "Branding" },
    { name: "TINT / Banuba", desc: "AR try-on integration", url: "https://www.banuba.com/famous-web-ar", icon: "🪄", category: "AI & Platform" },
    { name: "Base44 / Simpee", desc: "Company portal & AI agent", url: "https://app.base44.com", icon: "🤖", category: "AI & Platform" },
    { name: "FundFluent / FluentLab", desc: "Platform dev staging", url: "https://simplex-ity.fluentlab.co", icon: "🔧", category: "Development" },
    { name: "Synthesia", desc: "AI video creation", url: "https://synthesia.io", icon: "🎬", category: "AI & Platform" },
    { name: "Face++", desc: "AI face recognition", url: "https://face-plus-plus.com", icon: "👁️", category: "AI & Platform" },
  ],
};

const CATS = ["Productivity","E-Commerce","Hosting","Branding","AI & Platform","Development","Finance","Communication","Other"];
const CAT_COLORS = {
  "Productivity": "bg-blue-100 text-blue-700",
  "E-Commerce": "bg-green-100 text-green-700",
  "Hosting": "bg-purple-100 text-purple-700",
  "Branding": "bg-pink-100 text-pink-700",
  "AI & Platform": "bg-[#e8e6fe] text-[#5e50fb]",
  "Development": "bg-orange-100 text-orange-700",
};

const empty = { name: "", desc: "", url: "", icon: "🔗", category: "Other", brand: "5SENSESBEAUTY", notes: "" };
const F = ({ label, children }) => (
  <div className="space-y-1.5">
    <Label className="text-xs font-bold text-gray-500 uppercase tracking-wide">{label}</Label>
    {children}
  </div>
);

export default function Tools() {
  const [appTools, setAppTools] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);

  useEffect(() => { load(); }, []);
  const load = async () => {
    const data = await base44.entities.AppTool.list().catch(() => []);
    setAppTools(data);
  };

  const save = async () => {
    setSaving(true);
    if (editing) await base44.entities.AppTool.update(editing.id, form);
    else await base44.entities.AppTool.create(form);
    await load(); setShowForm(false); setSaving(false);
  };

  const remove = async (id) => {
    if (confirm("Remove tool?")) { await base44.entities.AppTool.delete(id); await load(); }
  };

  const ToolCard = ({ tool, onEdit, onDelete }) => (
    <a href={tool.url} target="_blank" rel="noopener noreferrer"
      className="flex items-center gap-3 p-4 bg-white rounded-xl border border-[#e8e6fe] hover:border-[#8c82fc] hover:shadow-sm transition-all group relative">
      <span className="text-2xl flex-shrink-0">{tool.icon || "🔗"}</span>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-bold text-[#1a1a1f] group-hover:text-[#5e50fb]" style={{fontFamily:'Montserrat, sans-serif'}}>{tool.name}</p>
        <p className="text-[11px] text-gray-400 truncate" style={{fontFamily:'Montserrat, sans-serif'}}>{tool.desc || tool.description}</p>
        {tool.category && (
          <Badge className={`mt-1 text-[10px] border-0 px-1.5 py-0 ${CAT_COLORS[tool.category] || "bg-gray-100 text-gray-600"}`}>{tool.category}</Badge>
        )}
      </div>
      <ExternalLink className="w-3.5 h-3.5 text-gray-300 group-hover:text-[#8c82fc] flex-shrink-0" />
      {(onEdit || onDelete) && (
        <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity" onClick={e => e.preventDefault()}>
          {onEdit && <button onClick={onEdit} className="p-1 bg-white rounded hover:bg-[#e8e6fe]"><Edit className="w-3 h-3 text-gray-400" /></button>}
          {onDelete && <button onClick={onDelete} className="p-1 bg-white rounded hover:bg-red-50"><Trash2 className="w-3 h-3 text-red-400" /></button>}
        </div>
      )}
    </a>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-[#1a1a1f]" style={{fontFamily:'Exo 2, sans-serif'}}>Tools & Apps</h1>
          <p className="text-sm text-gray-500 mt-0.5" style={{fontFamily:'Montserrat, sans-serif'}}>All connected apps, tools & platforms</p>
        </div>
        <Button onClick={() => { setEditing(null); setForm(empty); setShowForm(true); }} className="bg-[#8c82fc] hover:bg-[#5e50fb] text-white gap-2 font-semibold">
          <Plus className="w-4 h-4" /> Add Tool
        </Button>
      </div>

      <Tabs defaultValue="5senses">
        <TabsList className="bg-[#e8e6fe]">
          <TabsTrigger value="5senses" style={{fontFamily:'Montserrat, sans-serif'}}>✨ 5SENSESBEAUTY</TabsTrigger>
          <TabsTrigger value="simplex" style={{fontFamily:'Montserrat, sans-serif'}}>🟣 SIMPLEX-ITY</TabsTrigger>
          <TabsTrigger value="custom" style={{fontFamily:'Montserrat, sans-serif'}}>⚙️ Custom ({appTools.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="5senses" className="mt-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {BUILT_IN_TOOLS["5SENSESBEAUTY"].map(t => <ToolCard key={t.name} tool={t} />)}
          </div>
        </TabsContent>

        <TabsContent value="simplex" className="mt-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {BUILT_IN_TOOLS["SIMPLEX-ITY"].map(t => <ToolCard key={t.name} tool={t} />)}
          </div>
        </TabsContent>

        <TabsContent value="custom" className="mt-4">
          {appTools.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <p className="text-sm" style={{fontFamily:'Montserrat, sans-serif'}}>No custom tools yet.</p>
              <button onClick={() => { setEditing(null); setForm(empty); setShowForm(true); }} className="mt-2 text-[#8c82fc] underline text-xs">Add your first tool</button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {appTools.map(t => (
                <ToolCard key={t.id} tool={t}
                  onEdit={e => { setEditing(t); setForm({...t}); setShowForm(true); }}
                  onDelete={e => remove(t.id)}
                />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle style={{fontFamily:'Exo 2, sans-serif'}}>{editing ? "Edit Tool" : "Add Tool"}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <div className="grid grid-cols-4 gap-3">
              <F label="Icon"><Input value={form.icon} onChange={e => setForm(f => ({...f, icon: e.target.value}))} className="text-center text-xl" /></F>
              <div className="col-span-3"><F label="Name"><Input value={form.name} onChange={e => setForm(f => ({...f, name: e.target.value}))} /></F></div>
            </div>
            <F label="URL"><Input value={form.url} onChange={e => setForm(f => ({...f, url: e.target.value}))} placeholder="https://" /></F>
            <F label="Description"><Input value={form.desc || form.description || ""} onChange={e => setForm(f => ({...f, desc: e.target.value, description: e.target.value}))} /></F>
            <div className="grid grid-cols-2 gap-3">
              <F label="Category">
                <Select value={form.category} onValueChange={v => setForm(f => ({...f, category: v}))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{CATS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </F>
              <F label="Brand">
                <Select value={form.brand || "5SENSESBEAUTY"} onValueChange={v => setForm(f => ({...f, brand: v}))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5SENSESBEAUTY">5SENSESBEAUTY</SelectItem>
                    <SelectItem value="SIMPLEX-ITY">SIMPLEX-ITY</SelectItem>
                    <SelectItem value="Both">Both</SelectItem>
                  </SelectContent>
                </Select>
              </F>
            </div>
            <F label="Notes"><Input value={form.notes || ""} onChange={e => setForm(f => ({...f, notes: e.target.value}))} /></F>
            <div className="flex gap-3 pt-2">
              <Button onClick={save} disabled={saving} className="flex-1 bg-[#8c82fc] hover:bg-[#5e50fb]">{saving ? "Saving..." : editing ? "Update" : "Add"}</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}