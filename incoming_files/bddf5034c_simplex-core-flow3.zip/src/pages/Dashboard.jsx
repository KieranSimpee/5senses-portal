import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import AlertsWidget from '@/components/dashboard/AlertsWidget';
import EmailSummaryWidget from '@/components/dashboard/EmailSummaryWidget';
import CostSavingsWidget from '@/components/dashboard/CostSavingsWidget';
import { format, parseISO, differenceInDays } from 'date-fns';
import { TrendingUp, AlertTriangle, DollarSign, Clock } from 'lucide-react';

export default function Dashboard() {
  const [metrics, setMetrics] = useState({
    totalExpenses: 0,
    pendingApprovals: 0,
    renewalsDue: 0,
    complianceItems: 0
  });
  const [topRisks, setTopRisks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    try {
      const [expenses, compliance, renewals] = await Promise.all([
        base44.entities.Expense.list().catch(() => []),
        base44.entities.ComplianceItem.list().catch(() => []),
        base44.entities.RenewalItem.list().catch(() => [])
      ]);

      const today = new Date();
      const totalExpenses = expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
      const pendingApprovals = expenses.filter(e => e.status === 'Pending' || e.status === 'pending').length;
      const renewalsDue = renewals.filter(r => {
        const daysLeft = differenceInDays(parseISO(r.renewal_date), today);
        return daysLeft > 0 && daysLeft <= 30;
      }).length;
      const complianceItems = compliance.filter(c => c.status !== 'Completed').length;

      setMetrics({
        totalExpenses,
        pendingApprovals,
        renewalsDue,
        complianceItems
      });

      // Identify top risks
      const risks = [];
      
      const overdue = compliance.filter(c => new Date(c.due_date) < today && c.status !== 'Completed');
      if (overdue.length > 0) risks.push({
        type: 'overdue',
        title: `${overdue.length} Overdue Compliance Items`,
        severity: 'critical',
        action: 'Review immediately'
      });

      const expiredRenewals = renewals.filter(r => new Date(r.renewal_date) < today && r.status === 'Active');
      if (expiredRenewals.length > 0) risks.push({
        type: 'expired',
        title: `${expiredRenewals.length} Expired Renewals`,
        severity: 'critical',
        action: 'Update status'
      });

      if (pendingApprovals > 5) risks.push({
        type: 'approvals',
        title: `${pendingApprovals} Expenses Pending Approval`,
        severity: 'high',
        action: 'Review & approve'
      });

      setTopRisks(risks);
    } catch (error) {
      console.error('Failed to load dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading dashboard...</div>;
  }

  const riskColors = {
    critical: 'border-red-200 bg-red-50',
    high: 'border-yellow-200 bg-yellow-50',
    medium: 'border-orange-200 bg-orange-50'
  };

  const riskTextColors = {
    critical: 'text-red-700',
    high: 'text-yellow-700',
    medium: 'text-orange-700'
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-[#1a1a1f]" style={{fontFamily:'Exo 2, sans-serif'}}>Executive Dashboard</h1>
        <p className="text-sm text-gray-500 mt-0.5">Real-time business intelligence & alerts</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Expenses', value: `HKD ${metrics.totalExpenses.toLocaleString()}`, icon: DollarSign, color: 'text-[#5e50fb]' },
          { label: 'Pending Approvals', value: metrics.pendingApprovals, icon: AlertTriangle, color: 'text-yellow-600' },
          { label: 'Renewals Due (30d)', value: metrics.renewalsDue, icon: Clock, color: 'text-orange-600' },
          { label: 'Compliance Items', value: metrics.complianceItems, icon: TrendingUp, color: 'text-blue-600' }
        ].map(m => {
          const Icon = m.icon;
          return (
            <Card key={m.label} className="border-[#e8e6fe]">
              <CardContent className="p-4">
                <Icon className={`w-5 h-5 ${m.color} mb-2`} />
                <p className="text-xs text-gray-400">{m.label}</p>
                <p className={`text-lg font-bold ${m.color} mt-1`}>{m.value}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Alerts Widget */}
      <AlertsWidget />

      {/* Top Risks */}
      {topRisks.length > 0 && (
        <div>
          <h2 className="text-sm font-bold text-[#1a1a1f] mb-3">⚠️ Top Risks</h2>
          <div className="space-y-2">
            {topRisks.map((risk, idx) => (
              <Card key={idx} className={`border ${riskColors[risk.severity]}`}>
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className={`font-semibold text-sm ${riskTextColors[risk.severity]}`}>{risk.title}</p>
                      <p className={`text-xs ${riskTextColors[risk.severity]} mt-0.5 opacity-75`}>{risk.action}</p>
                    </div>
                    <Badge className={`${riskColors[risk.severity]} border-0`}>{risk.severity}</Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Smart Widgets Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <EmailSummaryWidget />
        <CostSavingsWidget />
      </div>

      {/* Email Integration Notice */}
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <h3 className="font-bold text-sm text-blue-900 mb-2">📧 Email & External Apps Integration</h3>
          <p className="text-xs text-blue-700 mb-3">Access all your critical applications from one place. Go to Admin → External Apps to:</p>
          <ul className="text-xs text-blue-700 space-y-1 mb-3">
            <li>✓ Save login credentials securely</li>
            <li>✓ Quick-launch apps directly from the vault</li>
            <li>✓ Sync with Outlook for email reminders</li>
            <li>✓ View all communications in the Inbox</li>
          </ul>
          <div className="flex gap-2">
            <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white text-xs">
              Configure Now
            </Button>
            <Button size="sm" variant="outline" className="text-xs border-blue-300">
              View Inbox
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}