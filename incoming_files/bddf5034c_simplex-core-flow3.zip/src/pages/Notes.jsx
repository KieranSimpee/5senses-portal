import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, Trash2, Edit, Pin, Search, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format, parseISO } from "date-fns";

const SOURCES = ["Manual", "WhatsApp", "Simpee", "Email", "Meeting", "Other"];
const empty = { title: "", content: "", source: "Manual", tags: "", pinned: false, project_id: "" };

const F = ({ label, children }) => (
  <div className="space-y-1.5">
    <Label className="text-xs font-bold text-gray-500 uppercase tracking-wide" style={{fontFamily:'Montserrat, sans-serif'}}>{label}</Label>
    {children}
  </div>
);

const SOURCE_COLORS = {
  WhatsApp: "bg-green-100 text-green-700",
  Simpee: "bg-[#e8e6fe] text-[#5e50fb]",
  Manual: "bg-gray-100 text-gray-600",
  Email: "bg-blue-100 text-blue-700",
  Meeting: "bg-yellow-100 text-yellow-700",
  Other: "bg-gray-100 text-gray-500",
};

export default function Notes() {
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [tagFilter, setTagFilter] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);

  useEffect(() => { load(); }, []);

  const load = async () => {
    const d = await base44.entities.Note.list("-created_date").catch(() => []);
    setNotes(d); setLoading(false);
  };

  const save = async () => {
    setSaving(true);
    const tags = form.tags ? form.tags.split(",").map(t => t.trim()).filter(Boolean) : [];
    if (editing) await base44.entities.Note.update(editing.id, { ...form, tags });
    else await base44.entities.Note.create({ ...form, tags });
    await load(); setShowForm(false); setSaving(false); setForm(empty); setEditing(null);
  };

  const remove = async (id) => {
    if (confirm("Delete this note?")) { await base44.entities.Note.delete(id); await load(); }
  };

  const togglePin = async (note) => {
    await base44.entities.Note.update(note.id, { pinned: !note.pinned });
    await load();
  };

  const allTags = [...new Set(notes.flatMap(n => n.tags || []))].sort();

  const filtered = notes.filter(n => {
    const matchSearch = !search || n.title?.toLowerCase().includes(search.toLowerCase()) || n.content?.toLowerCase().includes(search.toLowerCase());
    const matchTag = !tagFilter || (n.tags || []).includes(tagFilter);
    return matchSearch && matchTag;
  });

  const pinned = filtered.filter(n => n.pinned);
  const unpinned = filtered.filter(n => !n.pinned);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-[#1a1a1f]" style={{fontFamily:'Exo 2, sans-serif'}}>Notes</h1>
          <p className="text-sm text-gray-500 mt-0.5" style={{fontFamily:'Montserrat, sans-serif'}}>From WhatsApp, meetings & manual entries</p>
        </div>
        <Button onClick={() => { setEditing(null); setForm(empty); setShowForm(true); }} className="bg-[#8c82fc] hover:bg-[#5e50fb] text-white gap-2 font-semibold" style={{fontFamily:'Montserrat, sans-serif'}}>
          <Plus className="w-4 h-4" /> Add Note
        </Button>
      </div>

      <div className="flex flex-wrap gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input placeholder="Search notes..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 w-56" style={{fontFamily:'Montserrat, sans-serif'}} />
        </div>
        {allTags.length > 0 && (
          <div className="flex flex-wrap gap-2 items-center">
            <Tag className="w-3.5 h-3.5 text-gray-400" />
            <button onClick={() => setTagFilter("")} className={`px-2.5 py-1 rounded-full text-xs font-bold border transition-all ${!tagFilter ? "bg-[#8c82fc] text-white border-[#8c82fc]" : "text-gray-500 border-gray-200 hover:border-[#8c82fc]"}`} style={{fontFamily:'Montserrat, sans-serif'}}>All</button>
            {allTags.map(t => (
              <button key={t} onClick={() => setTagFilter(t === tagFilter ? "" : t)} className={`px-2.5 py-1 rounded-full text-xs font-bold border transition-all ${tagFilter === t ? "bg-[#8c82fc] text-white border-[#8c82fc]" : "text-gray-500 border-gray-200 hover:border-[#8c82fc]"}`} style={{fontFamily:'Montserrat, sans-serif'}}>{t}</button>
            ))}
          </div>
        )}
      </div>

      {loading ? (
        <p className="text-center py-8 text-gray-400 text-sm">Loading notes...</p>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          <p className="text-sm" style={{fontFamily:'Montserrat, sans-serif'}}>No notes yet. <button onClick={() => setShowForm(true)} className="text-[#8c82fc] underline">Add one</button></p>
        </div>
      ) : (
        <div className="space-y-6">
          {pinned.length > 0 && (
            <div>
              <p className="text-xs font-bold text-[#8c82fc] uppercase tracking-widest mb-3" style={{fontFamily:'Montserrat, sans-serif'}}>📌 Pinned</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {pinned.map(n => <NoteCard key={n.id} note={n} onEdit={() => { setEditing(n); setForm({...n, tags: (n.tags || []).join(", ")}); setShowForm(true); }} onDelete={() => remove(n.id)} onPin={() => togglePin(n)} />)}
              </div>
            </div>
          )}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {unpinned.map(n => <NoteCard key={n.id} note={n} onEdit={() => { setEditing(n); setForm({...n, tags: (n.tags || []).join(", ")}); setShowForm(true); }} onDelete={() => remove(n.id)} onPin={() => togglePin(n)} />)}
          </div>
        </div>
      )}

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle style={{fontFamily:'Exo 2, sans-serif'}}>{editing ? "Edit Note" : "New Note"}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <F label="Title"><Input value={form.title} onChange={e => setForm(f => ({...f, title: e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <F label="Content"><Textarea value={form.content || ""} onChange={e => setForm(f => ({...f, content: e.target.value}))} rows={5} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <F label="Source">
              <Select value={form.source || "Manual"} onValueChange={v => setForm(f => ({...f, source: v}))}>
                <SelectTrigger style={{fontFamily:'Montserrat, sans-serif'}}><SelectValue /></SelectTrigger>
                <SelectContent>{SOURCES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </F>
            <F label="Tags (comma separated)"><Input value={form.tags || ""} onChange={e => setForm(f => ({...f, tags: e.target.value}))} placeholder="e.g. finance, urgent, review" style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <div className="flex items-center gap-2">
              <input type="checkbox" id="pinned" checked={form.pinned || false} onChange={e => setForm(f => ({...f, pinned: e.target.checked}))} className="w-4 h-4 accent-[#8c82fc]" />
              <label htmlFor="pinned" className="text-xs font-semibold text-gray-600" style={{fontFamily:'Montserrat, sans-serif'}}>Pin to top</label>
            </div>
            <div className="flex gap-3 pt-2">
              <Button onClick={save} disabled={saving} className="flex-1 bg-[#8c82fc] hover:bg-[#5e50fb]">{saving ? "Saving..." : editing ? "Update" : "Save"}</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function NoteCard({ note, onEdit, onDelete, onPin }) {
  return (
    <Card className={`border group transition-all ${note.pinned ? "border-[#bab4fd] bg-[#faf9ff]" : "border-[#e8e6fe] hover:border-[#bab4fd]"}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <p className="font-bold text-sm text-[#1a1a1f] leading-tight" style={{fontFamily:'Montserrat, sans-serif'}}>{note.title}</p>
          <div className="flex gap-1 flex-shrink-0">
            <button onClick={onPin} className="p-1 hover:bg-[#e8e6fe] rounded">
              <Pin className={`w-3 h-3 ${note.pinned ? "text-[#8c82fc] fill-[#8c82fc]" : "text-gray-300"}`} />
            </button>
            <button onClick={onEdit} className="p-1 hover:bg-[#e8e6fe] rounded opacity-0 group-hover:opacity-100 transition-opacity">
              <Edit className="w-3 h-3 text-gray-400" />
            </button>
            <button onClick={onDelete} className="p-1 hover:bg-red-50 rounded opacity-0 group-hover:opacity-100 transition-opacity">
              <Trash2 className="w-3 h-3 text-red-400" />
            </button>
          </div>
        </div>
        {note.content && <p className="text-xs text-gray-600 leading-relaxed mb-3 line-clamp-3" style={{fontFamily:'Montserrat, sans-serif'}}>{note.content}</p>}
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div className="flex flex-wrap gap-1">
            {(note.tags || []).map(t => (
              <span key={t} className="text-[10px] bg-[#e8e6fe] text-[#5e50fb] px-2 py-0.5 rounded-full font-semibold" style={{fontFamily:'Montserrat, sans-serif'}}>{t}</span>
            ))}
          </div>
          <div className="flex items-center gap-2">
            {note.source && <Badge className={`text-[10px] border-0 ${SOURCE_COLORS[note.source] || "bg-gray-100 text-gray-500"}`}>{note.source}</Badge>}
            <span className="text-[10px] text-gray-300" style={{fontFamily:'Montserrat, sans-serif'}}>{note.created_date ? format(parseISO(note.created_date), "d MMM yyyy") : ""}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}