import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Plus, ExternalLink, Trash2, Edit, Star, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { format, parseISO } from "date-fns";

const BRAND_COLORS = [
  { name:"Primary Lilac", hex:"#8c82fc" }, { name:"Accent Violet", hex:"#5e50fb" },
  { name:"Soft Lilac", hex:"#bab4fd" }, { name:"Lavender Wash", hex:"#e8e6fe" },
  { name:"White Canvas", hex:"#ffffff" }, { name:"Neutral Grey", hex:"#e6e6e6" },
  { name:"Body Text", hex:"#1a1a1f" },
];

const TIERS = ["Tier 1","Tier 2","Tier 3","KOL","Nano","Micro","Macro"];
const PLATFORMS = ["Instagram","TikTok","YouTube","Xiaohongshu","Facebook","Other"];
const BRAND_STATUSES = ["Active","Inactive","Prospect","Churned"];
const INF_STATUSES = ["Active","Inactive","Pending","Blacklisted"];
const CAMPAIGN_STATUSES = ["Draft","Active","Completed","Cancelled","Paused"];

const F = ({ label, children }) => (
  <div className="space-y-1.5">
    <Label className="text-xs font-bold text-gray-500 uppercase tracking-wide" style={{fontFamily:'Montserrat, sans-serif'}}>{label}</Label>
    {children}
  </div>
);

export default function Brand() {
  const [brands, setBrands] = useState([]);
  const [influencers, setInfluencers] = useState([]);
  const [campaigns, setCampaigns] = useState([]);
  const [revenue, setRevenue] = useState([]);
  const [loading, setLoading] = useState(true);

  // Forms
  const [showBrandForm, setShowBrandForm] = useState(false);
  const [showInfForm, setShowInfForm] = useState(false);
  const [showCampForm, setShowCampForm] = useState(false);
  const [editingBrand, setEditingBrand] = useState(null);
  const [editingInf, setEditingInf] = useState(null);
  const [editingCamp, setEditingCamp] = useState(null);
  const [brandForm, setBrandForm] = useState({ name:"", tier:"Tier 2", status:"Active", category:"", country:"HK", contact_name:"", contact_email:"", membership_fee:0, notes:"" });
  const [infForm, setInfForm] = useState({ name:"", handle:"", platform:"Instagram", tier:"Micro", status:"Active", email:"", reliability_score:5, commission_rate:0, follower_count:0, notes:"" });
  const [campForm, setCampForm] = useState({ title:"", brand_name:"", status:"Draft", phase:"Planning", start_date:"", end_date:"", total_revenue:0, notes:"" });
  const [saving, setSaving] = useState(false);

  useEffect(() => { load(); }, []);

  const load = async () => {
    const [b, inf, c, r] = await Promise.all([
      base44.entities.Brand.list("-created_date").catch(() => []),
      base44.entities.Influencer.list("-created_date").catch(() => []),
      base44.entities.Campaign.list("-created_date").catch(() => []),
      base44.entities.RevenueRecord.list("-date").catch(() => []),
    ]);
    setBrands(b); setInfluencers(inf); setCampaigns(c); setRevenue(r); setLoading(false);
  };

  const saveBrand = async () => { setSaving(true); if (editingBrand) await base44.entities.Brand.update(editingBrand.id, brandForm); else await base44.entities.Brand.create(brandForm); await load(); setShowBrandForm(false); setSaving(false); };
  const saveInf = async () => { setSaving(true); if (editingInf) await base44.entities.Influencer.update(editingInf.id, infForm); else await base44.entities.Influencer.create(infForm); await load(); setShowInfForm(false); setSaving(false); };
  const saveCamp = async () => { setSaving(true); if (editingCamp) await base44.entities.Campaign.update(editingCamp.id, campForm); else await base44.entities.Campaign.create(campForm); await load(); setShowCampForm(false); setSaving(false); };

  const statusColor = (s) => ({ Active:"bg-green-100 text-green-700", Inactive:"bg-gray-100 text-gray-500", Prospect:"bg-blue-100 text-blue-700", Churned:"bg-red-100 text-red-700", Draft:"bg-gray-100 text-gray-500", Completed:"bg-green-100 text-green-700", Cancelled:"bg-red-100 text-red-700", Paused:"bg-yellow-100 text-yellow-700", Pending:"bg-yellow-100 text-yellow-700", Blacklisted:"bg-red-100 text-red-700" }[s] || "bg-gray-100 text-gray-500");

  const totalRevenue = revenue.reduce((s, r) => s + (r.amount || 0), 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-[#1a1a1f]" style={{fontFamily:'Exo 2, sans-serif'}}>Brand</h1>
        <p className="text-sm text-gray-500 mt-0.5" style={{fontFamily:'Montserrat, sans-serif'}}>Brands · Influencers · Campaigns · Revenue</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label:"Brands", value:brands.filter(b=>b.status==="Active").length + " active", color:"text-[#5e50fb]" },
          { label:"Influencers", value:influencers.filter(i=>i.status==="Active").length + " active", color:"text-[#8c82fc]" },
          { label:"Campaigns", value:campaigns.filter(c=>c.status==="Active").length + " active", color:"text-green-600" },
          { label:"Total Revenue", value:`HKD ${totalRevenue.toLocaleString()}`, color:"text-[#1a1a1f]" },
        ].map(s => (
          <Card key={s.label} className="border-[#e8e6fe]">
            <CardContent className="p-4">
              <p className="text-xs text-gray-400 mb-1" style={{fontFamily:'Montserrat, sans-serif'}}>{s.label}</p>
              <p className={`text-xl font-extrabold ${s.color}`} style={{fontFamily:'Exo 2, sans-serif'}}>{s.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="brands">
        <TabsList className="bg-[#e8e6fe] flex-wrap h-auto gap-1">
          <TabsTrigger value="brands" style={{fontFamily:'Montserrat, sans-serif'}}>🏷️ Brands ({brands.length})</TabsTrigger>
          <TabsTrigger value="influencers" style={{fontFamily:'Montserrat, sans-serif'}}>⭐ Influencers ({influencers.length})</TabsTrigger>
          <TabsTrigger value="campaigns" style={{fontFamily:'Montserrat, sans-serif'}}>🚀 Campaigns ({campaigns.length})</TabsTrigger>
          <TabsTrigger value="revenue" style={{fontFamily:'Montserrat, sans-serif'}}>💰 Revenue ({revenue.length})</TabsTrigger>
          <TabsTrigger value="identity" style={{fontFamily:'Montserrat, sans-serif'}}>🎨 Identity</TabsTrigger>
        </TabsList>

        {/* BRANDS */}
        <TabsContent value="brands" className="mt-4 space-y-4">
          <div className="flex justify-end">
            <Button onClick={() => { setEditingBrand(null); setBrandForm({ name:"", tier:"Tier 2", status:"Active", category:"", country:"HK", contact_name:"", contact_email:"", membership_fee:0, notes:"" }); setShowBrandForm(true); }} className="bg-[#8c82fc] hover:bg-[#5e50fb] text-white gap-2 font-semibold" style={{fontFamily:'Montserrat, sans-serif'}}>
              <Plus className="w-4 h-4" /> Add Brand
            </Button>
          </div>
          {loading ? <p className="text-center py-8 text-gray-400 text-sm">Loading...</p> : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {brands.map(b => (
                <Card key={b.id} className="border-[#e8e6fe] hover:border-[#bab4fd] transition-all group">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-bold text-sm text-[#1a1a1f]" style={{fontFamily:'Montserrat, sans-serif'}}>{b.name}</p>
                        {b.contact_name && <p className="text-xs text-gray-400">{b.contact_name}{b.contact_email ? ` · ${b.contact_email}` : ""}</p>}
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => { setEditingBrand(b); setBrandForm({...b}); setShowBrandForm(true); }} className="p-1 hover:bg-[#e8e6fe] rounded"><Edit className="w-3.5 h-3.5 text-gray-400" /></button>
                        <button onClick={() => { if(confirm("Delete?")) base44.entities.Brand.delete(b.id).then(load); }} className="p-1 hover:bg-red-100 rounded"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Badge className={`text-[10px] border-0 ${statusColor(b.status)}`}>{b.status}</Badge>
                      {b.tier && <Badge className="bg-[#e8e6fe] text-[#5e50fb] border-0 text-[10px]">{b.tier}</Badge>}
                      {b.category && <span className="text-[10px] text-gray-400">{b.category}</span>}
                      {b.country && <span className="text-[10px] text-gray-400">{b.country}</span>}
                    </div>
                    {b.membership_fee > 0 && <p className="text-xs font-bold text-[#5e50fb] mt-1.5">HKD {b.membership_fee.toLocaleString()}/mo</p>}
                    {b.notes && <p className="text-[11px] text-gray-400 mt-1.5 leading-relaxed">{b.notes}</p>}
                  </CardContent>
                </Card>
              ))}
              {brands.length === 0 && <p className="text-center text-gray-400 py-8 text-sm col-span-2">No brands yet</p>}
            </div>
          )}
        </TabsContent>

        {/* INFLUENCERS */}
        <TabsContent value="influencers" className="mt-4 space-y-4">
          <div className="flex justify-end">
            <Button onClick={() => { setEditingInf(null); setInfForm({ name:"", handle:"", platform:"Instagram", tier:"Micro", status:"Active", email:"", reliability_score:5, commission_rate:0, follower_count:0, notes:"" }); setShowInfForm(true); }} className="bg-[#8c82fc] hover:bg-[#5e50fb] text-white gap-2 font-semibold" style={{fontFamily:'Montserrat, sans-serif'}}>
              <Plus className="w-4 h-4" /> Add Influencer
            </Button>
          </div>
          {loading ? <p className="text-center py-8 text-gray-400 text-sm">Loading...</p> : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {influencers.map(inf => (
                <Card key={inf.id} className="border-[#e8e6fe] hover:border-[#bab4fd] transition-all group">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-bold text-sm text-[#1a1a1f]" style={{fontFamily:'Montserrat, sans-serif'}}>{inf.name}</p>
                        {inf.handle && <p className="text-xs text-[#8c82fc]">@{inf.handle}</p>}
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => { setEditingInf(inf); setInfForm({...inf}); setShowInfForm(true); }} className="p-1 hover:bg-[#e8e6fe] rounded"><Edit className="w-3.5 h-3.5 text-gray-400" /></button>
                        <button onClick={() => { if(confirm("Delete?")) base44.entities.Influencer.delete(inf.id).then(load); }} className="p-1 hover:bg-red-100 rounded"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 mb-2">
                      <Badge className={`text-[10px] border-0 ${statusColor(inf.status)}`}>{inf.status}</Badge>
                      {inf.platform && <Badge className="bg-[#e8e6fe] text-[#5e50fb] border-0 text-[10px]">{inf.platform}</Badge>}
                      {inf.tier && <span className="text-[10px] text-gray-400">{inf.tier}</span>}
                    </div>
                    <div className="text-xs text-gray-500 space-y-0.5" style={{fontFamily:'Montserrat, sans-serif'}}>
                      {inf.follower_count > 0 && <div className="flex justify-between"><span>Followers</span><span className="font-semibold text-[#1a1a1f]">{inf.follower_count.toLocaleString()}</span></div>}
                      {inf.reliability_score && <div className="flex justify-between items-center"><span>Reliability</span><div className="flex items-center gap-1"><Star className="w-3 h-3 text-yellow-500 fill-yellow-500" /><span className="font-semibold text-[#1a1a1f]">{inf.reliability_score}/10</span></div></div>}
                      {inf.commission_rate > 0 && <div className="flex justify-between"><span>Commission</span><span className="font-semibold text-[#1a1a1f]">{inf.commission_rate}%</span></div>}
                    </div>
                  </CardContent>
                </Card>
              ))}
              {influencers.length === 0 && <p className="text-center text-gray-400 py-8 text-sm col-span-3">No influencers yet</p>}
            </div>
          )}
        </TabsContent>

        {/* CAMPAIGNS */}
        <TabsContent value="campaigns" className="mt-4 space-y-4">
          <div className="flex justify-end">
            <Button onClick={() => { setEditingCamp(null); setCampForm({ title:"", brand_name:"", status:"Draft", phase:"Planning", start_date:"", end_date:"", total_revenue:0, notes:"" }); setShowCampForm(true); }} className="bg-[#8c82fc] hover:bg-[#5e50fb] text-white gap-2 font-semibold" style={{fontFamily:'Montserrat, sans-serif'}}>
              <Plus className="w-4 h-4" /> Add Campaign
            </Button>
          </div>
          {loading ? <p className="text-center py-8 text-gray-400 text-sm">Loading...</p> : (
            <div className="space-y-3">
              {campaigns.map(c => (
                <Card key={c.id} className="border-[#e8e6fe] hover:border-[#bab4fd] transition-all group">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <p className="font-bold text-sm text-[#1a1a1f]" style={{fontFamily:'Montserrat, sans-serif'}}>{c.title}</p>
                          <Badge className={`text-[10px] border-0 ${statusColor(c.status)}`}>{c.status}</Badge>
                          {c.phase && <span className="text-[10px] text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">{c.phase}</span>}
                        </div>
                        {c.brand_name && <p className="text-xs text-gray-500 mb-1">{c.brand_name}</p>}
                        <div className="text-xs text-gray-400 flex gap-3 flex-wrap" style={{fontFamily:'Montserrat, sans-serif'}}>
                          {c.start_date && <span>Start: {format(parseISO(c.start_date), "d MMM yyyy")}</span>}
                          {c.end_date && <span>End: {format(parseISO(c.end_date), "d MMM yyyy")}</span>}
                          {c.total_revenue > 0 && <span className="font-bold text-green-600">Revenue: HKD {c.total_revenue.toLocaleString()}</span>}
                        </div>
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => { setEditingCamp(c); setCampForm({...c}); setShowCampForm(true); }} className="p-1 hover:bg-[#e8e6fe] rounded"><Edit className="w-3.5 h-3.5 text-gray-400" /></button>
                        <button onClick={() => { if(confirm("Delete?")) base44.entities.Campaign.delete(c.id).then(load); }} className="p-1 hover:bg-red-100 rounded"><Trash2 className="w-3.5 h-3.5 text-red-400" /></button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {campaigns.length === 0 && <p className="text-center text-gray-400 py-8 text-sm">No campaigns yet</p>}
            </div>
          )}
        </TabsContent>

        {/* REVENUE */}
        <TabsContent value="revenue" className="mt-4 space-y-4">
          <Card className="border-[#e8e6fe]">
            <CardContent className="p-0">
              <div className="hidden md:grid grid-cols-[2fr_1fr_1fr_1fr_1fr] gap-4 px-5 py-3 bg-[#f5f4ff] text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                <div>Campaign</div><div>Influencer</div><div>Brand</div><div>Amount</div><div>Date</div>
              </div>
              {revenue.map(r => (
                <div key={r.id} className="grid grid-cols-[2fr_1fr_1fr_1fr_1fr] gap-4 px-5 py-3 border-b border-[#e8e6fe] last:border-0 hover:bg-[#f5f4ff]">
                  <p className="text-sm font-semibold text-[#1a1a1f]" style={{fontFamily:'Montserrat, sans-serif'}}>{r.campaign_title}</p>
                  <p className="text-xs text-gray-500">{r.influencer_name}</p>
                  <p className="text-xs text-gray-500">{r.brand_name}</p>
                  <p className="text-sm font-bold text-green-600">{r.currency || "HKD"} {(r.amount||0).toLocaleString()}</p>
                  <p className="text-xs text-gray-400">{r.date ? format(parseISO(r.date), "d MMM yy") : "—"}</p>
                </div>
              ))}
              {revenue.length === 0 && <p className="text-center py-8 text-gray-400 text-sm">No revenue records yet</p>}
            </CardContent>
          </Card>
        </TabsContent>

        {/* IDENTITY */}
        <TabsContent value="identity" className="mt-4">
          <Card className="border-[#e8e6fe]">
            <CardContent className="p-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3" style={{fontFamily:'Montserrat, sans-serif'}}>Brand Colors</p>
                  <div className="space-y-2">
                    {BRAND_COLORS.map(c => (
                      <div key={c.hex} className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg border border-gray-200 flex-shrink-0" style={{backgroundColor:c.hex}} />
                        <div>
                          <p className="text-xs font-bold text-[#1a1a1f]" style={{fontFamily:'Montserrat, sans-serif'}}>{c.name}</p>
                          <p className="text-[10px] font-mono text-gray-400">{c.hex}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2" style={{fontFamily:'Montserrat, sans-serif'}}>Typography</p>
                    <p className="text-sm text-[#1a1a1f] mb-1" style={{fontFamily:'Exo 2, sans-serif'}}>Exo 2 — Headlines</p>
                    <p className="text-sm text-gray-500" style={{fontFamily:'Montserrat, sans-serif'}}>Montserrat — Body</p>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-2" style={{fontFamily:'Montserrat, sans-serif'}}>Brand Name</p>
                    <p className="text-sm font-bold text-[#1a1a1f]" style={{fontFamily:'Exo 2, sans-serif'}}>SIMPLEX-ITY</p>
                    <p className="text-xs text-[#8c82fc] mt-1 font-semibold" style={{fontFamily:'Montserrat, sans-serif'}}>Simplify to Amplify</p>
                  </div>
                  <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                    <p className="text-xs font-bold text-red-700" style={{fontFamily:'Montserrat, sans-serif'}}>⚠️ PROHIBITED</p>
                    <p className="text-xs text-red-500 mt-0.5" style={{fontFamily:'Montserrat, sans-serif'}}>"ONE STOP ASIAN BEAUTY" — never use</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Brand Dialog */}
      <Dialog open={showBrandForm} onOpenChange={setShowBrandForm}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle style={{fontFamily:'Exo 2, sans-serif'}}>{editingBrand ? "Edit Brand" : "Add Brand"}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <F label="Name"><Input value={brandForm.name} onChange={e => setBrandForm(f=>({...f,name:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <div className="grid grid-cols-2 gap-3">
              <F label="Tier"><Select value={brandForm.tier||"Tier 2"} onValueChange={v=>setBrandForm(f=>({...f,tier:v}))}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent>{TIERS.map(t=><SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select></F>
              <F label="Status"><Select value={brandForm.status||"Active"} onValueChange={v=>setBrandForm(f=>({...f,status:v}))}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent>{BRAND_STATUSES.map(s=><SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select></F>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <F label="Category"><Input value={brandForm.category||""} onChange={e=>setBrandForm(f=>({...f,category:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
              <F label="Country"><Input value={brandForm.country||"HK"} onChange={e=>setBrandForm(f=>({...f,country:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            </div>
            <F label="Contact Name"><Input value={brandForm.contact_name||""} onChange={e=>setBrandForm(f=>({...f,contact_name:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <F label="Contact Email"><Input value={brandForm.contact_email||""} onChange={e=>setBrandForm(f=>({...f,contact_email:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <F label="Membership Fee (HKD/mo)"><Input type="number" value={brandForm.membership_fee||0} onChange={e=>setBrandForm(f=>({...f,membership_fee:parseFloat(e.target.value)||0}))} /></F>
            <F label="Notes"><Input value={brandForm.notes||""} onChange={e=>setBrandForm(f=>({...f,notes:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <div className="flex gap-3 pt-2">
              <Button onClick={saveBrand} disabled={saving} className="flex-1 bg-[#8c82fc] hover:bg-[#5e50fb]">{saving?"Saving...":editingBrand?"Update":"Add"}</Button>
              <Button variant="outline" onClick={()=>setShowBrandForm(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Influencer Dialog */}
      <Dialog open={showInfForm} onOpenChange={setShowInfForm}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle style={{fontFamily:'Exo 2, sans-serif'}}>{editingInf ? "Edit Influencer" : "Add Influencer"}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <F label="Name"><Input value={infForm.name} onChange={e=>setInfForm(f=>({...f,name:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <div className="grid grid-cols-2 gap-3">
              <F label="Handle"><Input value={infForm.handle||""} onChange={e=>setInfForm(f=>({...f,handle:e.target.value}))} placeholder="@handle" style={{fontFamily:'Montserrat, sans-serif'}} /></F>
              <F label="Platform"><Select value={infForm.platform||"Instagram"} onValueChange={v=>setInfForm(f=>({...f,platform:v}))}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent>{PLATFORMS.map(p=><SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent></Select></F>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <F label="Tier"><Select value={infForm.tier||"Micro"} onValueChange={v=>setInfForm(f=>({...f,tier:v}))}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent>{TIERS.map(t=><SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent></Select></F>
              <F label="Status"><Select value={infForm.status||"Active"} onValueChange={v=>setInfForm(f=>({...f,status:v}))}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent>{INF_STATUSES.map(s=><SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select></F>
            </div>
            <F label="Email"><Input value={infForm.email||""} onChange={e=>setInfForm(f=>({...f,email:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <div className="grid grid-cols-2 gap-3">
              <F label="Follower Count"><Input type="number" value={infForm.follower_count||0} onChange={e=>setInfForm(f=>({...f,follower_count:parseInt(e.target.value)||0}))} /></F>
              <F label="Reliability (1-10)"><Input type="number" min="1" max="10" value={infForm.reliability_score||5} onChange={e=>setInfForm(f=>({...f,reliability_score:parseFloat(e.target.value)||5}))} /></F>
            </div>
            <F label="Commission Rate (%)"><Input type="number" value={infForm.commission_rate||0} onChange={e=>setInfForm(f=>({...f,commission_rate:parseFloat(e.target.value)||0}))} /></F>
            <F label="Notes"><Input value={infForm.notes||""} onChange={e=>setInfForm(f=>({...f,notes:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <div className="flex gap-3 pt-2">
              <Button onClick={saveInf} disabled={saving} className="flex-1 bg-[#8c82fc] hover:bg-[#5e50fb]">{saving?"Saving...":editingInf?"Update":"Add"}</Button>
              <Button variant="outline" onClick={()=>setShowInfForm(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Campaign Dialog */}
      <Dialog open={showCampForm} onOpenChange={setShowCampForm}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle style={{fontFamily:'Exo 2, sans-serif'}}>{editingCamp ? "Edit Campaign" : "Add Campaign"}</DialogTitle></DialogHeader>
          <div className="space-y-3 py-2">
            <F label="Title"><Input value={campForm.title} onChange={e=>setCampForm(f=>({...f,title:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <F label="Brand Name"><Input value={campForm.brand_name||""} onChange={e=>setCampForm(f=>({...f,brand_name:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <div className="grid grid-cols-2 gap-3">
              <F label="Status"><Select value={campForm.status||"Draft"} onValueChange={v=>setCampForm(f=>({...f,status:v}))}><SelectTrigger><SelectValue/></SelectTrigger><SelectContent>{CAMPAIGN_STATUSES.map(s=><SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select></F>
              <F label="Phase"><Input value={campForm.phase||""} onChange={e=>setCampForm(f=>({...f,phase:e.target.value}))} placeholder="e.g. Launch" style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <F label="Start Date"><Input type="date" value={campForm.start_date||""} onChange={e=>setCampForm(f=>({...f,start_date:e.target.value}))} /></F>
              <F label="End Date"><Input type="date" value={campForm.end_date||""} onChange={e=>setCampForm(f=>({...f,end_date:e.target.value}))} /></F>
            </div>
            <F label="Total Revenue (HKD)"><Input type="number" value={campForm.total_revenue||0} onChange={e=>setCampForm(f=>({...f,total_revenue:parseFloat(e.target.value)||0}))} /></F>
            <F label="Notes"><Input value={campForm.notes||""} onChange={e=>setCampForm(f=>({...f,notes:e.target.value}))} style={{fontFamily:'Montserrat, sans-serif'}} /></F>
            <div className="flex gap-3 pt-2">
              <Button onClick={saveCamp} disabled={saving} className="flex-1 bg-[#8c82fc] hover:bg-[#5e50fb]">{saving?"Saving...":editingCamp?"Update":"Add"}</Button>
              <Button variant="outline" onClick={()=>setShowCampForm(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}