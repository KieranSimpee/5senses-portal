import { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Upload, Eye, CheckCircle, AlertCircle, Loader2, Copy, FileCode } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function CodeUpload() {
  const [file, setFile] = useState(null);
  const [code, setCode] = useState("");
  const [fileName, setFileName] = useState("");
  const [uploading, setUploading] = useState(false);
  const [applied, setApplied] = useState(false);
  const [error, setError] = useState(null);
  const [copied, setCopied] = useState(false);
  const fileRef = useRef();

  function handleFileSelect(e) {
    const f = e.target.files[0];
    if (!f) return;
    setFile(f);
    setFileName(f.name);
    setApplied(false);
    setError(null);
    const reader = new FileReader();
    reader.onload = (ev) => setCode(ev.target.result);
    reader.readAsText(f);
  }

  async function handleApply() {
    if (!file || !code) return;
    setUploading(true);
    setError(null);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      await base44.entities.Document.create({
        title: fileName,
        category: "other",
        file_url,
        file_name: fileName,
        file_type: file.type || "text/plain",
        notes: "Uploaded via Code Upload tool",
        tags: ["code", "upload"],
      });
      setApplied(true);
    } catch (err) {
      setError(err.message);
    }
    setUploading(false);
  }

  function handleCopy() {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  const ext = fileName.split(".").pop()?.toLowerCase();
  const isCode = ["js", "jsx", "ts", "tsx", "json", "css", "html"].includes(ext);

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-exo font-bold text-foreground flex items-center gap-2">
          <FileCode className="w-6 h-6 text-primary" /> Code Upload
        </h1>
        <p className="text-sm text-muted-foreground font-montserrat mt-1">
          Upload a code file, preview its contents, then apply it to the app.
        </p>
      </div>

      {/* Drop Zone */}
      <div
        onClick={() => fileRef.current.click()}
        onDragOver={e => e.preventDefault()}
        onDrop={e => {
          e.preventDefault();
          const f = e.dataTransfer.files[0];
          if (f) {
            setFile(f); setFileName(f.name); setApplied(false); setError(null);
            const reader = new FileReader();
            reader.onload = ev => setCode(ev.target.result);
            reader.readAsText(f);
          }
        }}
        className="border-2 border-dashed border-border rounded-xl p-10 text-center cursor-pointer hover:border-primary hover:bg-primary/5 transition-colors mb-6"
      >
        <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
        <p className="font-montserrat text-sm text-muted-foreground">
          {fileName ? (
            <span className="text-foreground font-semibold">{fileName}</span>
          ) : (
            <>Drop a file here or <span className="text-primary font-semibold">click to browse</span></>
          )}
        </p>
        <p className="text-xs text-muted-foreground mt-1">Supports .js, .jsx, .ts, .tsx, .json, .css, .html and more</p>
        <input ref={fileRef} type="file" className="hidden" onChange={handleFileSelect} />
      </div>

      {/* Code Preview */}
      {code && (
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm font-semibold font-exo text-foreground">Preview — {fileName}</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary font-montserrat">
                {code.split("\n").length} lines
              </span>
            </div>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              {copied ? <CheckCircle className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? "Copied!" : "Copy"}
            </button>
          </div>
          <pre className="bg-muted rounded-xl p-4 text-xs font-mono overflow-auto max-h-[500px] text-foreground border border-border leading-relaxed">
            {code.split("\n").map((line, i) => (
              <div key={i} className="flex gap-4">
                <span className="select-none text-muted-foreground w-8 text-right flex-shrink-0">{i + 1}</span>
                <span>{line || " "}</span>
              </div>
            ))}
          </pre>
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="flex items-center gap-2 bg-destructive/10 text-destructive border border-destructive/20 rounded-lg px-4 py-3 text-sm font-montserrat mb-4">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}

      {/* Success */}
      {applied && (
        <div className="flex items-center gap-2 bg-green-50 text-green-700 border border-green-200 rounded-lg px-4 py-3 text-sm font-montserrat mb-4">
          <CheckCircle className="w-4 h-4 flex-shrink-0" />
          <span><strong>{fileName}</strong> uploaded and saved to Documents successfully.</span>
        </div>
      )}

      {/* Actions */}
      {code && !applied && (
        <div className="flex gap-3">
          <Button
            onClick={handleApply}
            disabled={uploading}
            className="bg-primary text-primary-foreground font-montserrat"
          >
            {uploading ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> Applying…</>
            ) : (
              <><CheckCircle className="w-4 h-4" /> Apply to App</>
            )}
          </Button>
          <Button
            variant="outline"
            onClick={() => { setFile(null); setCode(""); setFileName(""); setError(null); }}
            disabled={uploading}
            className="font-montserrat"
          >
            Clear
          </Button>
        </div>
      )}

      {applied && (
        <Button
          variant="outline"
          onClick={() => { setFile(null); setCode(""); setFileName(""); setApplied(false); setError(null); }}
          className="font-montserrat"
        >
          Upload Another File
        </Button>
      )}
    </div>
  );
}